export const environment = {
    production: true,
    AES_key: '7Zk9ImH5C4W8A1MP',
    AES_initVectorStr: 'FLvEHyF7qY6meHAU',

    managementUIURL: 'https://oddev.westus.cloudapp.azure.com/optidesk',
    managementApiURL: 'https://oddev.westus.cloudapp.azure.com',
    managementBackupURL: 'http://192.168.100.12:8082',

    caapUIURL: 'https://odcaap.eastus.cloudapp.azure.com/optidesk',
    caapApiURL: 'https://odcaap.eastus.cloudapp.azure.com',
    caapBackupURL: 'http://192.168.100.12:8081'
};
