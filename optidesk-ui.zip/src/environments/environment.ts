// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    AES_key: '7Zk9ImH5C4W8A1MP',
    AES_initVectorStr: 'FLvEHyF7qY6meHAU',

    managementUIURL: 'http://localhost/oddev',
    managementApiURL: 'http://localhost/oddev_api',
    managementBackupURL: 'http://192.168.100.12:8081',

    caapUIURL: 'http://localhost/odcaap',
    caapApiURL: 'http://localhost/odcaap_api',
    caapBackupURL: 'http://192.168.100.12:8083'
};
