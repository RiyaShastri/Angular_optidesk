import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../field.interface';

@Component({
    selector: 'app-field-error',
    templateUrl: './field-error.component.html',
    styleUrls: ['./field-error.component.css']
})
export class FieldErrorComponent implements OnInit {

    @Input() group: FormGroup;
    @Input() field: FieldConfig;
    @Input() isTableEditable = false;
    constructor() { }

    ngOnInit(): void {
    }

}
