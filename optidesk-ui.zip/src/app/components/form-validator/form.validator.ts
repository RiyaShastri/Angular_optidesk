import { AbstractControl, ValidatorFn } from '@angular/forms';
import * as moment from 'moment';

export function noDuplicateRecord(): ValidatorFn {
    return (control: AbstractControl) => {
        if (control.value && control.value !== '' && control.parent) {
            const formControlName = getControlName(control);
            const tabRecords = control.parent.parent.value;
            const index = tabRecords.findIndex(tabRecord => {
                if (tabRecord[formControlName] && tabRecord[formControlName] !== '') {
                    return addLeadingZero(tabRecord[formControlName]) === addLeadingZero(control.value);
                }
            });
            if (index > -1) {
                return { noDuplicateRecord: control.value };
            }
            return null;
        }
        return null;
    };
}

function addLeadingZero(dateString: string): string {
    if (dateString && !dateString.includes('/')) {
        return dateString;
    }
    const dateObj = dateString.split('/');
    dateObj[0] = dateObj[0].length === 2 ? dateObj[0] : '0' + dateObj[0];
    dateObj[1] = dateObj[1].length === 2 ? dateObj[1] : '0' + dateObj[1];
    return dateObj.join('/');
}

function getControlName(c: AbstractControl): string | null {
    const formGroup = c.parent.controls;
    return Object.keys(formGroup).find(name => c === formGroup[name]) || null;
}

export function invalidYearValidation(validationType, formArrayName, fieldName): ValidatorFn {
    return (control: AbstractControl) => {
        if (formArrayName !== '' && control.root && control.value && control.value !== '') {
            const formArray = control.root.get(formArrayName);
            if (formArray) {
                const valueArray = formArray.value;
                if (valueArray.length > 0) {
                    if (validationType === 'lessOrEqual' && valueArray[0].hasOwnProperty(fieldName)) {
                        const minFieldvalue = valueArray[0][fieldName];
                        if (minFieldvalue.includes('/')) {
                            const minFieldArr = minFieldvalue.split('/');
                            if (minFieldArr.length === 3) {
                                if (control.value > minFieldArr[2]) {
                                    return { invalidYearValidation: control.value };
                                }
                                return null;
                            }

                        }
                    } else if (validationType === 'greaterOrEqual' && valueArray[valueArray.length - 1].hasOwnProperty(fieldName)) {
                        const maxFieldvalue = valueArray[valueArray.length - 1][fieldName];
                        if (maxFieldvalue.includes('/')) {
                            const maxFieldArr = maxFieldvalue.split('/');
                            if (maxFieldArr.length === 3) {
                                if (control.value < maxFieldArr[2]) {
                                    return { invalidYearValidation: control.value };
                                }
                                return null;
                            }

                        }
                    }
                    return null;
                }
            }
            return null;
        }
        return null;
    };
}

export function lessThanOrEqualValidation(compareFielddName, isDate?): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFielddName !== '' && control.parent && control.value !== '') {
            const compareFielddNameObj = compareFielddName.split('.');
            const compareField = control.parent.get(compareFielddNameObj[1]);
            const compareValue = compareField.value;
            if (isDate && compareValue !== '') {
                const controlDate = moment(control.value, 'DD-MM-YYYY');
                const compareDate = moment(compareValue, 'DD-MM-YYYY');
                if (compareDate.diff(controlDate, 'days') < 0) {
                    return { lessThanOrEqualValidation: control.value };
                } else {
                    if (!compareField.valid) {
                        compareField.updateValueAndValidity();
                    }
                    return null;
                }
            } else {
                if (compareValue !== '' && control.value > compareValue) {
                    return { lessThanOrEqualValidation: control.value };
                } else {
                    if (!compareField.valid) {
                        compareField.updateValueAndValidity();
                    }
                    return null;
                }
            }
        }
        return null;
    };
}

export function greaterThanOrEqualValidation(compareFielddName, isDate?): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFielddName !== '' && control.parent && control.value !== '') {
            const compareFielddNameObj = compareFielddName.split('.');
            const compareField = control.parent.get(compareFielddNameObj[1]);
            const compareValue = compareField.value;
            if (isDate && compareValue !== '') {
                const controlDate = moment(control.value, 'DD-MM-YYYY');
                const compareDate = moment(compareValue, 'DD-MM-YYYY');
                if (controlDate.diff(compareDate, 'days') < 0) {
                    return { greaterThanOrEqualValidation: control.value };
                } else {
                    if (!compareField.valid) {
                        compareField.updateValueAndValidity();
                    }
                    return null;
                }
            } else {
                if (control.value < compareValue) {
                    return { greaterThanOrEqualValidation: control.value };
                } else {
                    if (!compareField.valid) {
                        compareField.updateValueAndValidity();
                    }
                    return null;
                }
            }
        }
        return null;
    };

}

export function noDuplicatValue(): ValidatorFn {
    return (control: AbstractControl) => {
        if (control.value && control.value !== '' && control.parent) {
            const formControlName = getControlName(control);
            const tabRecords = control.parent.parent.value;
            const index = tabRecords.filter(tabRecord => {
                if (tabRecord[formControlName] && tabRecord[formControlName] !== '') {
                    return (tabRecord[formControlName] === control.value);
                }
            });
            if (index.length > 1) {
                return { noDuplicatValue: control.value };
            }
            return null;
        }
        return null;
    };
}


export function checkCombination(combinationField): ValidatorFn {
    return (control: AbstractControl) => {
        if (combinationField !== '' && control.parent && control.value !== '') {
            const formControlName = getControlName(control);
            const combinationFieldNameObj = combinationField.split('.');
            const compareField = control.parent.get(combinationFieldNameObj[0]);
            if (compareField && compareField.value) {
                const tabRecords = control.parent.parent.value;
                const filterRecord = tabRecords.filter(x => x[combinationFieldNameObj[0]] === compareField.value);
                const index = filterRecord.filter(x => x[formControlName] === control.value);
                if (index.length > 1) {
                    return { checkCombination: control.value };
                }
                return null;
            }
        }
        return null;
    };

}

function setTimeFormate(data) {
    let time = '';
    for (const compa in data) {
        if (compa === 'hour') {
            time = data[compa];
        } else {
            time += ':' + data[compa];
        }
    }
    return time;
}

export function compareStartTime(compareFielddName): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFielddName !== '' && control.parent && control.value !== '') {
            const compareFielddNameObj = compareFielddName.split('.');
            const compareField = control.parent.get(compareFielddNameObj[0]);
            let controlTime = '';
            let compareTime = '';
            if (compareField) {
                controlTime = setTimeFormate(control.value);
                const compareValue = compareField.value;
                if (compareValue) {
                    compareTime = setTimeFormate(compareValue);
                }
            }
            const compareT = moment(compareTime, 'h:mm:ss');
            const controlT = moment(controlTime, 'h:mm:ss');
            if (compareT.isBefore(controlT) || compareT.isSame(controlT)) {
                return { compareStartTime: control.value };
            } else {
                if (!compareField.valid) {
                    compareField.updateValueAndValidity();
                }
                return null;
            }
        }
        return null;
    };
}

export function compareFinishTime(compareFielddName): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFielddName !== '' && control.parent && control.value !== '') {
            const compareFielddNameObj = compareFielddName.split('.');
            const compareField = control.parent.get(compareFielddNameObj[0]);
            let controlTime = '';
            let compareTime = '';
            if (compareField) {
                controlTime = setTimeFormate(control.value);
                const compareValue = compareField.value;
                if (compareValue) {
                    compareTime = setTimeFormate(compareValue);
                }
            }
            const compareT = moment(compareTime, 'h:mm:ss');
            const controlT = moment(controlTime, 'h:mm:ss');
            if (controlT.isBefore(compareT) || compareT.isSame(controlT)) {
                return { compareFinishTime: control.value };
            } else {
                if (!compareField.valid) {
                    compareField.updateValueAndValidity();
                }
                return null;
            }
        }
        return null;
    };
}

export function checkBreakTime(start, end): ValidatorFn {
    return (control: AbstractControl) => {
        if (start !== '' && end !== '' && control.parent && control.value !== '') {
            const startObj = start.split('.');
            const startField = control.parent.get(startObj[0]);
            const endObj = end.split('.');
            const endField = control.parent.get(endObj[0]);
            const startTime = setTimeFormate(startField.value);
            const endTime = setTimeFormate(endField.value);
            const startT = moment(startTime, 'HH:mm:ss');
            const endT = moment(endTime, 'HH:mm:ss');
            const duration = moment.duration(endT.diff(startT));
            const compareTime = moment.utc(+duration).format('HH:mm:ss');
            let controlTime = '';
            controlTime = setTimeFormate(control.value);
            const compareT = moment(compareTime, 'h:mm:ss');
            const controlT = moment(controlTime, 'h:mm:ss');
            if (compareT.isBefore(controlT)) {
                return { checkBreakTime: control.value };
            } else {
                return null;
            }
        }
        return null;
    };
}

export function isNotEqualValue(compareFielddName): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFielddName !== '' && control.parent && control.value !== '') {
            const compareFielddNameObj = compareFielddName.split('.');
            const compareField = control.parent.get(compareFielddNameObj[0]);
            const compareValue = compareField.value;
            if (compareValue !== null && compareValue !== '' && control.value === compareValue) {
                return { isNotEqualValue: control.value };
            } else {
                if (!compareField.valid) {
                    compareField.updateValueAndValidity();
                }
                return null;
            }
        }
        return null;
    };
}

export function isEqualValue(compareFielddName): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFielddName !== '' && control.parent && control.value !== '') {
            const compareFielddNameObj = compareFielddName.split('.');
            const compareField = control.parent.get(compareFielddNameObj[0]);
            const compareValue = compareField.value;
            if (compareValue !== null && compareValue !== '' && control.value !== compareValue) {
                return { isEqualValue: control.value };
            } else {
                if (!compareField.valid) {
                    compareField.updateValueAndValidity();
                }
                return null;
            }
        }
        return null;
    };
}

export function noTimeOvelap(compareFieldName, shiftNo, start, end): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFieldName !== '' && shiftNo && control.parent && control.value !== '') {
            const compareFieldNameObj = compareFieldName.split('.');
            const compareField = control.parent.get(compareFieldNameObj[0]);
            const compareValue = compareField.value;
            const shiftNoObj = shiftNo.split('.');
            const shiftNoField = control.parent.get(shiftNoObj[0]);
            const shiftNoValue = shiftNoField.value;
            const startObj = start.split('.');
            const startField = control.parent.get(startObj[0]);
            const endObj = end.split('.');
            const endField = control.parent.get(endObj[0]);
            if (compareValue !== null && shiftNo !== '') {
                const tableRecord = control.parent.parent.value;
                const filterRecords = tableRecord.filter(x => (x[compareFieldName]).toString() === (compareValue).toString()
                    && x[shiftNo].toString() !== (shiftNoValue).toString());
                const checkRecords = [];
                if (filterRecords.length > 0) {
                    filterRecords.forEach(record => {
                        if (record[start] && record[end]) {
                            checkRecords.push({
                                startTime: setTimeFormate(record[start]),
                                endTime: setTimeFormate(record[end])
                            });
                        }
                    });
                    if (startField.value && endField.value) {
                        const startTime = setTimeFormate(startField.value);
                        const endTime = setTimeFormate(endField.value);
                        const start2 = moment(startTime, 'HH:mm:ss');
                        const end2 = moment(endTime, 'HH:mm:ss');
                        let error = 0;
                        checkRecords.forEach(record => {
                            const start1 = moment(record.startTime, 'HH:mm:ss');
                            const end1 = moment(record.endTime, 'HH:mm:ss');
                            if (!start2.isBetween(start1, end1) && !end2.isBetween(start1, end1) && !start1.isSame(start2)
                                && !end1.isSame(end2) && !start1.isSame(end2) && !end1.isSame(start2)
                                && !start1.isBetween(start2, end2) && !end1.isBetween(start2, end2)) {
                                return null;
                            } else {
                                error = error + 1;
                            }
                        });
                        if (error > 0) {
                            return { noTimeOvelap: control.value };
                        } else {
                            return null;
                        }
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    };
}

export function noDuplicateShift(compareFieldName): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFieldName !== '' && control.parent && control.value !== '') {
            const compareField = control.parent.get(compareFieldName);
            const compareValue = compareField.value;
            const formControlName = getControlName(control);
            const tabRecords = control.parent.parent.value;
            if (control.value && compareValue && compareValue !== '') {
                const isCompareExist = tabRecords.filter(tabRecord => {
                    if (tabRecord[formControlName] && tabRecord[formControlName] !== '') {
                        return ((tabRecord[formControlName]).toString() === (control.value).toString());
                    }
                });
                if (isCompareExist.length > 1) {
                    const isSameRecord = isCompareExist.filter(record => {
                        if (record[compareFieldName] && compareValue) {
                            return ((record[compareFieldName]).toString() === compareValue.toString());
                        }
                    });
                    if (isSameRecord.length > 1) {
                        return { noDuplicateShift: control.value };
                    } else {
                        if (!compareField.valid) {
                            compareField.updateValueAndValidity();
                        }
                        return null;
                    }
                } else {
                    if (!compareField.valid) {
                        compareField.updateValueAndValidity();
                    }
                    return null;
                }
            }
        }
        return null;
    };
}

export function noDuplicateDayForShift(compareFieldName): ValidatorFn {
    return (control: AbstractControl) => {
        if (compareFieldName !== '' && control.parent && control.value !== '') {
            const compareField = control.parent.get(compareFieldName);
            const compareValue = compareField.value;
            const formControlName = getControlName(control);
            const tabRecords = control.parent.parent.value;
            if (control.value && compareValue && compareValue !== '') {
                const isCompareExist = tabRecords.filter(tabRecord => {
                    if (tabRecord[formControlName] && tabRecord[formControlName] !== '') {
                        return ((tabRecord[formControlName]).toString() === (control.value).toString());
                    }
                });
                if (isCompareExist.length > 1) {
                    const isSameRecord = isCompareExist.filter(record => {
                        if (record[compareFieldName] && compareValue) {
                            return ((record[compareFieldName]).toString() === compareValue.toString());
                        }
                    });
                    if (isSameRecord.length > 1) {
                        return { noDuplicateDayForShift: control.value };
                    } else {
                        if (!compareField.valid) {
                            compareField.updateValueAndValidity();
                        }
                        return null;
                    }
                } else {
                    if (!compareField.valid) {
                        compareField.updateValueAndValidity();
                    }
                    return null;
                }
            }
        }
        return null;
    };
}

export function shiftnoNotGreaterThanNoShift(compareFieldName, tabName): ValidatorFn {
    return (control: AbstractControl) => {
        if (control.value && control.value !== '' && control.parent) {
            const compareFieldValue = control.parent.parent.parent.controls[tabName].value[0][compareFieldName];
            if (control.value > compareFieldValue) {
                return { shiftnoNotGreaterThanNoShift: control.value };
            }
            return null;
        }
        return null;
    };
}

