import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { ComponentService } from '../component.service';
import { faTimes, faCheckCircle, faInfoCircle, faCheck, faMinusCircle, faPlusCircle } from '@fortawesome/free-solid-svg-icons';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CONSTANTS } from 'src/app/shared/constants';
import { Router } from '@angular/router';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';

@Component({
    selector: 'app-dynamic-table',
    templateUrl: './dynamic-table.component.html',
    styles: [],
})

export class DynamicTableComponent implements OnInit {
    @Input() section;
    @Input() tableRecords = [];
    @Input() pageType;
    @Input() masterData;
    @Input() tblName;
    @Input() primaryData;
    @Input() isTableEditable;
    @Input() mainFromGroupObj: FormGroup;

    faTimes = faTimes;
    faInfoCircle = faInfoCircle;
    faCheckCircle = faCheckCircle;
    faCheck = faCheck;
    faMinusCircle = faMinusCircle;
    faPlusCircle = faPlusCircle;
    fieldValue = [];
    columns = [];
    addIndex = 0;
    initFormObject = false;
    tableFormArray: FormArray;
    fromGroupObj: FormGroup;
    CONSTANTS = CONSTANTS;
    lessFields = true;
    resetForm = false;
    performSort = false;
    isHoldiay = false;
    isModelLocation = false;
    isModelMaterial = false;
    isModelLocationMaterial = false;
    isTransportationLanes = false;
    isShiftCapacity = false;
    records = [];
    dropList = {};
    offset = 500;

    constructor(
        private fb: FormBuilder,
        private componentService: ComponentService,
        private modalService: NgbModal,
        private router: Router,
        private planningDataService: PlanningDataService
    ) {
        this.isHoldiay = this.router.url.indexOf('holiday-calendar') > -1;
        this.isModelLocation = this.router.url.indexOf('model-location/') > -1;
        this.isModelMaterial = this.router.url.indexOf('model-material') > -1;
        this.isModelLocationMaterial = this.router.url.indexOf('model-location-material') > -1;
        this.isTransportationLanes = this.router.url.indexOf('transportation-lanes') > -1;
        this.isShiftCapacity = this.router.url.indexOf('shift-capacity') > -1;

        this.planningDataService.currentMessage.subscribe(message => {
            if (message.includes('masterData')) {
                const obj = JSON.parse(message.replace('masterData|', ''));
                this.masterData[obj.masterDataKey] = obj.options;
                const masterDataObj = Object.assign({}, this.masterData);
                this.masterData = {};
                this.masterData = masterDataObj;
            }
        });
    }

    ngOnInit(): void {
        this.tableFormArray = (this.mainFromGroupObj.get(this.tblName) as FormArray);
        this.createTableForm();
        if (this.section.hasOwnProperty('sortBy') && this.section.sortBy.hasOwnProperty('name')) {
            this.performSort = true;
        }
    }

    createTableForm() {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.tableRecords.forEach((tableRecord, rowIndex) => {
                const rowFormGroup = this.componentService.createFormFields({
                    fieldsArray: this.section.fields,
                    masterData: this.masterData,
                    groupObj: this.fb.group({}),
                    fieldValue: tableRecord
                });
                this.tableFormArray.insert(rowIndex, rowFormGroup);
            });
        }
        this.records = this.tableRecords.slice(0, this.offset);
        this.columns = [];
        this.section.fields.forEach((fieldRow) => {
            fieldRow.forEach((column) => {
                this.columns.push(column);
            });
        });
    }

    editRecord(rowIndex) {
        this.fromGroupObj = this.tableFormArray.controls[rowIndex] as FormGroup;
    }

    addRecord(content) {
        this.addIndex = this.tableFormArray.controls.length;
        const sectionFields = this.section.fields;
        let option = {};
        if (this.isTableEditable) {
            option = { size: 'lg' };
        }
        if (this.isTransportationLanes || this.isShiftCapacity) {
            option = { size: 'xl' };
        }
        this.fromGroupObj = this.componentService.createFormFields({
            fieldsArray: sectionFields,
            masterData: this.masterData,
            groupObj: this.fb.group({}),
            fieldValue: this.primaryData
        });
        this.tableFormArray.push(this.fromGroupObj);
        this.modalHandler(content, option).then(res => {
            const formValue = this.fromGroupObj.value;
            this.tableRecords.push(formValue);
            if (this.tableRecords.length < this.offset) {
                this.records.push(formValue);
            }
            if (this.performSort && this.isHoldiay) {
                this.sortHoliday();
            }
            this.removeChildDropDownOptions();
        }).catch(err => {
            this.tableFormArray.removeAt(this.addIndex);
            this.removeChildDropDownOptions();
        });
    }

    removeChildDropDownOptions() {
        this.section.fields.forEach((section, secIndex) => {
            section.forEach((fields, index) => {
                if (fields.hasOwnProperty('isFillChildDropList') && fields.isFillChildDropList) {
                    this.section.fields[secIndex][index + 1].options = [];
                    this.masterData[fields.masterDataKey] = [];
                }
            });
        });
    }

    sortHoliday() {
        this.tableRecords.sort((a, b) => {
            return this.process(a[this.section.sortBy.name]) - this.process(b[this.section.sortBy.name]);
        });
        this.records.sort((a, b) => {
            return this.process(a[this.section.sortBy.name]) - this.process(b[this.section.sortBy.name]);
        });
        this.tableFormArray.reset([]);
        this.tableFormArray.patchValue(this.tableRecords);
    }

    process(fieldValue) {
        if (this.section.sortBy.type === 'date') {
            const parts = fieldValue.split('/');
            return new Date(parts[2], parts[1] - 1, parts[0]).getTime();
        }
        return fieldValue;
    }

    deleteRecord(content) {
        this.modalHandler(content).then(res => { }).catch(err => { });
    }

    modalHandler(content, option = {}) {
        return new Promise((resolve, reject) => {
            this.modalService.open(content, option).result.then((result) => {
                resolve();
            }, (reason) => {
                reject();
            });
        });
    }

    searchCriteria(searchedCriteria) {
        const records = JSON.parse(JSON.stringify(this.tableRecords));
        const keys = Object.keys(searchedCriteria);
        const findIndex = records.findIndex((item) => {
            for (const key in searchedCriteria) {
                if (item[key].toString() !== searchedCriteria[key].toString()) {
                    return false;
                }
            }
            return true;
        });
        if (findIndex > -1) {
            this.tableFormArray.removeAt(findIndex);
            this.tableRecords.splice(findIndex, 1);
            if (findIndex < this.records.length) {
                this.records.splice(findIndex, 1);
            }
            this.modalService.dismissAll();
        }
    }

    matchAllCondition(conditions, record) {
        return new Promise((resolve, reject) => {
            try {
                let conditionMatched = 0;
                const totalConditions = conditions.length;
                conditions.forEach((condition, index) => {
                    if (record[condition.conditionColumnName] === condition.conditionValue) {
                        conditionMatched++;
                    }
                    if (index === (totalConditions - 1)) {
                        if (totalConditions === conditionMatched) {
                            resolve(1);
                        } else {
                            resolve(0);
                        }
                    }
                });
            } catch (error) {
                resolve(0);
            }
        });
    }

    scrollHandler(event) {
        const element = (event.srcElement as Element);
        if (this.records.length < this.tableRecords.length) {
            const scrollPercentage = (element.scrollTop / element.scrollHeight) * 100;
            const screenScroll = (element.clientHeight / element.scrollHeight) * 100;
            const maxScreenScroll = 100 - screenScroll;
            const loadMoreScroll = maxScreenScroll - (maxScreenScroll * 20) / 100;
            if (scrollPercentage >= loadMoreScroll) {
                const moreRecords = this.tableRecords.slice(this.records.length, this.records.length + this.offset);
                this.records = this.records.concat(moreRecords);
            }
        }
    }
}
