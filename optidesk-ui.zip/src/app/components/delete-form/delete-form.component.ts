import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { faCheck, faTimes } from '@fortawesome/free-solid-svg-icons';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CONSTANTS } from 'src/app/shared/constants';
import { ComponentService } from '../component.service';

@Component({
    selector: 'app-delete-form',
    templateUrl: './delete-form.component.html',
    styleUrls: ['./delete-form.component.css']
})
export class DeleteFormComponent implements OnInit {
    @Input() tableData = [];
    @Input() searchBoxConfig;
    @Input() masterData = {};
    @Output() searchCriteria: EventEmitter<any> = new EventEmitter<any>();
    faCheck = faCheck;
    faTimes = faTimes;
    searchBoxGroup: FormGroup;
    searchBoxes = [];
    searchBoxObj = {};
    selectedCriteria = {};
    CONSTANTS = CONSTANTS;
    removeSectionFields;

    constructor(
        private modalService: NgbModal,
        private componentService: ComponentService,
        private formBuilder: FormBuilder,
    ) { }

    ngOnInit(): void {
        this.removeSectionFields = JSON.parse(JSON.stringify(this.searchBoxConfig));
        this.removeSectionFields.fields = [];
        const removeFields = [];
        this.searchBoxConfig.fields.forEach(fieldRow => {
            fieldRow.forEach(column => {
                if (column.hasOwnProperty('isRemoveField') && column.isRemoveField) {
                    removeFields.push(column);
                }
            });
        });
        this.removeSectionFields.fields.push(removeFields);
        this.searchBoxGroup = this.componentService.createFormFields({
            fieldsArray: this.removeSectionFields.fields,
            groupObj: this.formBuilder.group({})
        }, true);
        this.removeSectionFields.fields.forEach(fields => {
            fields.forEach((record, index) => {
                if (record.name && record.option && index === 0) {
                    const dropListData = [];
                    this.tableData.forEach(data => {
                        dropListData.push(data[record.name].toString());
                    });
                    const sortArray = Array.from(new Set(dropListData));
                    this.masterData[record.option] = sortArray;
                } else {
                    this.masterData[record.option] = [];
                }
            });
        });
    }

    setMasterData(event) {
        if (event.field.childKey) {
            if (event.isResetChild) {
                this.masterData[event.field.childKeyOption] = [];
                this.searchBoxGroup.get(event.field.childKey).setValue(null);
            } else {
                const dropListData = [];
                this.tableData.forEach(data => {
                    const dataGroupValue = this.searchBoxGroup.get(event.field.name).value;
                    if (data[event.field.name].toString() === dataGroupValue.toString()) {
                        dropListData.push(data[event.field.childKey].toString());
                    }
                });
                this.masterData[event.field.childKeyOption] = dropListData;
            }
            const mastData = JSON.parse(JSON.stringify(this.masterData));
            this.masterData = {};
            this.masterData = mastData;
        }
    }

    dismissModalFn() {
        this.modalService.dismissAll();
    }

    removeData() {
        this.searchCriteria.emit(this.searchBoxGroup.value);
    }

}
