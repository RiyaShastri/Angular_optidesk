import { Component, OnInit } from '@angular/core';
import { FieldConfig } from '../field.interface';
import { FormGroup } from '@angular/forms';
import { NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { CONSTANTS } from 'src/app/shared/constants';

@Component({
    selector: 'app-timepicker',
    templateUrl: './timepicker.component.html',
    styleUrls: []
})
export class TimepickerComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    time: NgbTimeStruct;
    readOnlyFlag;
    noFieldLabel;
    groupValue = {};
    pageType;
    CONSTANTS = CONSTANTS;

    constructor() {
    }

    ngOnInit(): void {
        const timet: NgbTimeStruct = this.field.value;
        this.field.value = timet;
    }

}
