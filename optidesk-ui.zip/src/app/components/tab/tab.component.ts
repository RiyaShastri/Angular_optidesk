import {
    Component,
    OnInit,
    Input,
    Output,
    EventEmitter,
    ChangeDetectorRef,
    OnChanges,
    AfterViewInit,
    ViewChild,
    HostListener,
} from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { CONSTANTS, DROPDOWN, CUSTOMER_USER_ROLES } from 'src/app/shared/constants';
import { ComponentService } from '../component.service';
import { Router } from '@angular/router';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';

@Component({
    selector: 'app-tab',
    templateUrl: './tab.component.html',
    styles: [],
})
export class TabComponent implements OnInit, OnChanges, AfterViewInit {
    @Input() moduleConfig;
    @Input() pageType;
    @Input() moduleBaseUrl = '';
    @Input() moduleData;
    @Input() masterData: any = {};
    @Input() isTableEditable?= false;
    @Output() tabOutput?: EventEmitter<any> = new EventEmitter<any>();

    @ViewChild('form') form: NgForm;
    mainForm: FormGroup;
    activeTab = 0;
    searchedCriteria = {};
    CONSTANTS = CONSTANTS;
    renderPage = true;
    customerUserRoles = CUSTOMER_USER_ROLES;
    formSubmitted = false;
    displayLoader = false;

    constructor(
        private cdr: ChangeDetectorRef,
        private router: Router,
        private componentService: ComponentService,
        private planningDataService: PlanningDataService
    ) { }

    ngOnInit(): void {
        if (
            this.moduleConfig.search &&
            !this.moduleConfig.search.editExternal &&
            (this.moduleData.hasOwnProperty('srcFlg') && this.moduleData.srcFlg === 'E') &&
            this.pageType === CONSTANTS.EDIT
        ) {
            this.renderPage = false;
            this.componentService.displayEditExternalError.emit(true);
        }
        this.mainForm = this.planningDataService.createMainFormGroup(
            this.moduleConfig
        );
        for (const dropDownKey in DROPDOWN) {
            if (DROPDOWN.hasOwnProperty(dropDownKey)) {
                this.masterData[dropDownKey] = DROPDOWN[dropDownKey];
            }
        }
    }

    ngOnChanges(changes) {
        if (changes.hasOwnProperty('resetForm')) {
            if (changes.resetForm.currentValue) {
                this.mainForm.reset();
            }
        }
    }

    sectionData(data) {
        this.moduleData[data.tableName] = data.tableData;
    }

    submitForm() {
        this.formSubmitted = true;
        this.planningDataService.displayPopup(
            'info',
            'MESSAGE.SAVE_CHANGES',
            'MESSAGE.DO_YOU_WANT_TO_SAVE_CHANGES', '', {}, true
        ).toPromise().then(close => {
            this.submit();
        }).catch(dismiss => {
        });
    }

    submit() {
        this.displayLoader = true;
        let obj;
        const tblName = this.moduleConfig.tabs[0].tblName;
        const moduleName = this.moduleConfig.moduleName;
        if (moduleName === 'CAAP_USER') {
            const roleArray = [];
            const object = this.mainForm.value;
            this.customerUserRoles.some(item => {
                if (Object.keys(object[tblName][0]).includes(item) && object[tblName][0][item] === true) {
                    roleArray.push(item);
                }
                delete object[tblName][0][item];
            });
            object[tblName][0].roles = roleArray;
            obj = object;
        } else {
            obj = this.mainForm.value;
        }
        this.planningDataService.performAction(this.moduleConfig.moduleName, this.pageType, obj).then(res => {
            if (res) {
                this.displayLoader = false;
                this.mainForm.markAsUntouched();
                this.router.navigateByUrl(this.moduleBaseUrl);
            } else {
                this.displayLoader = false;
                this.formSubmitted = false;
            }
        }).catch(err => {
            this.displayLoader = false;
            this.formSubmitted = false;
        });
    }

    ngAfterViewInit() {
        this.cdr.detectChanges();
    }

    @HostListener('window:beforeunload', ['$event'])
    @HostListener('window:popstate', ['$event'])
    unloadHandler(event) {
        if (this.mainForm && !this.mainForm.untouched) {
            const confirmationMessage = 'o/';
            event.returnValue = confirmationMessage;
            return confirmationMessage;
        } else {
            return true;
        }
    }
}
