import { Injectable, EventEmitter } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { DatePipe } from '@angular/common';
import { ENCRYPT_KEY } from 'src/app/shared/constants';
import * as CryptoJS from 'crypto-js';
import { CreateFormFields } from './field.interface';

@Injectable({
    providedIn: 'root'
})
export class ComponentService {
    displayEditExternalError = new EventEmitter(false);
    constructor(
        private fb: FormBuilder,
        private http: HttpClient,
        private datePipe: DatePipe
    ) { }

    createFormFields(fieldConfig: CreateFormFields, applySearchValidation = false) {
        fieldConfig.fieldsArray.forEach(fieldsRow => {
            fieldsRow.forEach(field => {
                field.value = (fieldConfig.fieldValue && fieldConfig.fieldValue[field.valueKey]) || null;
                if (field.fieldType === 'createdOn' && !field.value) {
                    field.value = this.datePipe.transform(new Date(), 'd/M/yyyy');
                }
                if (field.fieldType === 'changedOn' && field.value !== '' && field.value !== null) {
                    field.value = this.datePipe.transform(new Date(), 'd/M/yyyy');
                }
                if (field.type === 'button' || field.type === 'blank') {
                    return;
                }
                if (field.type === 'select') {
                    field.options = (fieldConfig.masterData && fieldConfig.masterData[field.option]) || [];
                }
                if (!fieldConfig.groupObj.contains(field.name)) {
                    const control = this.fb.control(
                        field.value,
                        this.bindValidations(field[(applySearchValidation ? 'searchValidations' : 'validations')] || [])
                    );
                    fieldConfig.groupObj.addControl(field.name, control);
                } else {
                    fieldConfig.groupObj.get(field.name).setValue(field.value);
                }
            });
        });
        return fieldConfig.groupObj;
    }

    bindValidations(validations: any) {
        if (validations.length > 0) {
            const validList = [];
            validations.forEach(valid => {
                validList.push(valid.validator);
            });
            return Validators.compose(validList);
        }
        return null;
    }

    fillDropDownOption(reqObj) {
        const url = '/api/commons/_dropdown-options';
        if (reqObj.tableName === 'customers' || reqObj.tableName === 'USERS') {
            const httpOptions = {
                headers: new HttpHeaders({
                    isAuthAPI: 'true'
                }),
            };
            return this.http.post<any>(url, this.renameKeys(ENCRYPT_KEY, reqObj), httpOptions);
        } else {
            return this.http.post<any>(url, this.renameKeys(ENCRYPT_KEY, reqObj));
        }
    }

    renameKeys(keysMap, obj) {
        return Object.keys(obj).reduce((acc, key) => {
            if (Array.isArray(obj[key])) {
                obj[key].forEach((childObj, index) => {
                    obj[key][index] = this.renameKeys(keysMap, childObj);
                });
            } else if (typeof obj[key] === 'object') {
                obj[key] = this.renameKeys(keysMap, obj[key]);
            } else if (typeof obj[key] === 'string' || typeof obj[key] === 'number') {
                obj[key] = this.encryptText(obj[key]);
            }
            const renamedObject = {
                [keysMap[key] || key]: obj[key]
            };
            return {
                ...acc,
                ...renamedObject
            };
        }, {});
    }

    encryptText(plainText) {
        const temp = [];
        const initVector = CryptoJS.enc.Utf8.parse(environment.AES_initVectorStr);
        const keyUtf8 = CryptoJS.enc.Utf8.parse(environment.AES_key);
        let t;
        if (typeof plainText === 'object') {
            plainText.forEach(text => {
                t = CryptoJS.AES.encrypt(text, keyUtf8, {
                    iv: initVector
                });
                temp.push(t.ciphertext.toString(CryptoJS.enc.Base64));
            });
            return temp;
        } else {
            t = CryptoJS.AES.encrypt(plainText, keyUtf8, {
                iv: initVector
            });
            return t.ciphertext.toString(CryptoJS.enc.Base64);
        }
    }

    decryptText(encodedText) {
        const temp = [];
        const initVector = CryptoJS.enc.Utf8.parse(environment.AES_initVectorStr);
        const keyUtf8 = CryptoJS.enc.Utf8.parse(environment.AES_key);
        let t;
        if (typeof encodedText === 'object') {
            encodedText.forEach(text => {
                t = CryptoJS.AES.decrypt(text, keyUtf8, {
                    iv: initVector
                });
                temp.push(t.toString(CryptoJS.enc.Utf8));
            });
            return temp;
        } else {
            t = CryptoJS.AES.decrypt(encodedText, keyUtf8, {
                iv: initVector
            });
            return t.toString(CryptoJS.enc.Utf8);
        }

    }

}
