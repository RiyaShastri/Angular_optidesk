import { Component, OnInit, ViewChild, Injectable } from '@angular/core';
import { FieldConfig } from '../field.interface';
import { FormGroup, FormArray } from '@angular/forms';
import { NgbDatepicker, NgbDateStruct, NgbDateAdapter, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';

@Injectable()
export class CustomAdapter extends NgbDateAdapter<string> {
    readonly DELIMITER = '/';

    fromModel(value: string | null): NgbDateStruct | null {
        if (value) {
            const date = value.split(this.DELIMITER);
            return {
                day: parseInt(date[0], 10),
                month: parseInt(date[1], 10),
                year: parseInt(date[2], 10)
            };
        }
        return null;
    }

    toModel(date: NgbDateStruct | null): string | null {
        return date ? date.day + this.DELIMITER + date.month + this.DELIMITER + date.year : null;
    }
}

@Injectable()
export class CustomDateParserFormatter extends NgbDateParserFormatter {

    readonly DELIMITER = '/';

    parse(value: string): NgbDateStruct | null {
        if (value) {
            const date = value.split(this.DELIMITER);
            return {
                day: parseInt(date[0], 10),
                month: parseInt(date[1], 10),
                year: parseInt(date[2], 10)
            };
        }
        return null;
    }

    format(date: NgbDateStruct | null): string {
        return date ? date.day + this.DELIMITER + date.month + this.DELIMITER + date.year : '';
    }
}

@Component({
    selector: 'app-datepicker',
    templateUrl: './datepicker.component.html',
    styles: [
    ],
    providers: [
        { provide: NgbDateAdapter, useClass: CustomAdapter },
        { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter }
    ]
})
export class DatepickerComponent implements OnInit {
    @ViewChild(NgbDatepicker) d: NgbDatepicker;
    field: FieldConfig;
    group: FormGroup;
    minDate: NgbDateStruct;
    maxDate: NgbDateStruct;
    constructor() { }
    ngOnInit(): void {
        let minYear = '1980';
        let maxYear = '2040';
        if (this.field.hasOwnProperty('datePickerConfig')) {
            const parentForm = this.group.parent.parent;
            const yearFromField = this.field.datePickerConfig.yearFrom;
            const yearFromFieldObj = yearFromField.split('.');
            const yearFrom = (parentForm.get(yearFromFieldObj[0]) as FormArray).at(0).get(yearFromFieldObj[1]).value.toString();
            if (yearFrom !== '' && yearFrom.length === 4) {
                minYear = yearFrom;
            }
            const yearTillField = this.field.datePickerConfig.yearTill;
            const yearTillFieldObj = yearTillField.split('.');
            const yearTill = (parentForm.get(yearTillFieldObj[0]) as FormArray).at(0).get(yearTillFieldObj[1]).value.toString();
            if (yearTill !== '' && yearTill.length === 4) {
                maxYear = yearTill;
            }
        }
        this.minDate = { year: Number.parseInt(minYear, 0), month: 1, day: 1 };
        this.maxDate = { year: Number.parseInt(maxYear, 0), month: 12, day: 31 };

    }

}
