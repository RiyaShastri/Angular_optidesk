import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../field.interface';
import { CURRENCY_NUMBER_MASK } from 'src/app/shared/constants';
import createNumberMask from 'text-mask-addons/dist/createNumberMask';

@Component({
    selector: 'app-input',
    templateUrl: './input.component.html',
    styles: []
})

export class InputComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    noFieldLabel;
    textMask;
    constructor() {
    }
    ngOnInit() {
        this.textMask = createNumberMask(CURRENCY_NUMBER_MASK[this.field.inputMaskType]);
    }

    setValue(value) {
        if (value * 1) {
            this.group.get(this.field.name).setValue(value * 1);
        }
    }
}
