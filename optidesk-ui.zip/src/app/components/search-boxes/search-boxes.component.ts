import { Component, OnInit, Input, Output, EventEmitter, OnChanges, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ComponentService } from '../component.service';
import { faCheck, faTimes } from '@fortawesome/free-solid-svg-icons';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { DROPDOWN, CONSTANTS, ENCRYPT_KEY, tLanesDefaultPayLoad, LANE_TYPES } from 'src/app/shared/constants';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';

@Component({
    selector: 'app-search-boxes',
    templateUrl: './search-boxes.component.html',
    styles: []
})
export class SearchBoxesComponent implements OnInit, OnChanges {
    @Input() searchBoxConfig;
    @Input() moduleConfig: any = {};
    @Input() pageType;
    @Input() resetForm;
    @Input() toasts = [];
    @Input() primaryData = {};
    @Input() dropDownRecords = [];
    @Input() isCreateDropList?= false;
    @Output() searchCriteria: EventEmitter<any> = new EventEmitter<any>();
    // tslint:disable-next-line: no-output-native
    @Output() reset: EventEmitter<any> = new EventEmitter<any>();

    faCheck = faCheck;
    faTimes = faTimes;
    searchBoxGroup: FormGroup;
    typeaheadObj = {};
    searchBoxes = [];
    searchBoxObj = {};
    selectedCriteria = {};
    disableSelection = false;
    displayToast = false;
    editExternalError = false;
    CONSTANTS = CONSTANTS;
    isReset = false;
    firstAPICalled = false;
    customDropDownOptions = DROPDOWN;
    isCustomSearch = false;
    isTransportationLanes = false;
    selectedLaneType;

    constructor(
        private formBuilder: FormBuilder,
        private cdRef: ChangeDetectorRef,
        private modalService: NgbModal,
        private componentService: ComponentService,
        private planningDataService: PlanningDataService,
        private router: Router
    ) {
        this.isTransportationLanes = this.router.url.includes('transportation-lanes');
    }

    ngOnInit(): void {
        if (this.pageType === CONSTANTS.EDIT) {
            this.componentService.displayEditExternalError.subscribe(x => {
                this.editExternalError = x;
                this.cdRef.detectChanges();
            });
        }
        this.createSearchBoxes();
    }

    ngOnChanges(changes) {
        if (changes.hasOwnProperty('resetForm')) {
            if (changes.resetForm.currentValue) {
                this.resetSearch();
            }
        }
    }

    createSearchBoxes() {
        this.searchBoxGroup = this.componentService.createFormFields({
            fieldsArray: this.searchBoxConfig.fields,
            groupObj: this.formBuilder.group({})
        });
        if (this.pageType !== CONSTANTS.CREATE || this.isCreateDropList || this.isTransportationLanes) {
            this.searchBoxConfig.fields.forEach((searchFieldRow) => {
                searchFieldRow.forEach((searchField) => {
                    if (!this.searchBoxes.includes(searchField.name) && searchField.hasOwnProperty('childKey')) {
                        this.searchBoxes.push(searchField.name);
                        this.searchBoxObj[searchField.name] = {
                            options: [],
                            filteredRecords: [],
                            filterValue: null,
                            apiReqObj: this.createReqObj(searchField),
                            selectFromList: false,
                            ngSelectInstance: null,
                            readOnly: true,
                            loading: false,
                            parentColumn: searchField.requestedColumnParentColumn ? searchField.requestedColumnParentColumn : '',
                            customColumnName: searchField.customColumnName ? searchField.customColumnName : '',
                            searchTableName: searchField.searchTableName ? searchField.searchTableName : ''
                        };
                        if (!this.firstAPICalled && searchField.fieldType !== 'primary' && !searchField.customOption) {
                            this.firstAPICalled = true;
                            this.fillDropDown(this.searchBoxObj[searchField.name].apiReqObj);
                        } else {
                            if (!this.firstAPICalled && searchField.fieldType !== 'primary' && searchField.customOption) {
                                this.firstAPICalled = true;
                                this.searchBoxObj[searchField.name].options = this.customDropDownOptions[searchField.customOption];
                                this.searchBoxObj[searchField.name].filteredRecords = this.customDropDownOptions[searchField.customOption];
                                this.searchBoxObj[searchField.name].readOnly = false;
                                this.searchBoxObj[searchField.name].loading = false;
                            }
                        }
                    }
                });
            });
        }
    }

    fillDropDown(reqObj, isFieldName?) {
        const fieldName = isFieldName ? isFieldName : reqObj.columnName;
        this.searchBoxObj[fieldName].loading = true;
        const reqObjClone = JSON.parse(JSON.stringify(reqObj));
        for (const key in this.primaryData) {
            if (this.primaryData.hasOwnProperty(key)) {
                reqObjClone.conditions.push({
                    conditionColumnName: key,
                    conditionValue: this.primaryData[key]
                });
            }
        }
        if (this.dropDownRecords.length > 0) {
            // Fill dropdown options from the available records
            this.getOptions(reqObjClone).then(options => {
                this.searchBoxObj[fieldName].options = options;
                this.searchBoxObj[fieldName].filteredRecords = options;
                this.searchBoxObj[fieldName].readOnly = false;
                this.searchBoxObj[fieldName].loading = false;
            });
        } else {
            // Fill dropdown options using API response
            this.componentService.fillDropDownOption(reqObjClone).toPromise().then(options => {
                this.searchBoxObj[fieldName].options = options;
                this.searchBoxObj[fieldName].filteredRecords = options;
                this.searchBoxObj[fieldName].readOnly = false;
                this.searchBoxObj[fieldName].loading = false;
            }).catch(err => {
                this.searchBoxObj[fieldName].options = [];
                this.searchBoxObj[fieldName].filteredRecords = [];
                this.searchBoxObj[fieldName].readOnly = false;
                this.searchBoxObj[fieldName].loading = false;
            });
        }
    }

    getOptions(reqObjClone) {
        return new Promise((resolve, reject) => {
            try {
                const options = [];
                this.dropDownRecords.forEach((record, index) => {
                    let conditionTrue = 0;
                    reqObjClone.conditions.forEach(condition => {
                        const columnName = condition.conditionColumnName;
                        const columnValue = condition.conditionValue;
                        if (record[columnName] === columnValue) {
                            conditionTrue++;
                        }
                        if (reqObjClone.conditions.length === conditionTrue) {
                            options.push(record[reqObjClone.columnName]);
                        }
                        if (index === (this.dropDownRecords.length - 1)) {
                            resolve(options);
                        }
                    });
                });
            } catch (error) {
                resolve([]);
            }
        });
    }

    filterRecords(searchTerm, fieldName, fieldObj) {
        if (searchTerm) {
            if (fieldObj.isOjectOption) {
                this.searchBoxObj[fieldName].filteredRecords = this.searchBoxObj[fieldName].options.
                    filter(option => option[fieldObj.bindLabel].toLowerCase().includes(searchTerm.toLowerCase()));
            } else {
                this.searchBoxObj[fieldName].filteredRecords = this.searchBoxObj[fieldName].options.
                    filter(option => option.toLowerCase().includes(searchTerm.toLowerCase()));
            }
        } else {
            this.searchBoxObj[fieldName].filteredRecords = JSON.parse(JSON.stringify(this.searchBoxObj[fieldName].options));
        }
    }

    onOpen(select, fieldName, fieldObj) {
        this.searchBoxObj[fieldName].ngSelectInstance = select;
        this.filterRecords(this.searchBoxObj[fieldName].filterValue, fieldName, fieldObj);
    }

    // Function will be called when user tries to search options
    onSearch(select, fieldName, fieldObj) {
        if (this.searchBoxGroup.get(fieldName).value) {
            this.resetChildTypehead(fieldName);
        }
        this.searchBoxGroup.get(fieldName).setValue(null);
        // this.searchBoxObj[fieldName].filterValue = event['target']['value'];
        this.searchBoxObj[fieldName].filterValue = select.searchTerm;
        this.filterRecords(this.searchBoxObj[fieldName].filterValue, fieldName, fieldObj);
    }

    // Function will be called when option is selected from the list
    onSelection(select, fieldObj) {
        let selectedValue;
        if (fieldObj.isOjectOption) {
            selectedValue = select.selectedItems[0].value[fieldObj.bindValue].trim();
            this.searchBoxObj[fieldObj.name].filterValue = select.selectedItems[0].value[fieldObj.bindLabel].trim();
        } else {
            selectedValue = select.selectedItems[0].value.trim();
            this.searchBoxObj[fieldObj.name].filterValue = select.selectedItems[0].value.trim();
        }
        this.searchBoxObj[fieldObj.name].selectFromList = false;
        this.optionSelected(selectedValue, fieldObj);
    }

    // Function will be called when user change the focus of dropdown
    onBlur(select, fieldObj) {
        select.searchTerm = this.searchBoxObj[fieldObj.name].filterValue;
        if (this.searchBoxObj[fieldObj.name].filterValue) {
            let data = [];
            if (fieldObj.isOjectOption) {
                data = this.searchBoxObj[fieldObj.name].filteredRecords.
                    filter(option => option[fieldObj.bindLabel].trim() === this.searchBoxObj[fieldObj.name].filterValue);
            } else {
                data = this.searchBoxObj[fieldObj.name].filteredRecords.
                    filter(option => option.trim() === this.searchBoxObj[fieldObj.name].filterValue);
            }
            if (data.length === 1) {
                this.searchBoxObj[fieldObj.name].selectFromList = false;
                if (fieldObj.isOjectOption) {
                    this.optionSelected(data[0][fieldObj.bindValue], fieldObj);
                } else {
                    this.optionSelected(data[0], fieldObj);
                }
            } else {
                this.searchBoxGroup.get(fieldObj.name).setValue(null);
            }
        }
        if (
            this.searchBoxObj[fieldObj.name].filterValue &&
            this.searchBoxObj[fieldObj.name].filteredRecords.length > 0 &&
            !this.searchBoxGroup.value[fieldObj.name]
        ) {
            this.searchBoxObj[fieldObj.name].selectFromList = true;
        }
    }

    optionSelected(selectedOption, fieldObj) {
        this.searchBoxGroup.get(fieldObj.name).setValue(selectedOption);
        if (fieldObj.childKey !== '' && !fieldObj.isCustomSearch) {
            const reqObj = JSON.parse(JSON.stringify(this.searchBoxObj[fieldObj.childKey].apiReqObj));
            if (fieldObj && fieldObj.isChangeMainTableName) {
                reqObj.tableName = fieldObj.mainTableName;
            }
            reqObj.conditions.forEach(conditionObj => {
                conditionObj.conditionValue = this.searchBoxGroup.value[conditionObj.conditionColumnName];
            });
            if (this.searchBoxObj[fieldObj.childKey] && this.searchBoxObj[fieldObj.childKey].options.length === 0) {
                this.fillDropDown(reqObj);
            }
        } else {
            if (fieldObj.isCustomSearch) {
                this.isCustomSearch = true;
                let index;
                let nextObject;
                let customKey;
                this.searchBoxConfig.fields.forEach((searchFieldRow, i) => {
                    customKey = searchFieldRow.filter(x => x.customOption && x.customOption !== '')[0].name;
                    index = searchFieldRow.findIndex(x => x.name === fieldObj.name);
                    nextObject = searchFieldRow[index + 1];
                    if (customKey) {
                        this.selectedLaneType = this.searchBoxGroup.get(customKey).value;
                    }
                });
                if (nextObject) {
                    const reqObj = JSON.parse(JSON.stringify(this.searchBoxObj[fieldObj.childKey].apiReqObj));
                    if (nextObject.customColumnName) {
                        reqObj.columnName = nextObject.customColumnName;
                    }
                    if (this.pageType === CONSTANTS.CREATE) {
                        reqObj.conditions.forEach(conditionObj => {
                            conditionObj.conditionValue = nextObject.customFillDropOption[this.selectedLaneType];
                        });
                    } else {
                        reqObj.conditions.forEach(conditionObj => {
                            conditionObj.conditionValue = this.searchBoxGroup.value[conditionObj.conditionColumnName];
                            if (nextObject && nextObject.isChangeColumnName && fieldObj.name === conditionObj.conditionColumnName) {
                                conditionObj.conditionColumnName = nextObject.customColumnName;
                            }
                        });
                    }
                    if (this.searchBoxObj[fieldObj.childKey] && this.searchBoxObj[fieldObj.childKey].options.length === 0) {
                        this.fillDropDown(reqObj, fieldObj.childKey);
                    }
                }
            }
        }
    }

    createReqObj(searchField) {
        const reqObj: any = {
            tableName: this.searchBoxConfig.tblName,
            columnName: searchField.name,
            conditions: []
        };
        searchField.parentKeys.forEach((parentKey, index) => {
            const conditionObj: any = {};
            conditionObj.conditionColumnName = parentKey;
            conditionObj.conditionValue = this.searchBoxGroup.value[parentKey];
            if (searchField.childTableKey && searchField.childTableKey[index]) {
                conditionObj.conditionTableName = searchField.childTableKey[index];
            }
            if (searchField.parentColumn && searchField.parentColumn[index]) {
                conditionObj.parentColumn = searchField.parentColumn[index];
            }
            if (searchField.mainTableForeignKeys && searchField.mainTableForeignKeys[index]) {
                conditionObj.mainTableForeignKey = searchField.mainTableForeignKeys[index];
            }
            reqObj.conditions.push(conditionObj);
        });
        if (searchField && searchField.requestedColumnParentTable &&
            searchField.requestedColumnParentColumn) {
            reqObj.requestedColumnParentTable = searchField.requestedColumnParentTable;
            reqObj.requestedColumnParentColumn = searchField.requestedColumnParentColumn;
        }
        if (searchField && searchField.requestedTableForeignKey) {
            reqObj.requestedTableForeignKey = searchField.requestedTableForeignKey;
        }
        return reqObj;
    }

    resetChildTypehead(fieldKey) {
        const fieldIndex = this.searchBoxes.indexOf(fieldKey);
        const childTypeheads = this.searchBoxes.slice(fieldIndex + 1);
        const formValue = this.searchBoxGroup.value;
        formValue[fieldKey] = formValue[fieldKey] || null;
        childTypeheads.forEach(childTypehead => {
            formValue[childTypehead] = null;
            this.searchBoxObj[childTypehead].options = [];
            this.searchBoxObj[childTypehead].filteredRecords = [];
            this.searchBoxObj[childTypehead].readOnly = true;
            this.searchBoxObj[childTypehead].filterValue = null;
            this.searchBoxObj[childTypehead].selectedItems = false;
            if (this.searchBoxObj[childTypehead].ngSelectInstance && this.searchBoxObj[childTypehead].ngSelectInstance.searchTerm) {
                this.searchBoxObj[childTypehead].ngSelectInstance.searchTerm = null;
            }
        });
        this.searchBoxGroup.setValue(formValue);
    }

    submit() {
        this.toasts = [];
        this.selectedCriteria = JSON.parse(JSON.stringify(this.searchBoxGroup.value));
        let customKey;
        let tblName = (this.isCustomSearch && this.pageType === CONSTANTS.CREATE) ?
        this.searchBoxObj[customKey].searchTableName : this.searchBoxConfig.tblName;
        if (this.isCustomSearch) {
            this.searchBoxConfig.fields.forEach(searchRow => {
                customKey = searchRow.filter(x => x.customOption && x.customOption !== '')[0].name;
            });
        }
        let selectedCriteriaObj: any = {
            tableName: (this.isCustomSearch && this.pageType === CONSTANTS.CREATE) ?
                this.searchBoxObj[customKey].searchTableName : this.searchBoxConfig.tblName,
            conditions: []
        };
        this.selectedCriteria = this.jsonConcat(this.selectedCriteria, this.primaryData);
        for (const key in this.selectedCriteria) {
            if (this.selectedCriteria.hasOwnProperty(key)) {
                const conditionsObj: any = {
                    conditionColumnName: (this.isCustomSearch && key !== customKey) ? this.searchBoxObj[key].customColumnName : key,
                    conditionValue: this.selectedCriteria[key]
                };
                if (this.isCustomSearch && key !== customKey) {
                    conditionsObj.conditionTableName = this.searchBoxObj[key].apiReqObj.tableName;
                    conditionsObj.mainTableForeignKey = this.searchBoxObj[key].apiReqObj.requestedTableForeignKey;
                    conditionsObj.parentColumn = this.searchBoxObj[key].parentColumn;
                }
                if (
                    this.pageType !== CONSTANTS.CREATE &&
                    this.searchBoxObj[key].apiReqObj.requestedColumnParentColumn &&
                    this.searchBoxObj[key].apiReqObj.requestedColumnParentTable) {
                    conditionsObj.parentColumn = this.searchBoxObj[key].apiReqObj.requestedColumnParentColumn;
                    conditionsObj.conditionTableName = this.searchBoxObj[key].apiReqObj.requestedColumnParentTable;
                }
                if (this.pageType !== CONSTANTS.CREATE && this.isCreateDropList) {
                    const isParentTableExist = this.searchBoxObj[key].apiReqObj.conditions
                        .find(x => x.conditionTableName !== 'undefined');
                    if (isParentTableExist) {
                        selectedCriteriaObj.tableName = this.searchBoxObj[key].searchTableName;
                        const selectedCriteriaIndex = selectedCriteriaObj.conditions
                            .findIndex(x => x.conditionColumnName === isParentTableExist.conditionColumnName);
                        if (selectedCriteriaIndex > -1) {
                            selectedCriteriaObj.conditions[selectedCriteriaIndex].parentColumn = this.searchBoxObj[key]
                                .apiReqObj.conditions[selectedCriteriaIndex].parentColumn;
                            selectedCriteriaObj.conditions[selectedCriteriaIndex].conditionTableName = this.searchBoxObj[key].apiReqObj
                                .conditions[selectedCriteriaIndex].conditionTableName;
                        }
                    }
                }
                selectedCriteriaObj.conditions.push(conditionsObj);
            }
        }
        // && this.pageType !== CONSTANTS.VIEW
        this.disableSelection = true;
        if (((this.pageType !== CONSTANTS.CREATE && this.isCreateDropList) ||
            (this.pageType === CONSTANTS.CREATE && !this.isCreateDropList) || !this.isCreateDropList)) {
            selectedCriteriaObj = this.componentService.renameKeys(ENCRYPT_KEY, selectedCriteriaObj);
            let moduleData: any = {};
            if (this.pageType === CONSTANTS.CREATE) {
                this.planningDataService.checkRecordExists(selectedCriteriaObj, tblName).toPromise().then(res => {
                    if (res['message'] === 'true') {
                        this.toasts = [{
                            type: 'danger',
                            message: 'VALIDATION_MESSAGE.' + (this.searchBoxConfig.recordExists || '')
                        }];
                        this.resetSearch();
                    } else {
                        moduleData = this.planningDataService.createFreshModuleData(this.moduleConfig);
                        moduleData.primaryData = this.selectedCriteria;
                        if (this.isTransportationLanes) {
                            const primaryData = Object.assign({}, this.selectedCriteria);
                            moduleData.transportationModes.push(Object.assign(primaryData, tLanesDefaultPayLoad));
                        }
                        this.searchCriteria.emit(moduleData);
                    }
                }).catch(err => { });
            } else {
                this.planningDataService.searchRecord(
                    this.moduleConfig.moduleName, selectedCriteriaObj[ENCRYPT_KEY.conditions]
                ).toPromise().then(res => {
                    moduleData = res;
                    moduleData.primaryData = this.selectedCriteria;
                    this.searchCriteria.emit(res);
                }).catch(err => { });
            }
        } else {
            if (this.isCreateDropList) {
                let moduleData: any = {};
                moduleData = this.planningDataService.createFreshModuleData(this.moduleConfig);
                moduleData.primaryData = this.selectedCriteria;
                moduleData.capacityValidates.push(moduleData.primaryData);
                this.searchCriteria.emit(moduleData);
            } else {
                const searchedCriteria = {
                    selectedCriteria: this.selectedCriteria,
                    selectedCriteriaObj
                };
                this.searchCriteria.emit(searchedCriteria);
            }
        }
    }

    jsonConcat(o1, o2) {
        for (const key in o2) {
            if (o2.hasOwnProperty(key)) {
                o1[key] = o2[key];
            }
        }
        return o1;
    }

    resetSearch() {
        if (this.isReset && this.pageType !== CONSTANTS.VIEW &&
            this.searchBoxGroup.valid && !this.editExternalError && this.disableSelection) {
            return this.planningDataService.displayPopup(
                'info', 'MESSAGE.DISCARD_CHANGE_TITLE', 'MESSAGE.DO_YOU_WANT_TO_CANCEL_OPERATION', '', {}, true)
                .toPromise().then(close => {
                    this.doReset();
                }).catch(dismiss => {
                    this.isReset = false;
                    return false;
                });
        } else {
            this.doReset();
        }
    }

    doReset() {
        this.searchBoxGroup.reset();
        this.disableSelection = false;
        this.editExternalError = false;
        this.searchBoxes.forEach((searchBox, index) => {
            this.searchBoxObj[searchBox].filterValue = null;
            if (this.searchBoxObj[searchBox].ngSelectInstance) {
                this.searchBoxObj[searchBox].ngSelectInstance.searchTerm = null;
            }
            if (index !== 0) {
                this.searchBoxObj[searchBox].options = [];
            }
            this.searchBoxObj[searchBox].filteredRecords = [];
            this.searchBoxObj[searchBox].selectFromList = false;
            this.searchBoxObj[searchBox].readOnly = index !== 0 ? true : false;
        });
        this.reset.emit();
        this.isReset = false;
        return true;
    }

    closeToast(alertNo) {
        this.toasts.splice(alertNo, 1);
    }

    dismissModalFn() {
        this.modalService.dismissAll();
    }
}
