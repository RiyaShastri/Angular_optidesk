import { Component, EventEmitter, Input, OnInit, Output, OnChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ComponentService } from '../component.service';
import { faTimes, faCheck } from '@fortawesome/free-solid-svg-icons';
import { CONSTANTS } from 'src/app/shared/constants';

@Component({
    exportAs: 'dynamicForm',
    // tslint:disable-next-line:component-selector
    selector: 'dynamic-form',
    templateUrl: './dynamic-form.component.html',
    styles: []
})
export class DynamicFormComponent implements OnInit, OnChanges {
    @Input() primaryData;
    @Input() fields = [];
    @Input() fieldValue = [];
    @Input() masterData = {};
    @Input() pageType = CONSTANTS.VIEW;
    @Input() tblName;
    @Input() fromGroupObj: FormGroup;
    @Input() initFormObject = true;
    @Input() lessFields = false;
    @Input() isTableEditable;
    // tslint:disable-next-line:no-output-native
    @Output() submit?: EventEmitter<any> = new EventEmitter<any>();
    CONSTANTS = CONSTANTS;
    faTimes = faTimes;
    faCheck = faCheck;
    form: FormGroup;
    formId = Math.random();

    constructor(
        private componentService: ComponentService
    ) { }

    ngOnInit() {
        if (this.initFormObject) {
            this.form = this.componentService.createFormFields({
                fieldsArray: this.fields,
                masterData: this.masterData,
                groupObj: this.fromGroupObj,
                fieldValue: this.fieldValue[0] || this.primaryData
            });
        } else {
            this.form = this.fromGroupObj;
        }
    }

    ngOnChanges(changes) {
        if (changes.hasOwnProperty('fieldValue')) {
            if (this.initFormObject) {
                this.form = this.componentService.createFormFields({
                    fieldsArray: this.fields,
                    masterData: this.masterData,
                    groupObj: this.fromGroupObj,
                    fieldValue: this.fieldValue[0] || this.primaryData
                });
            } else {
                this.form = this.fromGroupObj;
            }
        }

        if (changes.hasOwnProperty('fields')) {
            this.fields = [];
            this.fields = changes.fields.currentValue;
        }
        if (changes.hasOwnProperty('masterData')) {
            this.masterData = {};
            this.masterData = changes.masterData.currentValue;
        }
    }

    onSubmit(event: Event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.form.valid) {
            this.submit.emit(this.form);
        } else {
            this.validateAllFormFields(this.form);
        }
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            control.markAsTouched({ onlySelf: true });
        });
    }
}
