import { Component, OnInit, Input, OnChanges, OnDestroy, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
    selector: 'app-section',
    templateUrl: './section.component.html',
    styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit, OnChanges, OnDestroy {
    @Input() tabConfig;
    @Input() tabData;
    @Input() masterData;
    @Input() pageType;
    @Input() mainFromGroupObj;
    @Input() primaryData;
    @Input() isTableEditable;
    @Output() sectionData: EventEmitter<any> = new EventEmitter<any>();
    fromGroupObj: FormGroup;

    constructor() {
    }

    ngOnInit() {
        if (this.tabConfig.tabView === 'SECTION') {
            this.fromGroupObj = this.mainFromGroupObj.get(this.tabConfig.tblName).controls[0];
        }
    }

    ngOnChanges(changes) {
        if (changes.hasOwnProperty('pageType')) {
            this.pageType = changes.pageType.currentValue;
        }
    }

    ngOnDestroy() {
        if (this.tabConfig.tabView === 'SECTION') {
            this.tabData = (this.mainFromGroupObj.get(this.tabConfig.tblName) as FormGroup).value;
            const sectionDataObj = {
                tableName: this.tabConfig.tblName,
                tableData: this.tabData
            };
            this.sectionData.emit(sectionDataObj);
        }
    }

}
