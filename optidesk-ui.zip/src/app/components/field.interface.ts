import { FormGroup } from '@angular/forms';

export interface Validator {
    name: string;
    validator: any;
    message: string;
    messageParam: any;
}
export interface DatePickerConfig {
    yearFrom: string;
    yearTill: string;
}
export interface FieldConfig {
    label: string;
    name: string;
    value?: any;
    valueKey: string;
    type: string;
    inputType?: string;
    inputMaskType?: string;
    option?: string;
    options?: string[];
    isEditable?: boolean;
    width?: string;
    validations?: Validator[];
    datePickerConfig?: DatePickerConfig;
    fieldType?: any;
    recordExists?: string;
    isEditableInTable?: boolean;
    isFillChildDropList?: boolean;
    masterDataKey?: string;
    reqObj?: any;
    childKey?: string;
    childKeyOption?: string;
}
export interface CreateFormFields {
    fieldsArray: any[];
    masterData?: {};
    groupObj: FormGroup;
    fieldValue?: {};
}
