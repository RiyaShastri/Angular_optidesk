
import { Component, OnInit, OnDestroy, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
// import { PlanningDataService } from 'projects/data-management/src/app/planning-data/planning-data.service';
import { FieldConfig } from '../field.interface';

@Component({
    selector: 'app-select',
    templateUrl: './select.component.html',
    styles: []
})

export class SelectComponent implements OnInit, OnChanges, OnDestroy {
    @Input() groupName;
    @Input() fieldObj;
    @Input() masterData;
    @Input() isRemoveData = false;
    @Input() tableRecord = [];
    @Output() selectedValue: EventEmitter<any> = new EventEmitter<any>();
    noFieldLabel;
    field: FieldConfig;
    group: FormGroup;
    searchBoxObj = {
        options: [],
        filteredRecords: [],
        filterValue: null,
        selectFromList: false,
        ngSelectInstance: null
    };
    typeaheadObj = {};
    constructor(
        private planningDataService: PlanningDataService
    ) { }

    ngOnInit() {
        if (this.fieldObj && this.fieldObj.hasOwnProperty('name')) {
            this.field = this.fieldObj;
            this.group = this.groupName;
            this.masterData = this.masterData;
        }
        this.searchBoxObj.options = this.field.options || this.masterData[this.field.option];
        this.searchBoxObj.filterValue = this.field.value || null;
    }

    ngOnChanges() {
        if (this.field) {
            // this.searchBoxObj.options = changes.masterData.currentValue[this.field.option];
            this.searchBoxObj.options = this.masterData[this.field.option];
            if (this.searchBoxObj.options.length === 0) {
                this.searchBoxObj.options = [];
                this.searchBoxObj.filteredRecords = [];
                this.searchBoxObj.filterValue = null;
                this.searchBoxObj.selectFromList = false;
                if (this.searchBoxObj.ngSelectInstance) {
                    this.searchBoxObj.ngSelectInstance.searchTerm = null;
                }
                if (this.group) {
                    this.group.get(this.field.name).setValue(null);
                }
            }
        }
    }

    filterRecords(searchTerm) {
        if (searchTerm) {
            this.searchBoxObj.filteredRecords = this.searchBoxObj.options.
                filter(option => option.toLowerCase().includes(searchTerm.toLowerCase()));
        } else {
            this.searchBoxObj.filteredRecords = JSON.parse(JSON.stringify(this.searchBoxObj.options));
        }
    }

    onOpen(select) {
        this.searchBoxObj.ngSelectInstance = select;
        this.filterRecords(this.searchBoxObj.filterValue);
    }

    // Function will be called when user tries to search options
    onSearch(select) {
        if (this.group.get(this.field.name).value) {
            if ((this.field.hasOwnProperty('reqObj') && this.field.reqObj.columnName) || this.isRemoveData) {
                this.resetChild();
            }
        }
        this.group.get(this.field.name).setValue(null);
        // this.searchBoxObj.filterValue = event['target']['value'];
        this.searchBoxObj.filterValue = select.searchTerm;
        this.filterRecords(this.searchBoxObj.filterValue);
    }

    // Function will be called when option is selected from the list
    onSelection(select) {
        this.searchBoxObj.filterValue = select.selectedItems[0].value;
        this.searchBoxObj.selectFromList = false;
        this.optionSelected(select.selectedItems[0].value);
    }

    // Function will be called when user change the focus of dropdown
    onBlur(select) {
        select.searchTerm = this.searchBoxObj.filterValue;
        if (this.searchBoxObj.filterValue) {
            const data = this.searchBoxObj.filteredRecords.filter(option => option === this.searchBoxObj.filterValue);
            if (data.length === 1) {
                if (data[0] !== this.group.get(this.field.name).value) {
                    this.searchBoxObj.selectFromList = false;
                    this.optionSelected(data[0]);
                }
            } else {
                this.group.get(this.field.name).setValue(null);
                this.group.controls[this.field.name].markAsPending();
            }
        }
        if (
            this.searchBoxObj.filterValue &&
            this.searchBoxObj.filteredRecords.length > 0 &&
            !this.group.value[this.field.name]
        ) {
            this.searchBoxObj.selectFromList = true;
            this.group.controls[this.field.name].markAsPending();
        }
    }

    optionSelected(selectedOption) {
        this.group.get(this.field.name).setValue(selectedOption);
        if (this.isRemoveData && this.field.childKey) {
            const data = {
                isResetChild: false,
                field: this.field,
            };
            this.selectedValue.emit(data);
        }
        if (this.field.hasOwnProperty('isFillChildDropList') && this.field.isFillChildDropList) {
            if (this.field.masterDataKey !== '') {
                const reqObj: any = {
                    columnName: this.field.reqObj.columnName,
                    conditions: [],
                    tableName: this.field.reqObj.tableName
                };
                this.field.reqObj.parentKeys.forEach((parentKey, index) => {
                    const conditionObj: any = {};
                    conditionObj.conditionColumnName = parentKey;
                    conditionObj.conditionValue = selectedOption;
                    if (this.field.reqObj.childTableKey && this.field.reqObj.childTableKey[index]) {
                        conditionObj.conditionTableName = this.field.reqObj.childTableKey[index];
                    }
                    if (this.field.reqObj.parentColumn && this.field.reqObj.parentColumn[index]) {
                        conditionObj.parentColumn = this.field.reqObj.parentColumn[index];
                    }
                    reqObj.conditions.push(conditionObj);
                });
                if (this.field.reqObj && this.field.reqObj.requestedColumnParentColumn && this.field.reqObj.requestedColumnParentTable) {
                    reqObj.requestedColumnParentColumn = this.field.reqObj.requestedColumnParentColumn;
                    reqObj.requestedColumnParentTable = this.field.reqObj.requestedColumnParentTable;
                }
                this.planningDataService.getMasterDataOptions(reqObj).then(data => {
                    const obj = {
                        masterDataKey: this.field.masterDataKey,
                        options: data,
                        name: this.field.reqObj.columnName
                    };
                    this.planningDataService.changeMessage('masterData|' + JSON.stringify(obj));
                });
            }
        }
    }

    resetChild() {
        if (this.isRemoveData) {
            const data = {
                isResetChild: true,
                field: this.field,
            };
            this.selectedValue.emit(data);
        } else {
            const obj = {
                masterDataKey: this.field.masterDataKey,
                options: [],
                name: this.field.reqObj.columnName
            };
            this.planningDataService.changeMessage('masterData|' + JSON.stringify(obj));
        }
    }

    ngOnDestroy() {
        this.planningDataService.changeMessage('default message');
    }
}
