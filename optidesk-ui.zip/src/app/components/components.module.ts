import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import {
    ButtonComponent,
    CheckboxComponent,
    DynamicFormComponent,
    DynamicTableComponent,
    DynamicFieldDirective,
    InputComponent,
    SectionComponent,
    SelectComponent,
    TabComponent,
    SearchBoxesComponent
} from './';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ComponentService } from './component.service';
import {
    NgbTypeaheadModule,
    NgbDatepickerModule,
    NgbTooltipModule,
    NgbModule,
    NgbModalModule
} from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DatepickerComponent } from './datepicker/datepicker.component';
import { FieldErrorComponent } from './field-error/field-error.component';
import { TextMaskModule } from 'angular2-text-mask';
import { NgSelectModule } from '@ng-select/ng-select';
import { TimepickerComponent } from './timepicker/timepicker.component';
import { DeleteFormComponent } from './delete-form/delete-form.component';

@NgModule({
    declarations: [
        ButtonComponent,
        CheckboxComponent,
        DynamicFormComponent,
        DynamicTableComponent,
        DynamicFieldDirective,
        InputComponent,
        SectionComponent,
        SelectComponent,
        TabComponent,
        SearchBoxesComponent,
        DatepickerComponent,
        FieldErrorComponent,
        TimepickerComponent,
        DeleteFormComponent
    ],
    imports: [
        CommonModule,
        TranslateModule,
        FontAwesomeModule,
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        NgbTypeaheadModule,
        NgbDatepickerModule,
        NgbTooltipModule,
        NgbModalModule,
        TextMaskModule,
        NgSelectModule
    ],
    exports: [
        SectionComponent,
        SearchBoxesComponent,
        TabComponent
    ],
    providers: [
        DatePipe,
        ComponentService
    ]
})
export class ComponentsModule {
}
