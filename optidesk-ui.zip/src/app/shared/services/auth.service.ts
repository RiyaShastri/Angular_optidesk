import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NotifyService } from './notify.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    constructor(
        private http: HttpClient,
        public router: Router,
        private notifyService: NotifyService
    ) { }

    appendCAAPHeaders() {
        const httpOptions = {
            headers: new HttpHeaders({
                isAuthAPI: 'true'
            }),
        };
        return httpOptions;
    }

    login(params) {
        const url = '/api/v1/auth?clientCode=' + params.clientCode;
        return this.http.get<any>(url, this.appendCAAPHeaders()).toPromise();
    }

    userCodeVerification(requestBody) {
        const url = '/api/v1/auth/verify-code';
        return this.http.post<any>(url, requestBody, this.appendCAAPHeaders()).toPromise();
    }

    userEmailActivation(params) {
        const url = '/api/v1/customer-users/activate';
        const requestJson = { token: params.token };
        return this.http.put<any>(url, requestJson, this.appendCAAPHeaders()).toPromise();
    }

    logout() {
        const url = '/api/v1/auth/logout';
        return this.http.get<any>(url, this.appendCAAPHeaders()).toPromise();
    }

    doLogout() {
        this.logout().then(response => {
            localStorage.clear();
            location.href = environment.caapUIURL + '/auth/login';
        }).catch(err => {
            localStorage.clear();
            location.href = environment.caapUIURL + '/auth/login';
        });
    }

    logoutFromAllDevice() {
        const url = '/api/v1/auth/logout-from-all';
        return this.http.get<any>(url, this.appendCAAPHeaders()).toPromise();
    }

    getToken() {
        return this.notifyService.getToken();

    }

    adminLogin() {
        const url = '/api/v1/auth/admin';
        return this.http.get<any>(url, this.appendCAAPHeaders()).toPromise();
    }

    getUserDetails() {
        const url = '/api/v1/users';
        return this.http.get<any>(url, this.appendCAAPHeaders()).toPromise();
    }

    manageSingleSession() {
        localStorage.openpages = Date.now();
        const onLocalStorageEvent = (e) => {
            if (e.key === 'openpages') {
                localStorage.page_available = Date.now();
            }

            if (e.key === 'userLoggedIn' && localStorage.getItem('token') !== this.notifyService.getToken()) {
                this.router.navigate(['/auth/login']);
                window.close();
            }
        };
        window.addEventListener('storage', onLocalStorageEvent, false);
    }

     preventKeyboardRefresh(event) {
        if ((event.which || event.keyCode) === 116 || (event.ctrlKey && (event.keyCode === 82 || event.keyCode === 17))) {
            event.preventDefault();
            event.stopPropagation();
        }
    }

}
