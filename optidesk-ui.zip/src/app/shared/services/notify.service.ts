import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class NotifyService {

    private userDetails = new BehaviorSubject<any>('default message');
    userDetailsObservable = this.userDetails.asObservable();

    private messageSource = new BehaviorSubject<any>('default message');
    currentMessage = this.messageSource.asObservable();

    private tokenSource = new BehaviorSubject<any>('');

    private roleSource = new BehaviorSubject<any>('');
    currentRole = this.roleSource.asObservable();

    constructor() { }

    setUserDetailsJson(message: any) {
        this.userDetails.next(message);
    }

    changeMessage(message: any) {
        this.messageSource.next(message);
    }

    setToken(token: any) {
        this.tokenSource.next(token);
    }

    getToken() {
        return this.tokenSource.getValue();
    }

    setRole(role: any) {
        this.roleSource.next(role);
    }

}
