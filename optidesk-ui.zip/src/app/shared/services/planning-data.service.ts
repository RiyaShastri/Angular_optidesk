import { Injectable } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/internal/Subject';
import { BehaviorSubject } from 'rxjs';
import { ComponentService } from 'src/app/components/component.service';
import { CONSTANTS, ENCRYPT_KEY, MODULE_API_END_POINT, SUB_ERROR_MESSAGE } from 'src/app/shared/constants';
import { ConfirmOptions, ModalService } from 'src/app/core/utility/modal/modal.service';


@Injectable({
    providedIn: 'root'
})
export class PlanningDataService {
    masterData = new Subject<any>();
    private messageSource = new BehaviorSubject('default message');
    currentMessage = this.messageSource.asObservable();
    constructor(
        private router: Router,
        private formBuilder: FormBuilder,
        private httpClient: HttpClient,
        private modalService: ModalService,
        private componentService: ComponentService
    ) { }

    changeMessage(message: string) {
        this.messageSource.next(message);
    }

    decidePageType() {
        let pageType;
        if (this.router.url.indexOf('edit') > -1) {
            pageType = CONSTANTS.EDIT;
        } else if (this.router.url.indexOf('create') > -1) {
            pageType = CONSTANTS.CREATE;
        } else {
            pageType = CONSTANTS.VIEW;
        }
        return pageType;
    }

    createMainFormGroup(moduleConfig) {
        const mainFormGroups = {};
        moduleConfig.tabs.forEach(tab => {
            mainFormGroups[tab.tblName] = this.formBuilder.array([], this.componentService.bindValidations(tab.validations || []));
            if (tab.tabView === 'SECTION') {
                mainFormGroups[tab.tblName].push(this.formBuilder.group({}));
            }
        });
        return this.formBuilder.group(mainFormGroups);
    }

    createFreshModuleData(moduleConfig) {
        const freshModuleData = {};
        moduleConfig.tabs.forEach(tab => {
            freshModuleData[tab.tblName] = [];
        });
        return freshModuleData;
    }

    appendCAAPHeaders() {
        const httpOptions = {
            headers: new HttpHeaders({
                isAuthAPI: 'true'
            }),
        };
        return httpOptions;
    }

    checkRecordExists(reqObj, tblName) {
        const url = '/api/commons/_record-exists';
        if (tblName === 'customers' || tblName === 'USERS') {
            return this.httpClient.post<any>(url, reqObj, this.appendCAAPHeaders());
        } else {
            return this.httpClient.post<any>(url, reqObj);
        }
    }

    displayPopup(type, title, message, subMessage = '', messageParam = {}, isActionModal = false) {
        const modalOption: ConfirmOptions = {
            type,
            title,
            message,
            subMessage,
            messageParam,
            isActionModal
        };
        return this.modalService.confirm(modalOption);
    }

    encryptSearchReq(reqObj) {
        return this.componentService.renameKeys(ENCRYPT_KEY, reqObj);
    }

    searchRecord(moduleName, reqObj) {
        if (moduleName === 'CAAP_USER' || moduleName === 'CAAP_CUSTOMER') {
            const url = '/' + MODULE_API_END_POINT[moduleName] + '/_search';
            return this.httpClient.post(url, reqObj, this.appendCAAPHeaders());
        } else {
            const url = '/' + 'api/' + MODULE_API_END_POINT[moduleName] + '/_search';
            return this.httpClient.post(url, reqObj);
        }
    }

    getNewModelNumber(moduleName) {
        const url = environment.managementApiURL + '/' + MODULE_API_END_POINT[moduleName] + '/latest-model-id';
        return this.httpClient.get(url);
    }

    performAction(moduleName, pageType, reqObj) {
        return new Promise((resolve, reject) => {
            try {
                if (MODULE_API_END_POINT[moduleName]) {
                    let url;
                    if (moduleName === 'CAAP_USER' || moduleName === 'CAAP_CUSTOMER') {
                        url = '/' + MODULE_API_END_POINT[moduleName];
                        const mainMessage = 'MESSAGE.' + moduleName + '_' + ((pageType === CONSTANTS.CREATE) ? 'CREATE' : 'EDIT');
                        this.performCAAPAPICall(pageType, url, reqObj, mainMessage, resolve);
                    } else {
                        url = '/' + 'api/' + MODULE_API_END_POINT[moduleName];
                        const mainMessage = 'MESSAGE.' + moduleName + '_' + ((pageType === CONSTANTS.CREATE) ? 'CREATE' : 'EDIT');
                        this.performDataManagementAPICall(pageType, url, reqObj, mainMessage, resolve);
                    }
                }
            } catch (error) {
                resolve(false);
            }
        });
    }

    performCAAPAPICall(pageType, url, reqObj, mainMessage, resolve) {
        if (pageType === CONSTANTS.CREATE) {
            this.httpClient.post(url, reqObj, this.appendCAAPHeaders()).toPromise().then(res => {
                this.successRes(mainMessage);
                resolve(true);
            }).catch(err => {
                this.errorRes(err, mainMessage);
                resolve(false);
            });
        } else if (pageType === CONSTANTS.EDIT) {
            this.httpClient.put(url, reqObj, this.appendCAAPHeaders()).toPromise().then(res => {
                this.successRes(mainMessage);
                resolve(true);
            }).catch(err => {
                this.errorRes(err, mainMessage);
                resolve(false);
            });
        }
    }

    performDataManagementAPICall(pageType, url, reqObj, mainMessage, resolve) {
        if (pageType === CONSTANTS.CREATE) {
            this.httpClient.post(url, reqObj).toPromise().then(res => {
                this.successRes(mainMessage);
                resolve(true);
            }).catch(err => {
                this.errorRes(err, mainMessage);
                resolve(false);
            });
        } else if (pageType === CONSTANTS.EDIT) {
            this.httpClient.put(url, reqObj).toPromise().then(res => {
                this.successRes(mainMessage);
                resolve(true);
            }).catch(err => {
                this.errorRes(err, mainMessage);
                resolve(false);
            });
        }
    }

    successRes(mainMessage) {
        this.displayPopup(
            'success',
            'MESSAGE.TITLE_SUCCESS',
            mainMessage
        );
    }

    errorRes(err, mainMessage) {
        let subMessage = '';
        if (SUB_ERROR_MESSAGE.includes(err.error.errorSsid)) {
            subMessage = 'MESSAGE.' + err.error.errorSsid;
        }
        this.displayPopup(
            'info',
            'MESSAGE.TITLE_ERROR',
            mainMessage + '_FAILED',
            subMessage
        );
    }

    async doCanDeactivate(childRef) {
        return await this.canDeactivate(childRef);
    }

    canDeactivate(childRef) {
        return new Promise((resolve, reject) => {
            try {
                if (childRef && childRef.mainForm && !childRef.mainForm.untouched) {
                    this.displayPopup(
                        'info',
                        'MESSAGE.DISCARD_CHANGE_TITLE',
                        'MESSAGE.DO_YOU_WANT_TO_CANCEL_OPERATION', '', {}, true
                    ).toPromise().then(close => {
                        resolve(true);
                    }).catch(dismiss => {
                        resolve(false);
                    });
                } else {
                    resolve(true);
                }
            } catch (error) {
                reject(true);
            }
        });
    }

    populateMasterData(masterDataFields) {
        return new Promise(async (resolve, reject) => {
            const masterData = {};
            try {
                if (masterDataFields && masterDataFields.length > 0) {
                    const totalFields = masterDataFields.length;
                    let index = 0;
                    while (index < totalFields) {
                        const masterDataField = masterDataFields[index];
                        const reqObj = JSON.parse(JSON.stringify(masterDataField.reqObj));
                        masterData[masterDataField.masterDataKey] = await this.getMasterDataOptions(reqObj);
                        index++;
                        if (index === totalFields) {
                            resolve(masterData);
                        }
                    }
                } else {
                    resolve(masterData);
                }
            } catch (error) {
                resolve(masterData);
            }
        });
    }

    getMasterDataOptions(reqObj) {
        return new Promise((resolve, reject) => {
            try {
                this.componentService.fillDropDownOption(reqObj).toPromise().then(result => {
                    resolve(result);
                }).catch(err => {
                    resolve([]);
                });
            } catch (error) {
                resolve([]);
            }
        });
    }
}
