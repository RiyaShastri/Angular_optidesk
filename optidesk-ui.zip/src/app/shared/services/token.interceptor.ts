import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse
} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { concatMap, delay, retryWhen, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
    managementURL;
    authenticationURL;
    possibleErrorStatus = [0, 502, 503, 504];
    constructor(
        public auth: AuthService,
        public router: Router,
    ) {
        this.managementURL = environment.managementApiURL;
        this.authenticationURL = environment.caapApiURL;
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (!request.url.includes('.json')) {
            let url = '';
            if (request.headers.get('isAuthAPI') === 'true') {
                url = this.authenticationURL + request.url;
            } else {
                url = this.managementURL + request.url;
            }
            let token = this.auth.getToken();
            if (request.url.includes('logout') && !token) {
                token = localStorage.getItem('token');
            }
            request = request.clone({
                url,
                setHeaders: {
                    Authorization: `Bearer ${token}`
                }
            });
        }
        return next.handle(request).pipe(
            retryWhen(errors => errors
                .pipe(
                    concatMap((error, count) => {
                        if (this.possibleErrorStatus.indexOf(error.status) > -1) {
                            if (count < 2) {
                                return of(error.status);
                            } else {
                                let backupURL = '';
                                if (request.headers.get('isAuthAPI') === 'true') {
                                    this.authenticationURL = environment.caapBackupURL;
                                    backupURL = request.url.replace(environment.caapApiURL, this.authenticationURL);
                                } else {
                                    this.managementURL = environment.managementBackupURL;
                                    backupURL = request.url.replace(environment.managementApiURL, this.managementURL);
                                }
                                const httpRequest = new HttpRequest(request.method as any, backupURL);
                                request = Object.assign(request, httpRequest);
                                return of(error.status);
                            }
                        } else {
                            return throwError(error);
                        }
                    }),
                    delay(500)
                )
            ),
            tap((event: HttpEvent<any>) => {
            }, (err: any) => {
                if (err instanceof HttpErrorResponse) {
                    if (err.status === 401 || err.status === 403) {
                        localStorage.clear();
                        location.href = environment.caapUIURL + '/auth/login';
                        // this.router.navigate(['/auth/login']);
                    }
                }
            }));
    }
}
