export const CONSTANTS = {
    VIEW: 0,
    EDIT: 1,
    CREATE: 2,
    VALID_KEY: 0,
    INVALID_KEY: 1,
    SELECT_FROM_LIST: 2,
    NON_EDITABLE_LANES: '3'
};

export const ENCRYPT_KEY = {
    columnName: 'p1',
    conditions: 'p2',
    conditionColumnName: 'p21',
    conditionValue: 'p22',
    conditionTableName: 'p23',
    parentColumn: 'p24',
    mainTableForeignKey: 'p25',
    tableName: 'p3',
    requestedColumnParentTable: 'p4',
    requestedColumnParentColumn: 'p5',
    requestedTableForeignKey: 'p6'
};

export const LANE_TYPES = {
    INTERNAL_PROCURMENT: '1',
    EXTERNAL_PROCURMENT: '2',
    PRODUCTION_PROCURMENT: '3'
};

export const DROPDOWN = {
    commonDropList: ['X'],
    ynDropDown: ['Y', 'N'],
    dependentRequirement: ['I', 'C'],
    pushDistribution: ['PUSH', 'PULL', 'PULL/PUSH'],
    cosmodDropList: ['F', 'B', 'FB', 'BF'],
    laneTypes: [
        { value: LANE_TYPES.INTERNAL_PROCURMENT, name: '1 - INTERNAL PROCURMENT' },
        { value: LANE_TYPES.EXTERNAL_PROCURMENT, name: '2 - EXTERNAL PROCURMENT' },
        { value: LANE_TYPES.PRODUCTION_PROCURMENT, name: '3 - PRODUCTION PROCURMENT' },

    ],
    transportationModes: ['LAND', 'RAIL', 'AIR', 'OCEAN']
};

export const MODULE_API_END_POINT = {
    HOLIDAY_CALENDAR: 'holiday-calendars',
    WORKING_CALENDAR: 'working-calendars',
    VENDOR: 'vendors',
    PLANT: 'plants',
    CUSTOMER: 'customers',
    SUB_LOCATIONS: 'sub-locations',
    MATERIAL: 'materials',
    LOCATION_MATERIAL: 'location-materials',
    MODEL: 'models',
    MODEL_LOCATION: 'model-locations',
    MODEL_MATERIAL: 'model-materials',
    MODEL_LOCATION_MATERIAL: 'model-location-materials',
    TRANSPORTATION_LANES: 'transportation-lanes',
    RESOURCE: 'resources',
    SHIFT_CAPACITY: 'capacity-shifts',
    TRANSPORTATION_TYPE: 'transportation-types',
    CUSTOMER_ONBOARDING: 'api/customer/onboarding',
    CAAP_CUSTOMER: 'api/v1/customers',
    CAAP_USER: 'api/v1/customer-users',
    CUSTOMER_USER_ONBOARDING: 'api/v1/customer-users'
};

export const SUB_ERROR_MESSAGE = [
    'INVALID_HOLIDAY',
    'LOCATION_NUMBER_ALREADY_EXISTS',
    'INVALID_LOCATION_MATERIAL',
    'MODEL_MATERIAL_DOES_NOT_EXISTS',
    'MODEL_LOCATION_DOES_NOT_EXISTS',
    'CAPACITY_RECORD_ALREADY_EXISTS',
    'CAPACITY_RECORD_DOES_NOT_EXISTS',
    'INVALID_NOCAP_SSID',
    'CUSTOMER_DOES_NOT_EXISTS',
    'IDENTITY_PROVIDER_IS_REQUIRED',
    'MAX_8_CHARACTERS_ALLOWED_FOR_CUSTOMER',
    'ADMIN_USER_EDIT_NOT_ALLOWED',
    'INVALID_TENANT_ID',
    'INVALID_CLIENT_ID',
    'USER_NOT_ACTIVATED',
    'USER_DOES_NOT_EXISTS',
    'INTERNAL_SERVER_ERROR',
    'EMAIL_ALREADY_EXISTS',
    'CUSTOMER_NOT_ACTIVATED'
];

export const CURRENCY_NUMBER_MASK = {
    numbersOnly: {
        allowDecimal: false,
        decimalLimit: 0,
        prefix: '',
        suffix: '',
        thousandsSeparatorSymbol: ''
    },
    oneDecimalOnly: {
        allowDecimal: true,
        decimalLimit: 1,
        prefix: '',
        suffix: '',
        thousandsSeparatorSymbol: ''
    },
    twoDecimalOnly: {
        allowDecimal: true, // by default it will take 2 decimal
        prefix: '',
        suffix: '',
        thousandsSeparatorSymbol: ''
    },
    threeDecimalOnly: {
        allowDecimal: true,
        decimalLimit: 3,
        prefix: '',
        suffix: '',
        thousandsSeparatorSymbol: ''
    }
};

export const tLanesDefaultPayLoad = {
    traTyp: 'Default',
    dplTime: {
        hour: 0,
        minute: 0,
        second: 0
    },
    stoTime: {
        hour: 0,
        minute: 0,
        second: 0
    }
};

export const CUSTOMER_USER_ROLES = [
    'USERADMIN',
    'MASTER_DATA_ADMINISTRATOR',
    'DEMAND_PLANNER',
    'PRODUCTION_PLANNER',
    'DISTRIBUTION_PLANNER',
    'NETWORK_PLANNER',
    'SUPERADMIN',
    'USER_MANAGER'
];
