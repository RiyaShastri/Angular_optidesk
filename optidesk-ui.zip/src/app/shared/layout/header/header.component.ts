import { Component, Input, OnInit } from '@angular/core';
import { faUser } from '@fortawesome/free-regular-svg-icons';
import { faSignInAlt } from '@fortawesome/free-solid-svg-icons';
import { AuthService } from 'src/app/shared/services/auth.service';
import { NotifyService } from 'src/app/shared/services/notify.service';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
    @Input() userInfo = [];
    faUser = faUser;
    faSignInAlt = faSignInAlt;
    constructor(
        private authService: AuthService,
        private notifyService: NotifyService
    ) {
    }

    ngOnInit(): void {
    }

    toggle() {
        const classlist = document.body.getAttribute('class');
        if (classlist) {
            document.body.removeAttribute('class');
        } else {
            document.body.setAttribute('class', 'show');
        }
    }

    logout() {
        this.authService.logout().then(response => {
            localStorage.clear();
            this.notifyService.setToken('');
            location.href = environment.caapUIURL + '/auth/login';
            // window.open('https://odcaap.eastus.cloudapp.azure.com/optidesk/auth/login', '_self');
        }).catch(error => {
        });
    }
}
