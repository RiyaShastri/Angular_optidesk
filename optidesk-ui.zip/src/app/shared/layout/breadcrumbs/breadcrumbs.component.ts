import { Component, OnInit, Input } from '@angular/core';
import { faChevronRight, faHome } from '@fortawesome/free-solid-svg-icons';


@Component({
    selector: 'app-breadcrumbs',
    templateUrl: './breadcrumbs.component.html',
    styleUrls: ['./breadcrumbs.component.css']
})
export class BreadcrumbsComponent implements OnInit {

    faChevronRight = faChevronRight;
    faHome = faHome;
    @Input() breadcrumbs = [];
    constructor() { }
    ngOnInit(): void {
    }
}
