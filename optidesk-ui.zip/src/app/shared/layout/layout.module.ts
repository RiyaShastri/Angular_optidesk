import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BreadcrumbsComponent } from './breadcrumbs/breadcrumbs.component';
import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { SidebarComponent } from './sidebar/sidebar.component';
import { faEdit, faPlusSquare, faEye } from '@fortawesome/free-regular-svg-icons';
import { faArrowsAltH } from '@fortawesome/free-solid-svg-icons';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
    declarations: [
        HeaderComponent,
        FooterComponent,
        BreadcrumbsComponent,
        SidebarComponent
    ],
    imports: [
        CommonModule,
        RouterModule,
        TranslateModule,
        FontAwesomeModule
    ],
    exports: [
        HeaderComponent,
        FooterComponent,
        BreadcrumbsComponent,
        SidebarComponent
    ]
})
export class LayoutModule {
    constructor(library: FaIconLibrary) {
        library.addIcons(faEye);
        library.addIcons(faEdit);
        library.addIcons(faPlusSquare);
        library.addIcons(faArrowsAltH);
    }
}
