import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { TranslateModule } from '@ngx-translate/core';
import { ModalComponent } from './modal/modal.component';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
    declarations: [
        ModalComponent
    ],
    imports: [
        CommonModule,
        TranslateModule,
        FontAwesomeModule,
        NgbModalModule
    ],
    providers: [TranslateModule],
})
export class UtilityModule { }
