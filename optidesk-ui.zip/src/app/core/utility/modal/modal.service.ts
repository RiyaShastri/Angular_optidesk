import { Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalComponent } from './modal.component';
import { Observable, from, EMPTY, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

export type ModalType = 'success' | 'error' | 'warning' | 'info' | 'question';

export interface ConfirmOptions {
    type: ModalType;
    title: string;
    message: string;
    subMessage?: string;
    isActionModal?: boolean;
    messageParam?: {};
}

@Injectable({ providedIn: 'root' })
export class ModalService {
    constructor(
        private ngbModalService: NgbModal,
        private translate: TranslateService
    ) { }

    confirm(options: ConfirmOptions): Observable<void> {
        const modalRef = this.ngbModalService.open(ModalComponent);
        modalRef.componentInstance.type = options.type;
        modalRef.componentInstance.isActionModal = options.isActionModal;
        this.translate.get(
            [options.title, options.message, options.subMessage, 'MESSAGE.INTERNAL_SERVER_ERROR'], options.messageParam).subscribe(i18Text => {
                modalRef.componentInstance.title = i18Text[options.title];
                modalRef.componentInstance.message = i18Text[options.message] || i18Text[`MESSAGE.INTERNAL_SERVER_ERROR`];
                modalRef.componentInstance.subMessage = i18Text[options.subMessage];
            });
        // return from(modalRef.result);
        return from(modalRef.result).pipe(
            catchError(err => (options.isActionModal ? throwError(err ?? 'not confirmed') : EMPTY))
        );
    }
}
