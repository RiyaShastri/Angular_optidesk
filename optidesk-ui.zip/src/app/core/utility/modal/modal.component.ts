import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { faInfoCircle, faCheckCircle, faCheck, faTimes } from '@fortawesome/free-solid-svg-icons';

@Component({
    selector: 'app-modal',
    templateUrl: './modal.component.html',
    styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {
    @Input() type;
    @Input() title;
    @Input() message;
    @Input() subMessage;
    @Input() isActionModal;
    faInfoCircle = faInfoCircle;
    faCheckCircle = faCheckCircle;
    faCheck = faCheck;
    faTimes = faTimes;
    constructor(public activeModal: NgbActiveModal) { }
    ngOnInit(): void { }
}
