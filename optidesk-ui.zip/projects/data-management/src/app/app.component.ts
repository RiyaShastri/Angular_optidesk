import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from 'src/app/shared/services/auth.service';
import { NotifyService } from 'src/app/shared/services/notify.service';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    constructor(
        private translate: TranslateService,
        private authService: AuthService,
        private notifyService: NotifyService,
        public router: Router,
    ) {
        this.translate.setDefaultLang('en');
        this.translate.use('en');
    }

    ngOnInit(): void {
        this.authService.manageSingleSession();
    }

    // Prevent refresh using keyboard
    @HostListener('window:keydown', ['$event'])
    unloadHandler(event) {
        this.authService.preventKeyboardRefresh(event);
    }
}
