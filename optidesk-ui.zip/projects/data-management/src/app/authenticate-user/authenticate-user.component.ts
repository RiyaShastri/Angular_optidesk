import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { NotifyService } from 'src/app/shared/services/notify.service';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-authenticate-user',
    templateUrl: './authenticate-user.component.html',
    styleUrls: ['./authenticate-user.component.css']
})
export class AuthenticateUserComponent implements OnInit {

    constructor(
        private Activatedroute: ActivatedRoute,
        private router: Router,
        private authService: AuthService,
        private notifyService: NotifyService,
    ) { }

    ngOnInit(): void {
        this.Activatedroute.queryParamMap.subscribe((params: any) => {
            const currentTime = new Date().getTime();
            const getParamTime = params.params.t;
            const timeDiff = currentTime - getParamTime;
            if (timeDiff <= 60000) {
                this.notifyService.setToken(params.params.token);
                localStorage.setItem('token', params.params.token);
                localStorage.setItem('userLoggedIn', currentTime.toString());
                this.authService.getUserDetails().then(userInfo => {
                    const userDetailsObj = {
                        type: 'user-details',
                        data: userInfo
                    };
                    this.notifyService.setUserDetailsJson(userDetailsObj);
                    this.router.navigate(['/']);
                }).catch(error => {
                });
            } else {
                localStorage.clear();
                location.href = environment.caapUIURL + '/auth/login';
            }
        });
    }

}
