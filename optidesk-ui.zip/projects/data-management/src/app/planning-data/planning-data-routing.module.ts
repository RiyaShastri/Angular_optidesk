import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenusComponent } from './menus/menus.component';
import { PlanningDataComponent } from './planning-data.component';
import { AuthGuardService as AuthGuard } from 'src/app/shared/services/auth-guard.service';

const routes: Routes = [
    {
        path: '',
        component: PlanningDataComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: '',
                component: MenusComponent
            },
            {
                path: 'material',
                loadChildren: () => import('../planning-data/material/material.module').then(m => m.MaterialModule)
            },
            {
                path: 'holiday-calendar',
                loadChildren: () => import('../planning-data/holiday-calendar/holiday-calendar.module').then(m => m.HolidayCalendarModule)
            },
            {
                path: 'working-calendar',
                loadChildren: () => import('../planning-data/working-calendar/working-calendar.module').then(m => m.WorkingCalendarModule)
            },
            {
                path: 'plant',
                loadChildren: () => import('../planning-data/plant/plant.module').then(m => m.PlantModule)
            },
            {
                path: 'vendor',
                loadChildren: () => import('../planning-data/vendor/vendor.module').then(m => m.VendorModule)
            },
            {
                path: 'sub-location',
                loadChildren: () => import('../planning-data/sub-location/sub-location.module').then(m => m.SubLocationModule)
            },
            {
                path: 'customer',
                loadChildren: () => import('../planning-data/customer/customer.module').then(m => m.CustomerModule)
            },
            {
                path: 'location-material',
                loadChildren: () => import('../planning-data/location-material/location-material.module')
                    .then(m => m.LocationMaterialModule)
            },
            {
                path: 'model',
                loadChildren: () => import('../planning-data/model/model.module').then(m => m.ModelModule)
            },
            {
                path: 'model-location',
                loadChildren: () => import('../planning-data/model-location/model-location.module').then(m => m.ModelLocationModule)
            },
            {
                path: 'model-material',
                loadChildren: () => import('../planning-data/model-material/model-material.module').then(m => m.ModelMaterialModule)
            },
            {
                path: 'model-location-material',
                loadChildren: () => import('../planning-data/model-location-material/model-location-material.module')
                    .then(m => m.ModelLocationMaterialModule)
            },
            {
                path: 'transportation-lanes',
                loadChildren: () => import('../planning-data/transportation-lanes/transportation-lanes.module')
                    .then(m => m.TransportationLanesModule)
            },
            {
                path: 'transportation-type',
                loadChildren: () => import('../planning-data/transportation-type/transportation-type.module')
                    .then(m => m.TransportationTypeModule)
            },
            {
                path: 'resources',
                loadChildren: () => import('../planning-data/resources/resources.module').then(m => m.ResourcesModule)
            },
            {
                path: 'shift-capacity',
                loadChildren: () => import('../planning-data/shift-capacity/shift-capacity.module')
                    .then(m => m.ShiftCapacityModule)
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PlanningDataRoutingModule { }
