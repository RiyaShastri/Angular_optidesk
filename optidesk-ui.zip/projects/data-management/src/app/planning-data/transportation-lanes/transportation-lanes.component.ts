import { Component, OnInit, ViewChild } from '@angular/core';
import { TRANSPORTATION_LANES_CONFIG } from './transportation-lanes.config';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { TabComponent } from 'src/app/components';
import { CONSTANTS, LANE_TYPES} from 'src/app/shared/constants';

@Component({
    selector: 'app-transportation-lanes',
    templateUrl: './transportation-lanes.component.html',
    styleUrls: ['./transportation-lanes.component.css']
})
export class TransportationLanesComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = TRANSPORTATION_LANES_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    resetForm = false;
    pageType = CONSTANTS.VIEW;
    baseUrl = '/planning-data/transportation-lanes';
    isTableEditable = true;
    breadCrumb = {
        label: 'TRANSPORTATION_LANES.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'TRANSPORTATION_LANES.SIDE_BAR_MANUES.VIEW_MENU',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'TRANSPORTATION_LANES.SIDE_BAR_MANUES.EDIT_MENU',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'TRANSPORTATION_LANES.SIDE_BAR_MANUES.CREATE_MENU',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];
    validationError = '';
    isError = false;
    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
        this.moduleConfig.search.fields = [];
        if (this.pageType === CONSTANTS.CREATE) {
            this.moduleConfig.search.fields = this.moduleConfig.search.createFields;
            this.moduleConfig.search.tblName = this.moduleConfig.search.createTableName;
        } else {
            this.moduleConfig.search.fields = this.moduleConfig.search.editFields;
            this.moduleConfig.search.tblName = this.moduleConfig.search.editTableName;
        }
    }

    searchCriteria(searchedCriteria) {
        this.validationError = null;
        this.isError = false;
        this.resetForm = false;
        if (searchedCriteria && searchedCriteria.hasOwnProperty('primaryData')) {
            if (searchedCriteria.primaryData.laneTyp === LANE_TYPES.PRODUCTION_PROCURMENT &&
                searchedCriteria.primaryData.toLocNo !== searchedCriteria.primaryData.frLocNo) {
                this.validationError = 'MESSAGE.FROM_LOCATION_AND_TO_LOCATION_MUST_BE_SAME';
                this.isError = true;
                this.reset();
            } else {
                if (searchedCriteria.primaryData.laneTyp !== LANE_TYPES.PRODUCTION_PROCURMENT &&
                    searchedCriteria.primaryData.toLocNo === searchedCriteria.primaryData.frLocNo) {
                    this.validationError = 'MESSAGE.FROM_LOCATION_AND_TO_LOCATION_MUST_BE_DIFFRENT';
                    this.isError = true;
                    this.reset();
                }
            }
        }
        if (!this.isError) {
            if (this.pageType !== CONSTANTS.VIEW) {
                this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                    this.masterData = masterData;
                    this.displatPageContent(searchedCriteria);
                });
            } else {
                this.displatPageContent(searchedCriteria);
            }
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        setTimeout(() => {
            this.displayRecord = false;
            this.resetForm = true;
        }, 0);
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

    closeToast() {
        this.validationError = null;
    }

}
