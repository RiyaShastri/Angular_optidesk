import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransportationLanesComponent } from './transportation-lanes.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: TransportationLanesComponent
            },
            {
                path: 'edit',
                component: TransportationLanesComponent,
                canDeactivate: [CanDeactivatGuard]
            },
            {
                path: 'create',
                component: TransportationLanesComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class TransportationLanesRoutingModule { }
