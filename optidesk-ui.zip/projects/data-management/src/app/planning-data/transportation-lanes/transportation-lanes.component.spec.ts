import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransportationLanesComponent } from './transportation-lanes.component';

describe('TransportationLanesComponent', () => {
  let component: TransportationLanesComponent;
  let fixture: ComponentFixture<TransportationLanesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransportationLanesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransportationLanesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
