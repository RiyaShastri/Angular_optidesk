import { Validators } from '@angular/forms';
import { noDuplicatValue } from 'src/app/components/form-validator/form.validator';

export const TRANSPORTATION_LANES_CONFIG = {
    moduleName: 'TRANSPORTATION_LANES',
    moduleLabel: 'TRANSPORTATION_LANES.TITLE',
    moduleDescription: 'TRANSPORTATION_LANES.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'traTyps',
            reqObj: {
                columnName: 'traTyp',
                tableName: 'tratype'
            }
        }
    ],
    search: {
        tblName: '',
        editTableName: 'tlane',
        editExternal: false,
        recordExists: 'TRANSPORTATION_LANES_ALREADY_EXISTS',
        fields: [],
        editFields: [
            [
                {
                    label: 'TRANSPORTATION_LANES.FIELDS.LANETYP',
                    name: 'laneTyp',
                    value: '',
                    valueKey: 'laneTyp',
                    childKey: 'frLocNo',
                    parentKeys: [],
                    isCustomSearch: true,
                    isOjectOption: true,
                    bindLabel: 'name',
                    bindValue: 'value',
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    customOption: 'laneTypes',
                    notExistsLabel: 'TRANSPORTATION_LANES_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                    ]
                },
                {
                    label: 'TRANSPORTATION_LANES.FIELDS.FRLOCID',
                    name: 'frLocNo',
                    value: '',
                    valueKey: 'frLocNo',
                    childKey: 'toLocNo',
                    parentKeys: ['laneTyp'],
                    childTableKey: [],
                    isCustomSearch: true,
                    customColumnName: 'locNo',
                    customFillDropOption: {
                        '1': 'PLANT',
                        '2': 'VENDOR',
                        '3': 'PLANT'
                    },
                    requestedColumnParentTable: 'location',
                    requestedColumnParentColumn: 'locId',
                    requestedTableForeignKey: 'frLocId',
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'TRANSPORTATION_LANES_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH', messageParam: { max_char: 20 } }
                    ]
                },
                {
                    label: 'TRANSPORTATION_LANES.FIELDS.TOLOCID',
                    name: 'toLocNo',
                    value: '',
                    valueKey: 'toLocNo',
                    childKey: '',
                    isCustomSearch: true,
                    isChangeColumnName: true,
                    parentKeys: ['laneTyp', 'frLocNo'],
                    childTableKey: ['', 'location'],
                    parentColumn: ['', 'locId'],
                    mainTableForeignKeys: ['', 'frLocId'],
                    customColumnName: 'locNo',
                    requestedColumnParentTable: 'location',
                    requestedColumnParentColumn: 'locId',
                    requestedTableForeignKey: 'toLocId',
                    customFillDropOption: {
                        '1': 'PLANT',
                        '2': 'PLANT',
                        '3': 'PLANT'
                    },
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'TRANSPORTATION_LANES_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH', messageParam: { max_char: 20 } }
                    ]
                },
            ]
        ],
        createTableName: 'location',
        createFields: [
            [
                {
                    label: 'TRANSPORTATION_LANES.FIELDS.LANETYP',
                    name: 'laneTyp',
                    value: '',
                    valueKey: 'laneTyp',
                    childKey: 'frLocNo',
                    parentKeys: [],
                    isCustomSearch: true,
                    type: 'input',
                    inputType: 'text',
                    isOjectOption: true,
                    bindLabel: 'name',
                    bindValue: 'value',
                    option: '',
                    customOption: 'laneTypes',
                    searchTableName: 'tlane',
                    notExistsLabel: 'TRANSPORTATION_LANES_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                    ]
                },
                {
                    label: 'TRANSPORTATION_LANES.FIELDS.FRLOCID',
                    name: 'frLocNo',
                    value: '',
                    valueKey: 'frLocNo',
                    childKey: 'toLocNo',
                    parentKeys: ['locTyp'],
                    childTableKey: ['location'],
                    isCustomSearch: true,
                    customColumnName: 'locNo',
                    searchTableName: 'tlane',
                    requestedColumnParentColumn: 'locId',
                    requestedTableForeignKey: 'frLocId',
                    customFillDropOption: {
                        '1': 'PLANT',
                        '2': 'VENDOR',
                        '3': 'PLANT'
                    },
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'TRANSPORTATION_LANES_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH', messageParam: { max_char: 20 } }
                    ]
                },
                {
                    label: 'TRANSPORTATION_LANES.FIELDS.TOLOCID',
                    name: 'toLocNo',
                    value: '',
                    valueKey: 'toLocNo',
                    childKey: '',
                    isCustomSearch: true,
                    isChangeColumnName: true,
                    searchTableName: 'tlane',
                    parentKeys: ['locTyp'],
                    childTableKey: ['location'],
                    customColumnName: 'locNo',
                    requestedColumnParentColumn: 'locId',
                    requestedTableForeignKey: 'toLocId',
                    customFillDropOption: {
                        '1': 'PLANT',
                        '2': 'PLANT',
                        '3': 'PLANT'
                    },
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'TRANSPORTATION_LANES_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH', messageParam: { max_char: 20 } }
                    ]
                },
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'TRANSPORTATION_LANES.LANE_DETAILS_TAB.TITLE',
            tabDescription: 'TRANSPORTATION_LANES.LANE_DETAILS_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'transportationLanes',
            sections: [
                {
                    sectionTitle: 'TRANSPORTATION_LANES.LANE_DETAILS_TAB.SECTIONS.LANE_DETAIL',
                    fields: [
                        [
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.LANETYP',
                                name: 'laneTyp',
                                value: '',
                                valueKey: 'laneTyp',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.TOLOCID',
                                name: 'toLocNo',
                                value: '',
                                valueKey: 'toLocNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.FRLOCID',
                                name: 'frLocNo',
                                value: '',
                                valueKey: 'frLocNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                option: '',
                                fieldType: 'createdOn',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ],
                        [
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.ACTIND',
                                name: 'actInd',
                                value: '',
                                valueKey: 'actInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                custom: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            }
                        ]
                    ]
                }
            ]
        },
        {
            tabTitle: 'TRANSPORTATION_LANES.TRANSPORTATION_MODE_TAB.TITLE',
            tabDescription: 'TRANSPORTATION_LANES.TRANSPORTATION_MODE_TAB.DESCRIPTION',
            tabView: 'TABLE',
            tblName: 'transportationModes',
            sections: [
                {
                    sectionTitle: 'TRANSPORTATION_LANES.TRANSPORTATION_MODE_TAB.SECTIONS.TRANSPORTATION_MODE',
                    fields: [
                        [
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.TOLOCID',
                                name: 'toLocNo',
                                value: '',
                                valueKey: 'toLocNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.FRLOCID',
                                name: 'frLocNo',
                                value: '',
                                valueKey: 'frLocNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.TRATYP',
                                name: 'traTyp',
                                value: '',
                                valueKey: 'traTyp',
                                type: 'select',
                                inputType: 'select',
                                option: 'traTyps',
                                fieldType: '',
                                width: 'full',
                                isDefaultEditable: false,
                                compareFieldName: 'traTyp',
                                isEditable: true,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'noDuplicatValue', validator: noDuplicatValue(), message: 'DUPLICATE_TRANSPORTATION_TYPE' }
                                ]
                            },
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.DPLTIME',
                                name: 'dplTime',
                                value: '',
                                valueKey: 'dplTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isDefaultEditable: false,
                                compareFieldName: 'traTyp',
                                compareProductionProFr: 'frLocNo',
                                compareProductionProTo: 'toLocNo',
                                compareSelectedType: 'laneTyp',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'TRANSPORTATION_LANES.FIELDS.STOTIME',
                                name: 'stoTime',
                                value: '',
                                valueKey: 'stoTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                isDefaultEditable: false,
                                compareFieldName: 'traTyp',
                                compareSelectedType: 'laneTyp',
                                compareProductionProFr: 'frLocNo',
                                compareProductionProTo: 'toLocNo',
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
