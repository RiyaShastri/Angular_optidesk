import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransportationLanesRoutingModule } from './transportation-lanes-routing.module';
import { TransportationLanesComponent } from './transportation-lanes.component';
import { ComponentsModule } from 'src/app/components/components.module';
import { NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { FaIconLibrary, FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faBan } from '@fortawesome/free-solid-svg-icons';
import { TranslateModule } from '@ngx-translate/core';


@NgModule({
    declarations: [
        TransportationLanesComponent
    ],
    imports: [
        CommonModule,
        TransportationLanesRoutingModule,
        ComponentsModule,
        FontAwesomeModule,
        NgbAlertModule,
        TranslateModule
    ]
})
export class TransportationLanesModule {
    constructor(library: FaIconLibrary) {
        library.addIcons(faBan);
    }
}
