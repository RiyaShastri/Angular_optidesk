import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-planning-data',
    templateUrl: './planning-data.component.html',
    styleUrls: ['./planning-data.component.css']
})
export class PlanningDataComponent implements OnInit {
    sideBarMenus = [];
    breadcrumbs = [
        // {
        //     label: 'Supply Chain Data',
        //     routerLink: ['/planning-data']
        // },
        {
            label: 'Master Data',
            routerLink: ['/planning-data']
        }
    ];
    hideSideBar = false;
    constructor(
        private router: Router
    ) {
        this.hideSideBar = this.router.url === '/planning-data';
    }

    ngOnInit(): void { }

    onActivate(componentReference) {
        this.hideSideBar = this.router.url === '/planning-data';
        this.breadcrumbs.push(componentReference.breadCrumb);
        this.sideBarMenus = componentReference.sideBarMenus;
    }

    onDeactivate(componentReference) {
        this.breadcrumbs.pop();
    }
}
