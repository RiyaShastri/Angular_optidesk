import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { PlanningDataRoutingModule } from './planning-data-routing.module';
import { PlanningDataComponent } from './planning-data.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbNavModule, NgbAlertModule, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { FaIconLibrary, FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faBan, faCheck, faTimes, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { faClone, faCheckCircle } from '@fortawesome/free-regular-svg-icons';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { ModalService } from 'src/app/core/utility/modal/modal.service';
import { LayoutModule } from 'src/app/shared/layout/layout.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { MenusComponent } from './menus/menus.component';

@NgModule({
    declarations: [
        PlanningDataComponent,
        MenusComponent
    ],
    imports: [
        CommonModule,
        PlanningDataRoutingModule,
        TranslateModule,
        FontAwesomeModule,
        ReactiveFormsModule,
        ComponentsModule,
        LayoutModule,
        NgbNavModule,
        NgbAlertModule,
        NgbModalModule
    ],
    providers: [
        PlanningDataService,
        ModalService
    ]
})
export class PlanningDataModule {
    constructor(library: FaIconLibrary) {
        library.addIcons(faBan);
        library.addIcons(faCheck);
        library.addIcons(faTimes);
        library.addIcons(faClone);
        library.addIcons(faInfoCircle);
        library.addIcons(faCheckCircle);
    }
}
