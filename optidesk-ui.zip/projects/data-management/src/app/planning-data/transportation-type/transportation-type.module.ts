import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TransportationTypeRoutingModule } from './transportation-type-routing.module';
import { TransportationTypeComponent } from './transportation-type.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
    declarations: [
        TransportationTypeComponent
    ],
    imports: [
        CommonModule,
        TransportationTypeRoutingModule,
        ComponentsModule
    ]
})
export class TransportationTypeModule { }
