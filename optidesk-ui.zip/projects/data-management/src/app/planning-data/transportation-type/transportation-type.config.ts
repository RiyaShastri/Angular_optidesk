import { Validators } from '@angular/forms';

export const TRANSPORTATION_TYPE_CONFIG = {
    moduleName: 'TRANSPORTATION_TYPE',
    moduleLabel: 'TRANSPORTATION_TYPE.TITLE',
    moduleDescription: 'TRANSPORTATION_TYPE.DESCRIPTION',
    masterData: [],
    search: {
        tblName: 'tratype',
        editExternal: false,
        recordExists: 'TRANSPORTATION_TYPE_ALREADY_EXIST',
        fields: [
            [
                {
                    label: 'TRANSPORTATION_TYPE.FIELDS.TRATYP',
                    name: 'traTyp',
                    value: '',
                    valueKey: 'traTyp',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'TRANSPORTATION_TYPE_DOES_NOT_EXIST',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH', messageParam: { max_char: 10 } }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'TRANSPORTATION_TYPE.MODEL_DETAIL_TAB.TITLE',
            tabDescription: 'TRANSPORTATION_TYPE.MODEL_DETAIL_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'traType',
            sections: [
                {
                    sectionTitle: 'TRANSPORTATION_TYPE.MODEL_DETAIL_TAB.SECTIONS.MODEL_DETAIL',
                    fields: [
                        [
                            {
                                label: 'TRANSPORTATION_TYPE.FIELDS.TRATYP',
                                name: 'traTyp',
                                value: '',
                                valueKey: 'traTyp',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                            {
                                label: 'TRANSPORTATION_TYPE.FIELDS.TRAMODE',
                                name: 'traMode',
                                value: '',
                                valueKey: 'traMode',
                                type: 'select',
                                inputType: 'select',
                                option: 'transportationModes',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                editableFieldType: 2,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'TRANSPORTATION_TYPE.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'input',
                                inputType: 'datepicker',
                                option: '',
                                fieldType: 'createdOn',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'TRANSPORTATION_TYPE.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'input',
                                inputType: 'datepicker',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ]
                    ]
                }
            ]
        },
    ]
};
