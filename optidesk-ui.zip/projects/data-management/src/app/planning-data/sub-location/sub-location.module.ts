import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SubLocationRoutingModule } from './sub-location-routing.module';
import { SubLocationComponent } from './sub-location.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
    declarations: [SubLocationComponent],
    imports: [
        CommonModule,
        SubLocationRoutingModule,
        ComponentsModule
    ]
})
export class SubLocationModule { }
