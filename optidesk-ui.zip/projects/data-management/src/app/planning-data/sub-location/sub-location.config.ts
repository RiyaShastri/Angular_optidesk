import { Validators } from '@angular/forms';

export const SUB_LOCATIONS_CONFIG = {
    moduleName: 'SUB_LOCATIONS',
    moduleLabel: 'SUB_LOCATIONS.TITLE',
    moduleDescription: 'SUB_LOCATIONS.DESCRIPTION',
    masterData: [],
    search: {
        tblName: 'subLoc',
        editExternal: false,
        recordExists: 'SUB_LOCATIONS_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'SUB_LOCATIONS.FIELDS.PLANT',
                    name: 'plant',
                    value: '',
                    valueKey: 'plant',
                    childKey: 'sloc',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'LOCATION_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(5), message: 'ENTER_VALID_PLANT' }
                    ]
                },
                {
                    label: 'SUB_LOCATIONS.FIELDS.SLOC',
                    name: 'sloc',
                    value: '',
                    valueKey: 'sloc',
                    childKey: '',
                    parentKeys: ['plant'],
                    childTableKey: [],
                    parentColumn: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'LOCATION_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(5), message: 'ENTER_VALID_SLOC' }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'SUB_LOCATIONS.DETAIL_TAB.TITLE',
            tabDescription: 'SUB_LOCATIONS.DETAIL_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'subLocations',
            sections: [
                {
                    sectionTitle: 'SUB_LOCATIONS.DETAIL_TAB.SECTIONS.LOCATION_DETAIL',
                    fields: [
                        [
                            {
                                label: 'SUB_LOCATIONS.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_LOCATION_NO'
                                    }
                                ]
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.PLANT',
                                name: 'plant',
                                value: '',
                                valueKey: 'plant',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.SLOC',
                                name: 'subLoc',
                                value: '',
                                valueKey: 'subLoc',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SUB_LOCATIONS.FIELDS.SLOCNAME',
                                name: 'subLocName',
                                value: '',
                                valueKey: 'subLocName',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(40), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 40 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'SUB_LOCATIONS.FIELDS.VENDOR',
                                name: 'vendor',
                                value: '',
                                valueKey: 'vendor',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.CUSTOMER',
                                name: 'customer',
                                value: '',
                                valueKey: 'customer',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SUB_LOCATIONS.FIELDS.DIVISION',
                                name: 'division',
                                value: '',
                                valueKey: 'division',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.SALESORG',
                                name: 'salesOrg',
                                value: '',
                                valueKey: 'salesOrg',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SUB_LOCATIONS.FIELDS.SLOCMRPIND',
                                name: 'subLocMrpInd',
                                value: '',
                                valueKey: 'subLocMrpInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 1 }
                                    }
                                ]
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.STORRESIND',
                                name: 'storResInd',
                                value: '',
                                valueKey: 'storResInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 1 }
                                    }
                                ]
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.STORTANKIND',
                                name: 'storTankInd',
                                value: '',
                                valueKey: 'storTankInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 1 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SUB_LOCATIONS.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'createdOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'SUB_LOCATIONS.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ]
                    ]
                }
            ]
        },
    ]
};
