import { Component, OnInit, ViewChild } from '@angular/core';
import { SUB_LOCATIONS_CONFIG } from './sub-location.config';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';

@Component({
    selector: 'app-sub-location',
    templateUrl: './sub-location.component.html',
    styleUrls: ['./sub-location.component.css']
})
export class SubLocationComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = SUB_LOCATIONS_CONFIG;
    moduleData: any = {};
    displayRecord = false;
    pageType = CONSTANTS.VIEW;
    resetForm = false;
    baseUrl = '/planning-data/sub-location';
    breadCrumb = {
        label: 'SUB_LOCATIONS.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'SUB_LOCATIONS.SIDE_BAR_MANUES.VIEW_SUB_LOCATIONS',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        }
    ];

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
    }

    searchCriteria(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
