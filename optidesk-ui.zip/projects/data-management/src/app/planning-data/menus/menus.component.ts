import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-menus',
    templateUrl: './menus.component.html',
    styleUrls: ['./menus.component.css']
})
export class MenusComponent implements OnInit {
    breadCrumb = {};
    baseUrl = '/planning-data';
    menus = [
        [
            {
                label: 'HOLIDAY_CALENDAR.TITLE',
                routerLink: this.baseUrl + '/holiday-calendar'
            },
            {
                label: 'WORKING_CALENDAR.TITLE',
                routerLink: this.baseUrl + '/working-calendar'
            }
        ],
        [
            {
                label: 'PLANT.TITLE',
                routerLink: this.baseUrl + '/plant'
            },
            {
                label: 'SUB_LOCATIONS.TITLE',
                routerLink: this.baseUrl + '/sub-location'
            },
            {
                label: 'VENDOR.TITLE',
                routerLink: this.baseUrl + '/vendor'
            },
            {
                label: 'CUSTOMER.TITLE',
                routerLink: this.baseUrl + '/customer'
            }
        ],
        [
            {
                label: 'MATERIAL.TITLE',
                routerLink: this.baseUrl + '/material'
            }
        ],
        [
            {
                label: 'LOCATION_MATERIAL.TITLE',
                routerLink: this.baseUrl + '/location-material'
            }
        ],
        [
            {
                label: 'MODEL.TITLE',
                routerLink: this.baseUrl + '/model'
            },
            {
                label: 'MODEL_LOCATION.TITLE',
                routerLink: this.baseUrl + '/model-location'
            },
            {
                label: 'MODEL_MATERIAL.TITLE',
                routerLink: this.baseUrl + '/model-material'
            },
            {
                label: 'MODEL_LOCATION_MATERIAL.TITLE',
                routerLink: this.baseUrl + '/model-location-material'
            }
        ],
        [
            {
                label: 'TRANSPORTATION_LANES.TITLE',
                routerLink: this.baseUrl + '/transportation-lanes'
            },
            {
                label: 'TRANSPORTATION_TYPE.TITLE',
                routerLink: this.baseUrl + '/transportation-type'
            }
        ],
        [
            {
                label: 'RESOURCE.TITLE',
                routerLink: this.baseUrl + '/resources'
            },
            {
                label: 'SHIFT_CAPACITY.TITLE',
                routerLink: this.baseUrl + '/shift-capacity'
            }
        ]
    ];

    constructor() { }

    ngOnInit(): void { }

}
