import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelLocationMaterialComponent } from './model-location-material.component';

describe('ModelLocationMaterialComponent', () => {
  let component: ModelLocationMaterialComponent;
  let fixture: ComponentFixture<ModelLocationMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelLocationMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelLocationMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
