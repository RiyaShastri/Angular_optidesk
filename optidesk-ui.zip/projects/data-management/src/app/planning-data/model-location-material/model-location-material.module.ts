import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelLocationMaterialRoutingModule } from './model-location-material-routing.module';
import { ModelLocationMaterialComponent } from './model-location-material.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
    declarations: [ModelLocationMaterialComponent],
    imports: [
        CommonModule,
        ModelLocationMaterialRoutingModule,
        ComponentsModule
    ]
})
export class ModelLocationMaterialModule { }
