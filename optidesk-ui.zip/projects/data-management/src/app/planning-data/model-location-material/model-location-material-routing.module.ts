import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModelLocationMaterialComponent } from './model-location-material.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: ModelLocationMaterialComponent
            },
            {
                path: 'edit',
                component: ModelLocationMaterialComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ModelLocationMaterialRoutingModule { }
