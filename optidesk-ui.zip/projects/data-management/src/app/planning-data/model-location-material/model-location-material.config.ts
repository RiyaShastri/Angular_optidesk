import { Validators } from '@angular/forms';
import { checkCombination } from 'src/app/components/form-validator/form.validator';

export const MODEL_LOCATION_MATERIAL_CONFIG = {
    moduleName: 'MODEL_LOCATION_MATERIAL',
    moduleLabel: 'MODEL_LOCATION_MATERIAL.TITLE',
    moduleDescription: 'MODEL_LOCATION_MATERIAL.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'locNos',
            reqObj: {
                columnName: 'locNo',
                tableName: 'locMat',
                requestedColumnParentTable: 'location',
                requestedColumnParentColumn: 'locId',
            }
        }
    ],
    search: {
        tblName: 'model',
        editExternal: false,
        fields: [
            [
                {
                    label: 'MODEL_LOCATION_MATERIAL.FIELDS.MODELID',
                    name: 'modelId',
                    value: '',
                    valueKey: 'modelId',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'MODEL_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        {
                            name: 'maxlength', validator: Validators.maxLength(3), message: 'MAX_LENGTH',
                            messageParam: { max_char: 3 }
                        }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'MODEL_LOCATION_MATERIAL.DETAIL_TAB.TITLE',
            tabDescription: 'MODEL_LOCATION_MATERIAL.DETAIL_TAB.DESCRIPTION',
            tabView: 'TABLE',
            tblName: 'modelLocationMaterials',
            validations: [],
            sections: [
                {
                    sectionTitle: 'MODEL_LOCATION_MATERIAL.DETAIL_TAB.SECTIONS.MODEL_DETAIL',
                    fields: [
                        [
                            {
                                label: 'MODEL_LOCATION_MATERIAL.FIELDS.MODELID',
                                name: 'modelId',
                                value: '',
                                valueKey: 'modelId',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(3), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 3 }
                                    }
                                ]
                            },
                            {
                                label: 'MODEL_LOCATION_MATERIAL.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: 'select',
                                inputType: 'select',
                                option: 'locNos',
                                width: 'full',
                                fieldType: '',
                                isFillChildDropList: true,
                                isEditable: true,
                                isEditableInTable: false,
                                masterDataKey: 'matNos',
                                reqObj: {
                                    columnName: 'matNo',
                                    tableName: 'locMat',
                                    parentKeys: ['locNo'],
                                    childTableKey: ['location'],
                                    parentColumn: ['locId'],
                                    requestedColumnParentTable: 'material',
                                    requestedColumnParentColumn: 'matId',
                                },
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 20 }
                                    }
                                ]
                            },
                            {
                                label: 'MODEL_LOCATION_MATERIAL.FIELDS.MATNO',
                                name: 'matNo',
                                value: '',
                                valueKey: 'matNo',
                                type: 'select',
                                inputType: 'select',
                                option: 'matNos',
                                width: 'full',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 20 }
                                    },
                                    {
                                        name: 'checkCombination', validator: checkCombination('locNo'),
                                        message: 'DUPLICATE_LOCATION_MATERIAL'
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'MODEL_LOCATION_MATERIAL.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'createdOn',
                                option: '',
                                isEditable: false,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'MODEL_LOCATION_MATERIAL.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                isEditableInTable: false,
                                validations: []
                            },
                            {
                                label: 'MODEL_LOCATION_MATERIAL.FIELDS.ACTIND',
                                name: 'actInd',
                                value: '',
                                valueKey: 'actInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
