import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlantRoutingModule } from './plant-routing.module';
import { PlantComponent } from './plant.component';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
    declarations: [PlantComponent],
    imports: [
        CommonModule,
        PlantRoutingModule,
        ComponentsModule
    ]
})
export class PlantModule { }
