import { Component, OnInit, ViewChild } from '@angular/core';
import { PLANT_CONFIG } from './plant.config';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';

@Component({
    selector: 'app-plant',
    templateUrl: './plant.component.html',
    styleUrls: ['./plant.component.css']
})
export class PlantComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = PLANT_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    resetForm = false;
    pageType = CONSTANTS.VIEW;
    baseUrl = '/planning-data/plant';
    breadCrumb = {
        label: 'PLANT.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'PLANT.SIDE_BAR_MANUES.VIEW_PLANT',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'PLANT.SIDE_BAR_MANUES.EDIT_PLANT',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        }
    ];
    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
    }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displatPageContent(searchedCriteria);
            });
        } else {
            this.displatPageContent(searchedCriteria);
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.displayRecord = false;
        this.resetForm = true;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
