import { Validators } from '@angular/forms';

export const PLANT_CONFIG = {
    moduleName: 'PLANT',
    moduleLabel: 'PLANT.TITLE',
    moduleDescription: 'PLANT.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'holCalKeys',
            reqObj: {
                columnName: 'holCalKey',
                tableName: 'holcal'
            }
        },
        {
            masterDataKey: 'workCalKeys',
            reqObj: {
                columnName: 'workCalKey',
                tableName: 'workcal'
            }
        }
    ],
    search: {
        tblName: 'plant',
        editExternal: true,
        fields: [
            [
                {
                    label: 'PLANT.FIELDS.PLANT',
                    name: 'plant',
                    value: '',
                    valueKey: 'plant',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'LOCATION_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH', messageParam: { max_char: 10 } }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'PLANT.PLANT_TAB.TITLE',
            tabDescription: 'PLANT.PLANT_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'plants',
            sections: [
                {
                    sectionTitle: 'PLANT.PLANT_TAB.SECTIONS.LOCATION_DETAILS',
                    fields: [
                        [
                            {
                                label: 'PLANT.FIELDS.LOCID',
                                name: 'locId',
                                value: '',
                                valueKey: 'locId',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_LOCATION_NO',
                                    }
                                ]
                            },
                            {
                                label: 'PLANT.FIELDS.PLANT',
                                name: 'plant',
                                value: '',
                                valueKey: 'plant',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.PLANTNAME',
                                name: 'plantName',
                                value: '',
                                valueKey: 'plantName',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(40), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 40 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.VENDOR',
                                name: 'vendor',
                                value: '',
                                valueKey: 'vendor',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                            {
                                label: 'PLANT.FIELDS.CUSTOMER',
                                name: 'customer',
                                value: '',
                                valueKey: 'customer',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                option: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.WORKCALKEY',
                                name: 'workCalKey',
                                value: '',
                                valueKey: 'workCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'workCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'ENTER_VALID_WORKCALKEY'
                            },
                            {
                                label: 'PLANT.FIELDS.HOLCALKEY',
                                name: 'holCalKey',
                                value: '',
                                valueKey: 'holCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'holCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'ENTER_VALID_HOLCALKEY'
                            }
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.CTRYKEY',
                                name: 'ctryKey',
                                value: '',
                                valueKey: 'ctryKey',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                            {
                                label: 'PLANT.FIELDS.POSTCODE',
                                name: 'postCode',
                                value: '',
                                valueKey: 'postCode',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.DIVISION',
                                name: 'division',
                                value: '',
                                valueKey: 'division',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                custom: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ],
                            },
                            {
                                label: 'PLANT.FIELDS.DISTCHANNEL',
                                name: 'distChannel',
                                value: '',
                                valueKey: 'distChannel',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.SALESORG',
                                name: 'salesOrg',
                                value: '',
                                valueKey: 'salesOrg',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                            {
                                label: 'PLANT.FIELDS.PURCHORG',
                                name: 'purchOrg',
                                value: '',
                                valueKey: 'purchOrg',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                option: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.PLANTCTGY',
                                name: 'plantCtgy',
                                value: '',
                                valueKey: 'plantCtgy',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                option: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                            {
                                label: 'PLANT.FIELDS.NODETYP',
                                name: 'nodeTyp',
                                value: '',
                                valueKey: 'nodeTyp',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                option: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                custom: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'PLANT.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'input',
                                inputType: 'datepicker',
                                option: '',
                                fieldType: 'createdOn',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'PLANT.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'input',
                                inputType: 'datepicker',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ]
                    ]
                }
            ]
        },
    ]
};
