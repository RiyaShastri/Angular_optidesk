import { Validators } from '@angular/forms';

export const CUSTOMER_CONFIG = {
    moduleName: 'CUSTOMER',
    moduleLabel: 'CUSTOMER.TITLE',
    moduleDescription: 'CUSTOMER.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'holCalKeys',
            reqObj: {
                columnName: 'holCalKey',
                tableName: 'holcal'
            }
        },
        {
            masterDataKey: 'workCalKeys',
            reqObj: {
                columnName: 'workCalKey',
                tableName: 'workcal'
            }
        }
    ],
    search: {
        tblName: 'customer',
        editExternal: true,
        fields: [
            [
                {
                    label: 'CUSTOMER.FIELDS.CUSTOMER',
                    name: 'customer',
                    value: '',
                    valueKey: 'customer',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'LOCATION_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH', messageParam: { max_char: 10 } }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'CUSTOMER.CUSTOMER_TAB.TITLE',
            tabDescription: 'CUSTOMER.CUSTOMER_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'customers',
            sections: [
                {
                    sectionTitle: 'CUSTOMER.CUSTOMER_TAB.SECTIONS.LOCATION_DETAILS',
                    fields: [
                        [
                            {
                                label: 'CUSTOMER.FIELDS.LOCID',
                                name: 'locId',
                                value: '',
                                valueKey: 'locId',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_LOCATION_NO'
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.CUSTOMER',
                                name: 'customer',
                                value: '',
                                valueKey: 'customer',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                            {
                                label: 'CUSTOMER.FIELDS.CUSTNAME',
                                name: 'customerName',
                                value: '',
                                valueKey: 'customerName',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                width: 'full',
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(40), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 40 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.PLANT',
                                name: 'plant',
                                value: '',
                                valueKey: 'plant',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                            {
                                label: 'CUSTOMER.FIELDS.CUSTOMER',
                                name: 'vendor',
                                value: '',
                                valueKey: 'vendor',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.WORKCALKEY',
                                name: 'workCalKey',
                                value: '',
                                valueKey: 'workCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'workCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'ENTER_VALID_WORKCALKEY'
                            },
                            {
                                label: 'CUSTOMER.FIELDS.HOLCALKEY',
                                name: 'holCalKey',
                                value: '',
                                valueKey: 'holCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'holCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'ENTER_VALID_HOLCALKEY'
                            }
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.CTRYKEY',
                                name: 'ctryKey',
                                value: '',
                                valueKey: 'ctryKey',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ]
                            },
                            {
                                label: 'CUSTOMER.FIELDS.POSTCODE',
                                name: 'postCode',
                                value: '',
                                valueKey: 'postCode',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                custom: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'CUSTOMER.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'input',
                                inputType: 'datepicker',
                                option: '',
                                fieldType: 'createdOn',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'CUSTOMER.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'input',
                                inputType: 'datepicker',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ]
                    ]
                }
            ]
        },
    ]
};
