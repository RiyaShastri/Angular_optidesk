import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelLocationRoutingModule } from './model-location-routing.module';
import { ModelLocationComponent } from './model-location.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
    declarations: [ModelLocationComponent],
    imports: [
        CommonModule,
        ModelLocationRoutingModule,
        ComponentsModule
    ]
})
export class ModelLocationModule { }
