import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelLocationComponent } from './model-location.component';

describe('ModelLocationComponent', () => {
  let component: ModelLocationComponent;
  let fixture: ComponentFixture<ModelLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
