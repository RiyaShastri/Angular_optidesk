import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModelLocationComponent } from './model-location.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: ModelLocationComponent
            },
            {
                path: 'edit',
                component: ModelLocationComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ModelLocationRoutingModule { }
