import { Validators } from '@angular/forms';
import { noDuplicatValue } from 'src/app/components/form-validator/form.validator';

export const MODEL_LOCATION_CONFIG = {
    moduleName: 'MODEL_LOCATION',
    moduleLabel: 'MODEL_LOCATION.TITLE',
    moduleDescription: 'MODEL_LOCATION.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'locNos',
            reqObj: {
                columnName: 'locNo',
                tableName: 'location'
            }
        }
    ],
    search: {
        tblName: 'model',
        editExternal: false,
        fields: [
            [
                {
                    label: 'MODEL_LOCATION.FIELDS.MODELID',
                    name: 'modelId',
                    value: '',
                    valueKey: 'modelId',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'MODEL_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        {
                            name: 'maxlength', validator: Validators.maxLength(3), message: 'MAX_LENGTH',
                            messageParam: { max_char: 3 }
                        }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'MODEL_LOCATION.DETAIL_TAB.TITLE',
            tabDescription: 'MODEL_LOCATION.DETAIL_TAB.DESCRIPTION',
            tabView: 'TABLE',
            tblName: 'modelLocations',
            validations: [],
            sections: [
                {
                    sectionTitle: 'MODEL_LOCATION.DETAIL_TAB.SECTIONS.MODEL_DETAIL',
                    fields: [
                        [
                            {
                                label: 'MODEL_LOCATION.FIELDS.MODELID',
                                name: 'modelId',
                                value: '',
                                valueKey: 'modelId',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(3), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 3 }
                                    }
                                ]
                            },
                            {
                                label: 'MODEL_LOCATION.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: 'select',
                                inputType: 'select',
                                option: 'locNos',
                                width: 'full',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 20 }
                                    },
                                    { name: 'noDuplicatValue', validator: noDuplicatValue(), message: 'LOCATION_NO_ALREADY_EXIST' }
                                ]
                            },
                            {
                                label: 'MODEL_LOCATION.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'createdOn',
                                option: '',
                                isEditable: false,
                                isEditableInTable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'MODEL_LOCATION.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                isEditableInTable: false,
                                validations: []
                            },
                            {
                                label: 'MODEL_LOCATION.FIELDS.ACTIND',
                                name: 'actInd',
                                value: '',
                                valueKey: 'actInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
