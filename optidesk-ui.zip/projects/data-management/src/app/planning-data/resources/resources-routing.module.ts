import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ResourcesComponent } from './resources.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: ResourcesComponent,
                canDeactivate: [CanDeactivatGuard]
            },
            {
                path: 'edit',
                component: ResourcesComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ResourcesRoutingModule { }
