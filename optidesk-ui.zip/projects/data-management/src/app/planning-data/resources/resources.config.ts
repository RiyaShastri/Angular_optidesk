import { Validators } from '@angular/forms';
import { compareStartTime, compareFinishTime, checkBreakTime } from 'src/app/components/form-validator/form.validator';

export const RESOURCE_CONFIG = {
    moduleName: 'RESOURCE',
    moduleLabel: 'RESOURCE.TITLE',
    moduleDescription: 'RESOURCE.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'holCalKeys',
            reqObj: {
                columnName: 'holCalKey',
                tableName: 'holcal'
            }
        },
        {
            masterDataKey: 'workCalKeys',
            reqObj: {
                columnName: 'workCalKey',
                tableName: 'workcal'
            }
        },
        {
            masterDataKey: 'plants',
            reqObj: {
                columnName: 'plant',
                tableName: 'plant'
            }
        },
        {
            masterDataKey: 'vendors',
            reqObj: {
                columnName: 'vendor',
                tableName: 'vendor'
            }
        },
        {
            masterDataKey: 'sLocs',
            reqObj: {
                columnName: 'sLoc',
                tableName: 'subLoc'
            }
        },
    ],
    search: {
        tblName: 'resource',
        editExternal: true,
        fields: [
            [
                {
                    label: 'RESOURCE.FIELDS.RESOURCE',
                    name: 'resNo',
                    value: '',
                    valueKey: 'resNo',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'RESOURCE_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(30), message: 'MAX_LENGTH', messageParam: { max_char: 30 } }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'RESOURCE.RESOURCE_TAB.TITLE',
            tabDescription: 'RESOURCE.RESOURCE_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'resources',
            sections: [
                {
                    sectionTitle: 'RESOURCE.RESOURCE_TAB.SECTIONS.RESOURCES_DETAILS',
                    fields: [
                        [
                            {
                                label: 'RESOURCE.FIELDS.RESNO',
                                name: 'resNo',
                                value: '',
                                valueKey: 'resNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.OBJID',
                                name: 'objId',
                                value: '',
                                valueKey: 'objId',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_LOCATION_NO',
                                    }
                                ]
                            },
                            {
                                label: 'RESOURCE.FIELDS.CAPID',
                                name: 'capId',
                                value: '',
                                valueKey: 'capId',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 20 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.WRKCTR',
                                name: 'wrkctr',
                                value: '',
                                valueKey: 'wrkctr',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 20 }
                                    }
                                ]
                            },
                            {
                                label: 'RESOURCE.FIELDS.CAPCAT',
                                name: 'capCat',
                                value: '',
                                valueKey: 'capCat',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(20), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 20 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.PLANTID',
                                name: 'plant',
                                value: '',
                                valueKey: 'plant',
                                type: 'select',
                                inputType: 'select',
                                option: 'plants',
                                fieldType: 'null',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                ]
                            },
                            {
                                label: 'RESOURCE.FIELDS.VENDORID',
                                name: 'vendor',
                                value: '',
                                valueKey: 'vendor',
                                type: 'select',
                                inputType: 'select',
                                option: 'vendors',
                                fieldType: 'null',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'RESOURCE.FIELDS.SLOC',
                                name: 'sLoc',
                                value: '',
                                valueKey: 'sLoc',
                                type: 'select',
                                inputType: 'select',
                                option: 'sLocs',
                                fieldType: 'null',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 10 }
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.SETUPKEY',
                                name: 'setUpKey',
                                value: '',
                                valueKey: 'setUpKey',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.NOCAP',
                                name: 'noCap',
                                value: '',
                                valueKey: 'noCap',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                ]
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.STRTIME',
                                name: 'strTime',
                                value: '',
                                valueKey: 'strTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'compareStartTime', validator: compareStartTime('finTime'), message: 'ENTER_VALID_START_TIME' }
                                ]
                            },
                            {
                                label: 'RESOURCE.FIELDS.FINTIME',
                                name: 'finTime',
                                value: '',
                                valueKey: 'finTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'compareFinishTime', validator: compareFinishTime('strTime'),
                                        message: 'ENTER_VALID_FINISH_TIME'
                                    }
                                ]
                            },
                            {
                                label: 'RESOURCE.FIELDS.BRKTIME',
                                name: 'brkTime',
                                value: '',
                                valueKey: 'brkTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'checkBreakTime', validator: checkBreakTime('strTime', 'finTime'),
                                        message: 'ENTER_VALID_BREAK_TIME'
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.CAPUTIL',
                                name: 'capUtil',
                                value: '',
                                valueKey: 'capUtil',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'twoDecimalOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'max', validator: Validators.max(100),
                                        message: 'ENTER_VALID_CAPACITY_UTILIZATION'
                                    }
                                ],
                            },
                            {
                                label: 'RESOURCE.FIELDS.OVERLOAD',
                                name: 'overload',
                                value: '',
                                valueKey: 'overload',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'min', validator: Validators.min(100), message: 'ENTER_VALID_CAPACITY_OVERLOAD',
                                    },
                                    {
                                        name: 'max', validator: Validators.max(120), message: 'ENTER_VALID_CAPACITY_OVERLOAD',
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.WORKCALKEY',
                                name: 'workCalKey',
                                value: '',
                                valueKey: 'workCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'workCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'ENTER_VALID_WORKCALKEY'
                            },
                            {
                                label: 'RESOURCE.FIELDS.HOLCALKEY',
                                name: 'holCalKey',
                                value: '',
                                valueKey: 'holCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'holCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'ENTER_VALID_HOLCALKEY'
                            }
                        ],
                        [
                            {
                                label: 'RESOURCE.FIELDS.SCHEDIND',
                                name: 'schedInd',
                                value: '',
                                valueKey: 'schedInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            },
                            {
                                label: 'RESOURCE.FIELDS.MIXIND',
                                name: 'mixInd',
                                value: '',
                                valueKey: 'mixInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            },
                            {
                                label: 'RESOURCE.FIELDS.MULOPIND',
                                name: 'mulOpInd',
                                value: '',
                                valueKey: 'mulOpInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1),
                                        message: 'MAX_LENGTH', messageParam: { max_char: 1 }
                                    }
                                ],
                            }
                        ]
                    ]
                }
            ]
        },
    ]
};
