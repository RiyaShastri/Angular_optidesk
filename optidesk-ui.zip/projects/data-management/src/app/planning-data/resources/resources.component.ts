import { Component, OnInit, ViewChild } from '@angular/core';
import { RESOURCE_CONFIG } from './resources.config';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';

@Component({
    selector: 'app-resources',
    templateUrl: './resources.component.html',
    styleUrls: ['./resources.component.css']
})
export class ResourcesComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = RESOURCE_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    resetForm = false;
    pageType = CONSTANTS.VIEW;
    baseUrl = '/planning-data/resources';
    breadCrumb = {
        label: 'RESOURCE.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'RESOURCE.SIDE_BAR_MANUES.VIEW_RESOURCE',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'RESOURCE.SIDE_BAR_MANUES.EDIT_RESOURCE',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        }
    ];
    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
    }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displatPageContent(searchedCriteria);
            });
        } else {
            this.displatPageContent(searchedCriteria);
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.displayRecord = false;
        this.resetForm = true;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
