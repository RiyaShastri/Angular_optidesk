import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocationMaterialRoutingModule } from './location-material-routing.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { LocationMaterialComponent } from './location-material.component';


@NgModule({
    declarations: [LocationMaterialComponent],
    imports: [
        CommonModule,
        LocationMaterialRoutingModule,
        ComponentsModule
    ]
})
export class LocationMaterialModule { }
