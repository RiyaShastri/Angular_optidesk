import { Validators } from '@angular/forms';

export const LOCATION_MATERIAL_CONFIG = {
    moduleName: 'LOCATION_MATERIAL',
    moduleLabel: 'LOCATION_MATERIAL.TITLE',
    moduleDescription: 'LOCATION_MATERIAL.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'lotSzs',
            reqObj: {
                columnName: 'lotSz',
                tableName: 'lotSize'
            }
        },
        {
            masterDataKey: 'procTyps',
            reqObj: {
                columnName: 'procTyp',
                tableName: 'procType'
            }
        },
        {
            masterDataKey: 'mrpTyps',
            reqObj: {
                columnName: 'mrpTyp',
                tableName: 'mrpType'
            }
        },
        {
            masterDataKey: 'planStrs',
            reqObj: {
                columnName: 'planStr',
                tableName: 'planStrat'
            }
        }
    ],
    search: {
        tblName: 'locMat',
        editExternal: false,
        recordExists: 'LOCATION_MATERIAL_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'LOCATION_MATERIAL.FIELDS.LOCNO',
                    name: 'locNo',
                    value: '',
                    valueKey: 'locNo',
                    childKey: 'matNo',
                    parentKeys: [],
                    requestedColumnParentTable: 'location',
                    requestedColumnParentColumn: 'locId',
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'LOCATION_MATERIAL_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_LOCNO' }
                    ]
                },
                {
                    label: 'LOCATION_MATERIAL.FIELDS.MATNO',
                    name: 'matNo',
                    value: '',
                    valueKey: 'MATNO',
                    childKey: '',
                    parentKeys: ['locNo'],
                    childTableKey: ['location'],
                    parentColumn: ['locId'],
                    requestedColumnParentTable: 'material',
                    requestedColumnParentColumn: 'matId',
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'LOCATION_MATERIAL_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_MATNO' }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'LOCATION_MATERIAL.GENERAL_DATA_TAB.TITLE',
            tabDescription: 'LOCATION_MATERIAL.GENERAL_DATA_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'generalInformation',
            validations: [],
            sections: [
                {
                    sectionTitle: 'LOCATION_MATERIAL.GENERAL_DATA_TAB.SECTIONS.GENERAL_DATA',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MATNO',
                                name: 'matNo',
                                value: '',
                                valueKey: 'matNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MRPTYP',
                                name: 'mrpTyp',
                                value: '',
                                valueKey: 'mrpTyp',
                                type: 'select',
                                inputType: 'select',
                                option: 'mrpTyps',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.PROCTYP',
                                name: 'procTyp',
                                value: '',
                                valueKey: 'procTyp',
                                type: 'select',
                                inputType: 'select',
                                option: 'procTyps',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.PLANSTR',
                                name: 'planStr',
                                value: '',
                                valueKey: 'planStr',
                                type: 'select',
                                inputType: 'select',
                                option: 'planStrs',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ],
                            },
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.ISSUESLOC',
                                name: 'issueSLoc',
                                value: '',
                                valueKey: 'issueSLoc',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.RECVSLOC',
                                name: 'recvSloc',
                                value: '',
                                valueKey: 'recvSloc',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                    ]
                }
            ]
        },
        {
            tabTitle: 'LOCATION_MATERIAL.PROCUREMENT_TAB.TITLE',
            tabDescription: 'LOCATION_MATERIAL.PROCUREMENT_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'procurements',
            validations: [],
            sections: [
                {
                    sectionTitle: 'LOCATION_MATERIAL.PROCUREMENT_TAB.SECTIONS.LEAD_TIME',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MATNO',
                                name: 'matNo',
                                value: '',
                                valueKey: 'matNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.DELVTIME',
                                name: 'delvTime',
                                value: '',
                                valueKey: 'delvTime',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.GRTIME',
                                name: 'grTime',
                                value: '',
                                valueKey: 'grTime',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.GITIME',
                                name: 'gitTime',
                                value: '',
                                valueKey: 'gitTime',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                        ],
                    ]
                },
                {
                    sectionTitle: 'LOCATION_MATERIAL.PROCUREMENT_TAB.SECTIONS.LOT_PLANNING',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.LOTSZ',
                                name: 'lotSz',
                                value: '',
                                valueKey: 'lotSz',
                                type: 'select',
                                inputType: 'select',
                                option: 'lotSzs',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(5), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 5 }
                                    }
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MINLS',
                                name: 'minLs',
                                value: '',
                                valueKey: 'minLs',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MAXLS',
                                name: 'maxLs',
                                value: '',
                                valueKey: 'maxLs',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.FIXLS',
                                name: 'fixLs',
                                value: '',
                                valueKey: 'fixLs',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.INCLS',
                                name: 'incLs',
                                value: '',
                                valueKey: 'incLs',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            }
                        ],
                    ]
                },
                {
                    sectionTitle: 'LOCATION_MATERIAL.PROCUREMENT_TAB.SECTIONS.SAFETY_STOCK_PLANNING',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.SFTYSTK',
                                name: 'sftyStk',
                                value: '',
                                valueKey: 'sftyStk',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MINDAYS',
                                name: 'minDays',
                                value: '',
                                valueKey: 'minDays',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MAXDAYS',
                                name: 'maxDays',
                                value: '',
                                valueKey: 'maxDays',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.ROP',
                                name: 'rop',
                                value: '',
                                valueKey: 'rop',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MAXSTK',
                                name: 'maxStk',
                                value: '',
                                valueKey: 'maxStk',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,20}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ],
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.SRVLVL',
                                name: 'srvLvl',
                                value: '',
                                valueKey: 'srvLvl',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'threeDecimalOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'pattern', validator: Validators.pattern('^[0-9]{0,5}(\.?[0-9]{0,3}?)$'),
                                        message: 'INVALID_VALUE'
                                    }
                                ]
                            }
                        ]
                    ]
                },
                {
                    sectionTitle: 'LOCATION_MATERIAL.PROCUREMENT_TAB.SECTIONS.SAFETY_TIME',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.SFTYTIMIND',
                                name: 'sftyTimInd',
                                value: '',
                                valueKey: 'sftyTimInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'ynDropDown',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.SFTYTIM',
                                name: 'sftyTim',
                                value: '',
                                valueKey: 'sftyTim',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            }
                        ]
                    ]
                },
                {
                    sectionTitle: 'LOCATION_MATERIAL.PROCUREMENT_TAB.SECTIONS.SOURCE_DETERMINATION',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.SRCLIST',
                                name: 'srcList',
                                value: '',
                                valueKey: 'srcList',
                                type: 'select',
                                inputType: 'select',
                                option: 'ynDropDown',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        },
        {
            tabTitle: 'LOCATION_MATERIAL.PRODUCTION_AND_DISTRIBUTION_TAB.TITLE',
            tabDescription: 'LOCATION_MATERIAL.PRODUCTION_AND_DISTRIBUTION_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'productionDistributions',
            validations: [],
            sections: [
                {
                    sectionTitle: 'LOCATION_MATERIAL.PRODUCTION_AND_DISTRIBUTION_TAB.SECTIONS.PRODUCTION',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.LOCNO',
                                name: 'locNo',
                                value: '',
                                valueKey: 'locNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.MATNO',
                                name: 'matNo',
                                value: '',
                                valueKey: 'matNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.PRODHOR',
                                name: 'prodHor',
                                value: '',
                                valueKey: 'prodHor',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.DEPPLAN',
                                name: 'depPlan',
                                value: '',
                                valueKey: 'depPlan',
                                type: 'select',
                                inputType: 'select',
                                option: 'ynDropDown',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 1 }
                                    }
                                ],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.DEPREQ',
                                name: 'depReq',
                                value: '',
                                valueKey: 'depReq',
                                type: 'select',
                                inputType: 'select',
                                option: 'dependentRequirement',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 1 }
                                    }
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                },
                {
                    sectionTitle: 'LOCATION_MATERIAL.PRODUCTION_AND_DISTRIBUTION_TAB.SECTIONS.FORECAST_CONSUMPTION',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.CONSMODE',
                                name: 'consMode',
                                value: '',
                                valueKey: 'consMode',
                                type: 'select',
                                inputType: 'select',
                                option: 'cosmodDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.BWDCONS',
                                name: 'bwdCons',
                                value: '',
                                valueKey: 'bwdCons',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.FWDCONS',
                                name: 'fwdCons',
                                value: '',
                                valueKey: 'fwdCons',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            }
                        ]
                    ]
                },
                {
                    sectionTitle: 'LOCATION_MATERIAL.PRODUCTION_AND_DISTRIBUTION_TAB.SECTIONS.DISTRIBUTION',
                    fields: [
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.DISTHOR',
                                name: 'distHor',
                                value: '',
                                valueKey: 'distHor',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            },
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.PUSHIND',
                                name: 'pushInd',
                                value: '',
                                valueKey: 'pushInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'pushDistribution',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(10), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 10 }
                                    }
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'LOCATION_MATERIAL.FIELDS.OPENPER',
                                name: 'openPer',
                                value: '',
                                valueKey: 'openPer',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                            }
                        ]
                    ]
                },
            ]
        },
    ]
};
