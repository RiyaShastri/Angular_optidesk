import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LocationMaterialComponent } from './location-material.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: LocationMaterialComponent
            },
            {
                path: 'edit',
                component: LocationMaterialComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LocationMaterialRoutingModule { }
