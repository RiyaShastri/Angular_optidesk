import { Component, OnInit, ViewChild } from '@angular/core';
import { LOCATION_MATERIAL_CONFIG } from './location-material.config';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';

@Component({
    selector: 'app-location-material',
    templateUrl: './location-material.component.html',
    styleUrls: ['./location-material.component.css']
})
export class LocationMaterialComponent implements OnInit {

    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = LOCATION_MATERIAL_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    pageType = CONSTANTS.VIEW;
    resetForm = false;
    baseUrl = '/planning-data/location-material';
    breadCrumb = {
        label: 'LOCATION_MATERIAL.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'LOCATION_MATERIAL.SIDE_BAR_MANUES.VIEW_LOCATION_MATERIAL',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'LOCATION_MATERIAL.SIDE_BAR_MANUES.EDIT_LOCATION_MATERIAL',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        }
    ];

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void { }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displatPageContent(searchedCriteria);
            });
        } else {
            this.displatPageContent(searchedCriteria);
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }
}
