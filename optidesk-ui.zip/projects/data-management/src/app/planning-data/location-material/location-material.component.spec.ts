import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationMaterialComponent } from './location-material.component';

describe('LocationMaterialComponent', () => {
  let component: LocationMaterialComponent;
  let fixture: ComponentFixture<LocationMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
