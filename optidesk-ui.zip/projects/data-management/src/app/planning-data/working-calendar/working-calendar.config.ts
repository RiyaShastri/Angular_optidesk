import { Validators } from '@angular/forms';
import { lessThanOrEqualValidation, greaterThanOrEqualValidation } from 'src/app/components/form-validator/form.validator';

export const WORKING_CALENDAR_CONFIG = {
    moduleName: 'WORKING_CALENDAR',
    moduleLabel: 'WORKING_CALENDAR.TITLE',
    moduleDescription: 'WORKING_CALENDAR.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'holCalKeys',
            reqObj: {
                columnName: 'holCalKey',
                tableName: 'holcal'
            }
        }
    ],
    search: {
        tblName: 'workCal',
        editExternal: false,
        recordExists: 'WORKING_CALENDAR_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'WORKING_CALENDAR.FIELDS.WORKCALKEY',
                    name: 'workCalKey',
                    value: '',
                    valueKey: 'workCalKey',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'WORKING_CALENDAR_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(5), message: 'ENTER_VALID_WORKCALKEY' }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'WORKING_CALENDAR.WORKCAL_TAB.TITLE',
            tabDescription: 'WORKING_CALENDAR.WORKCAL_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'workcal',
            sections: [
                {
                    sectionTitle: 'WORKING_CALENDAR.WORKCAL_TAB.SECTIONS.CALENDAR',
                    fields: [
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.YEARFROM',
                                name: 'yearFrom',
                                value: '',
                                valueKey: 'yearFrom',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'pattern', validator: Validators.pattern('^[0-9]*$'), message: 'INVALID_YEAR_FROM' },
                                    { name: 'minlength', validator: Validators.minLength(4), message: 'MINIMUM_4_DIGITS' },
                                    { name: 'maxlength', validator: Validators.maxLength(4), message: 'MAXIMUM_4_DIGITS' },
                                    // tslint:disable-next-line:max-line-length
                                    { name: 'lessThanOrEqualValidation', validator: lessThanOrEqualValidation('workcal.yearTill'), message: 'INVALID_YEAR_RANGE' }
                                ]
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.YEARTILL',
                                name: 'yearTill',
                                value: '',
                                valueKey: 'yearTill',
                                type: 'input',
                                inputMaskType: 'numbersOnly',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'pattern', validator: Validators.pattern('^[0-9]*$'), message: 'INVALID_YEAR_TILL' },
                                    { name: 'minlength', validator: Validators.minLength(4), message: 'MINIMUM_4_DIGITS' },
                                    { name: 'maxlength', validator: Validators.maxLength(4), message: 'MAXIMUM_4_DIGITS' },
                                    // tslint:disable-next-line:max-line-length
                                    { name: 'greaterThanOrEqualValidation', validator: greaterThanOrEqualValidation('workcal.yearFrom'), message: 'INVALID_YEAR_RANGE' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.MONDAY',
                                name: 'monday',
                                value: false,
                                valueKey: 'monday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.TUESDAY',
                                name: 'tuesday',
                                value: false,
                                valueKey: 'tuesday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.WEDNESDAY',
                                name: 'wednesday',
                                value: false,
                                valueKey: 'wednesday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.THURSDAY',
                                name: 'thursday',
                                value: false,
                                valueKey: 'thursday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.FRIDAY',
                                name: 'friday',
                                value: false,
                                valueKey: 'friday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.SATURDAY',
                                name: 'saturday',
                                value: false,
                                valueKey: 'saturday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.SUNDAY',
                                name: 'sunday',
                                value: false,
                                valueKey: 'sunday',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.HOLCALKEY',
                                name: 'holCalKey',
                                value: '',
                                valueKey: 'holCalKey',
                                type: 'select',
                                inputType: 'select',
                                option: 'holCalKeys',
                                fieldType: 'null',
                                isEditable: true,
                                validations: [],
                                recordExists: 'INVALID_HOLIDAY_CALENDAR_KEY'
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.STARTDAY',
                                name: 'startDay',
                                value: '',
                                valueKey: 'startDay',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                fieldType: '',
                                option: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    // tslint:disable-next-line:max-line-length
                                    { name: 'pattern', validator: Validators.pattern('^[1-7]{1}$'), message: 'INVALID_START_DAY' },
                                ]
                            },
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    // tslint:disable-next-line:max-line-length
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH', messageParam: { max_char: 1 } },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.SRCFLG',
                                name: 'srcFlg',
                                value: '',
                                valueKey: 'srcFlg',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'secondary',
                                isEditable: false,
                                validations: [
                                    // tslint:disable-next-line:max-line-length
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH', messageParam: { max_char: 1 } },
                                ]
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                option: '',
                                fieldType: 'createdOn',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'WORKING_CALENDAR.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ],
                        [
                            {
                                label: 'WORKING_CALENDAR.FIELDS.WORKCALKEY',
                                name: 'workCalKey',
                                value: '',
                                valueKey: 'workCalKey',
                                type: '',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: []
                            }
                        ]
                    ]
                }
            ]
        },
    ]
};
