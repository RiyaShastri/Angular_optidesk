import { Component, OnInit, ViewChild } from '@angular/core';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { WORKING_CALENDAR_CONFIG } from './working-calendar.config';
import { CONSTANTS } from 'src/app/shared/constants';
import { TabComponent } from 'src/app/components';

@Component({
    selector: 'app-working-calendar',
    templateUrl: './working-calendar.component.html',
    styleUrls: ['./working-calendar.component.css']
})
export class WorkingCalendarComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = WORKING_CALENDAR_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    pageType = CONSTANTS.VIEW;
    resetForm = false;
    baseUrl = '/planning-data/working-calendar';
    breadCrumb = {
        label: 'WORKING_CALENDAR.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'WORKING_CALENDAR.SIDE_BAR_MANUES.VIEW_WORKING_CALENDAR',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'WORKING_CALENDAR.SIDE_BAR_MANUES.EDIT_WORKING_CALENDAR',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'WORKING_CALENDAR.SIDE_BAR_MANUES.CREATE_WORKING_CALENDAR',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void { }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displatPageContent(searchedCriteria);
            });
        } else {
            this.displatPageContent(searchedCriteria);
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }
}
