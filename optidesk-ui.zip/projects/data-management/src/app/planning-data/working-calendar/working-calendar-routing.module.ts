import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkingCalendarComponent } from './working-calendar.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: WorkingCalendarComponent
            },
            {
                path: 'edit',
                component: WorkingCalendarComponent,
                canDeactivate: [CanDeactivatGuard]
            },
            {
                path: 'create',
                component: WorkingCalendarComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class WorkingCalendarRoutingModule { }
