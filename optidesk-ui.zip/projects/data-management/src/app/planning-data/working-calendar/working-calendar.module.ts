import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WorkingCalendarRoutingModule } from './working-calendar-routing.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { WorkingCalendarComponent } from './working-calendar.component';


@NgModule({
    declarations: [WorkingCalendarComponent],
    imports: [
        CommonModule,
        WorkingCalendarRoutingModule,
        ComponentsModule
    ]
})
export class WorkingCalendarModule { }
