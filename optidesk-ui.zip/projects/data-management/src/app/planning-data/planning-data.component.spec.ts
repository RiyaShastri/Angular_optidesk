import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanningDataComponent } from './planning-data.component';

describe('PlanningDataComponent', () => {
  let component: PlanningDataComponent;
  let fixture: ComponentFixture<PlanningDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanningDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanningDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
