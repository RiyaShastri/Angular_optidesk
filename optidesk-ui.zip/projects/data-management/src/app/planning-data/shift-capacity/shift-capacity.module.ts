import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShiftCapacityRoutingModule } from './shift-capacity-routing.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { ShiftCapacityComponent } from './shift-capacity.component';


@NgModule({
    declarations: [
        ShiftCapacityComponent
    ],
    imports: [
        CommonModule,
        ShiftCapacityRoutingModule,
        ComponentsModule
    ]
})
export class ShiftCapacityModule { }
