import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShiftCapacityComponent } from './shift-capacity.component';

describe('ShiftCapacityComponent', () => {
  let component: ShiftCapacityComponent;
  let fixture: ComponentFixture<ShiftCapacityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShiftCapacityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShiftCapacityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
