import { Component, OnInit, ViewChild } from '@angular/core';
import { SHIFT_CAPACITY_CONFIG } from './shift-capacity.config';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { CONSTANTS } from 'src/app/shared/constants';
import { TabComponent } from 'src/app/components';

@Component({
    selector: 'app-shift-capacity',
    templateUrl: './shift-capacity.component.html',
    styleUrls: ['./shift-capacity.component.css']
})
export class ShiftCapacityComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = SHIFT_CAPACITY_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    resetForm = false;
    isTableEditable = true;
    pageType = CONSTANTS.VIEW;
    isCreateDropList = true;
    baseUrl = '/planning-data/shift-capacity';
    breadCrumb = {
        label: 'SHIFT_CAPACITY.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'SHIFT_CAPACITY.SIDE_BAR_MANUES.VIEW_SHIFT_CAPACITY',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'SHIFT_CAPACITY.SIDE_BAR_MANUES.EDIT_SHIFT_CAPACITY',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'SHIFT_CAPACITY.SIDE_BAR_MANUES.CREATE_SHIFT_CAPACITY',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];
    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
        if (this.pageType === CONSTANTS.CREATE) {
            this.moduleConfig.search.fields = this.moduleConfig.search.createFields;
        } else {
            this.moduleConfig.search.fields = this.moduleConfig.search.editFields;
        }
    }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displatPageContent(searchedCriteria);
            });
        } else {
            this.displatPageContent(searchedCriteria);
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.displayRecord = false;
        this.resetForm = true;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}

