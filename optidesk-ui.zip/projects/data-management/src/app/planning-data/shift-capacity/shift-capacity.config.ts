import { Validators } from '@angular/forms';
import {
    compareStartTime,
    compareFinishTime,
    checkBreakTime,
    noTimeOvelap,
    greaterThanOrEqualValidation,
    lessThanOrEqualValidation,
    noDuplicateShift,
    shiftnoNotGreaterThanNoShift,
    noDuplicateDayForShift
} from 'src/app/components/form-validator/form.validator';

export const SHIFT_CAPACITY_CONFIG = {
    moduleName: 'SHIFT_CAPACITY',
    moduleLabel: 'SHIFT_CAPACITY.TITLE',
    moduleDescription: 'SHIFT_CAPACITY.DESCRIPTION',
    masterData: [],
    search: {
        tblName: 'resource',
        editExternal: true,
        fields: [],
        editFields: [
            [
                {
                    label: 'SHIFT_CAPACITY.FIELDS.RESID',
                    name: 'resNo',
                    value: '',
                    valueKey: 'resNo',
                    childKey: 'validfr',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    isChangeMainTableName: true,
                    mainTableName: 'capVal',
                    searchTableName: 'capVal',
                    notExistsLabel: 'RESOURCE_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(30), message: 'MAX_LENGTH', messageParam: { max_char: 30 } }
                    ]
                },
                {
                    label: 'SHIFT_CAPACITY.FIELDS.VALIDFR',
                    name: 'validfr',
                    value: '',
                    valueKey: 'validfr',
                    childKey: 'validTo',
                    parentKeys: ['resNo'],
                    parentColumn: ['resid'],
                    childTableKey: ['resource'],
                    isChangeMainTableName: true,
                    mainTableName: 'capVal',
                    searchTableName: 'capVal',
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'RESOURCE_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                    ]
                },
                {
                    label: 'SHIFT_CAPACITY.FIELDS.VALIDTO',
                    name: 'validTo',
                    value: '',
                    valueKey: 'validTo',
                    childKey: '',
                    parentKeys: ['resNo', 'validfr'],
                    parentColumn: ['resid'],
                    childTableKey: ['resource'],
                    isChangeMainTableName: true,
                    mainTableName: 'capVal',
                    searchTableName: 'capVal',
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'RESOURCE_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                    ]
                }
            ]
        ],
        createFields: [
            [
                {
                    label: 'SHIFT_CAPACITY.FIELDS.RESID',
                    name: 'resNo',
                    value: '',
                    valueKey: 'resNo',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'RESOURCE_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(30), message: 'MAX_LENGTH', messageParam: { max_char: 30 } }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'SHIFT_CAPACITY.CAPACITY_VALIDITY_TAB.TITLE',
            tabDescription: 'SHIFT_CAPACITY.CAPACITY_VALIDITY_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'capacityValidates',
            sections: [
                {
                    sectionTitle: 'SHIFT_CAPACITY.CAPACITY_VALIDITY_TAB.SECTIONS.CAPACITY_VALIDITY',
                    fields: [
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.RESNO',
                                name: 'resNo',
                                value: '',
                                valueKey: 'resNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.VALIDFR',
                                name: 'validFr',
                                value: '',
                                valueKey: 'validFr',
                                type: 'datepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                editableFieldType: 2,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'lessThanOrEqualValidation',
                                        validator: lessThanOrEqualValidation('capacityValidates.validTo', 'isDate'),
                                        message: 'INVALID_VALID_FROM'
                                    }
                                ]
                            },
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.VALIDTO',
                                name: 'validTo',
                                value: '',
                                valueKey: 'validTo',
                                type: 'datepicker',
                                inputType: 'text',
                                editableFieldType: 2,
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'greaterThanOrEqualValidation',
                                        validator: greaterThanOrEqualValidation('capacityValidates.validFr', 'isDate'),
                                        message: 'INVALID_VALID_TO'
                                    },
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.NOSHIFT',
                                name: 'noShift',
                                value: '',
                                valueKey: 'noShift',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                inputMaskType: 'numbersOnly',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                ]
                            },
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.CALOVRD',
                                name: 'calOvrd',
                                value: '',
                                valueKey: 'calOvrd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                recordExists: 'INVALID_VALUE',
                                validations: [
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(1), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 1 }
                                    }
                                ]
                            }
                        ]
                    ]
                }
            ]
        },
        {
            tabTitle: 'SHIFT_CAPACITY.SHIFT_DETAILS_TAB.TITLE',
            tabDescription: 'SHIFT_CAPACITY.SHIFT_DETAILS_TAB.DESCRIPTION',
            tabView: 'TABLE',
            tblName: 'capacityShifts',
            validations: [
                { name: 'required', validator: Validators.required, message: 'REQUIRED' }
            ],
            sections: [
                {
                    sectionTitle: 'SHIFT_CAPACITY.SHIFT_DETAILS_TAB.SECTIONS.SHIFT_DETAILS',
                    fields: [
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.RESNO',
                                name: 'resNo',
                                value: '',
                                valueKey: 'resNo',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: 'primary',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.DAYNO',
                                name: 'dayNo',
                                value: '',
                                valueKey: 'dayNo',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'numbersOnly',
                                fieldType: '',
                                option: 'dayNos',
                                isEditable: true,
                                isEditableInTable: false,
                                isRemoveField: true,
                                childKey: 'shiftNo',
                                childKeyOption: 'shiftNos',
                                parentKeys: [],
                                searchValidations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ],
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'pattern', validator: Validators.pattern('^[1-7]{1}$'), message: 'INVALID_DAY_NO' },
                                    {
                                        name: 'noDuplicateDayForShift',
                                        validator: noDuplicateDayForShift('shiftNo'),
                                        message: 'DUPLICATE_SHIFT_NO'
                                    }
                                ]
                            },
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.SHIFTNO',
                                name: 'shiftNo',
                                value: '',
                                valueKey: 'shiftNo',
                                type: 'input',
                                inputType: 'text',
                                option: 'shiftNos',
                                fieldType: '',
                                inputMaskType: 'numbersOnly',
                                isRemoveField: true,
                                isEditable: true,
                                isEditableInTable: false,
                                childKey: '',
                                parentKeys: ['dayNo'],
                                searchValidations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ],
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'noDuplicateShift',
                                        validator: noDuplicateShift('dayNo'),
                                        message: 'DUPLICATE_SHIFT_NO'
                                    },
                                    {
                                        name: 'shiftnoNotGreaterThanNoShift',
                                        validator: shiftnoNotGreaterThanNoShift('noShift', 'capacityValidates'),
                                        message: 'SHIFT_NO_IS_NOIT_GREATER'
                                    }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.NOCAP',
                                name: 'noCap',
                                value: '',
                                valueKey: 'noCap',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                inputMaskType: 'numbersOnly',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.STRTIME',
                                name: 'strTime',
                                value: '',
                                valueKey: 'strTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'compareStartTime', validator: compareStartTime('finTime'), message: 'ENTER_VALID_START_TIME' },
                                    {
                                        name: 'noTimeOvelap',
                                        validator: noTimeOvelap('dayNo', 'shiftNo', 'strTime', 'finTime'),
                                        message: 'INVALID_SHIFT_TIME_RANGE'
                                    }
                                ]
                            },
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.FINTIME',
                                name: 'finTime',
                                value: '',
                                valueKey: 'finTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'compareFinishTime', validator: compareFinishTime('strTime'),
                                        message: 'ENTER_VALID_FINISH_TIME'
                                    },
                                    {
                                        name: 'noTimeOvelap',
                                        validator: noTimeOvelap('dayNo', 'shiftNo', 'strTime', 'finTime'),
                                        message: 'INVALID_SHIFT_TIME_RANGE'
                                    }
                                ]
                            },
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.BRKTIME',
                                name: 'brkTime',
                                value: '',
                                valueKey: 'brkTime',
                                type: 'timepicker',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'checkBreakTime', validator: checkBreakTime('strTime', 'finTime'),
                                        message: 'ENTER_VALID_BREAK_TIME'
                                    }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.CAPUTIL',
                                name: 'capUtil',
                                value: '',
                                valueKey: 'capUtil',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'twoDecimalOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'max', validator: Validators.max(100),
                                        message: 'ENTER_VALID_CAPACITY_UTILIZATION'
                                    }
                                ],
                            },
                            {
                                label: 'SHIFT_CAPACITY.FIELDS.OVERLOAD',
                                name: 'overload',
                                value: '',
                                valueKey: 'overload',
                                type: 'input',
                                inputType: 'text',
                                inputMaskType: 'twoDecimalOnly',
                                option: '',
                                fieldType: '',
                                isEditable: true,
                                isEditableInTable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'min', validator: Validators.min(100), message: 'ENTER_VALID_CAPACITY_OVERLOAD',
                                    },
                                    {
                                        name: 'max', validator: Validators.max(120), message: 'ENTER_VALID_CAPACITY_OVERLOAD',
                                    }
                                ]
                            },
                        ],
                    ]
                }
            ]
        }
    ]
};
