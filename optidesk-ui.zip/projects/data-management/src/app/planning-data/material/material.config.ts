import { Validators } from '@angular/forms';

export const MATERIAL_CONFIG = {
    moduleName: 'MATERIAL',
    moduleLabel: 'MATERIAL.TITLE',
    moduleDescription: 'MATERIAL.DESCRIPTION',
    masterData: [
        {
            masterDataKey: 'matTypes',
            reqObj: {
                columnName: 'mattyp',
                tableName: 'mattype'
            }
        },
        {
            masterDataKey: 'units',
            reqObj: {
                columnName: 'uom',
                tableName: 'unit'
            }
        }
    ],
    search: {
        tblName: 'material',
        editExternal: false,
        recordExists: 'MATERIAL_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'MATERIAL.FIELDS.MATNO',
                    name: 'matNo',
                    value: '',
                    valueKey: 'matNo',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'MATERIAL_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(20), message: 'ENTER_VALID_MATERIAL' }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'MATERIAL.DETAIL_TAB.TITLE',
            tabDescription: 'MATERIAL.DETAIL_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'materials',
            validations: [],
            sections: [
                {
                    sectionTitle: 'MATERIAL.DETAIL_TAB.SECTIONS.MATERIAL_DETAILS',
                    fields: [
                        [
                            {
                                label: 'MATERIAL.FIELDS.MATID',
                                name: 'matId',
                                value: '',
                                valueKey: 'matId',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'MATERIAL.FIELDS.MATNO',
                                name: 'matNo',
                                value: '',
                                valueKey: 'matNo',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'MATERIAL.FIELDS.MATTYP',
                                name: 'matTyp',
                                value: '',
                                valueKey: 'matTyp',
                                type: 'select',
                                inputType: 'select',
                                option: 'matTypes',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.BASEUOM',
                                name: 'baseUom',
                                value: '',
                                valueKey: 'baseUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'MATERIAL.FIELDS.ORDERUOM',
                                name: 'OrderUom',
                                value: '',
                                valueKey: 'OrderUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.GROSSWT',
                                name: 'grossWt',
                                value: '',
                                valueKey: 'grossWt',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.NETWT',
                                name: 'netWt',
                                value: '',
                                valueKey: 'netWt',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.WTUOM',
                                name: 'wtUom',
                                value: '',
                                valueKey: 'wtUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: '',
                                name: '',
                                value: '',
                                valueKey: '',
                                type: 'blank',
                                inputType: '',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.VOLUME',
                                name: 'volume',
                                value: '',
                                valueKey: 'volume',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.VOLUOM',
                                name: 'volUom',
                                value: '',
                                valueKey: 'volUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.DIVISION',
                                name: 'division',
                                value: '',
                                valueKey: 'division',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(5), message: 'MAXIMUM_4_DIGITS' },
                                ]
                            },
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.LENGTH',
                                name: 'length',
                                value: '',
                                valueKey: 'length',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.WIDTH',
                                name: 'width',
                                value: '',
                                valueKey: 'width',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.HEIGH',
                                name: 'heigh',
                                value: '',
                                valueKey: 'heigh',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                width: 'full',
                                isEditable: false,
                                validations: []
                            }
                        ],
                        [
                            {
                                label: '',
                                name: '',
                                value: '',
                                valueKey: '',
                                type: 'blank',
                                inputType: '',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: '',
                                name: '',
                                value: '',
                                valueKey: '',
                                type: 'blank',
                                inputType: '',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.DIMUOM',
                                name: 'dimUom',
                                value: '',
                                valueKey: 'dimUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'createdOn',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'MATERIAL.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'MATERIAL.FIELDS.VALIDFROM',
                                name: 'validFrom',
                                value: '',
                                valueKey: 'validFrom',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: '',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.VALIDTILL',
                                name: 'validTill',
                                value: '',
                                valueKey: 'validTill',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: '',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ]
                    ]
                }
            ]
        },
        {
            tabTitle: 'MATERIAL.UNIT_TAB.TITLE',
            tabDescription: 'MATERIAL.UNIT_TAB.DESCRIPTION',
            tabView: 'TABLE',
            tblName: 'matUoms',
            validations: [],
            sections: [
                {
                    sectionTitle: 'MATERIAL.UNIT_TAB.TITLE',
                    fields: [
                        [
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.MATID',
                                name: 'matId',
                                value: '',
                                valueKey: 'matId',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'MATERIAL.FIELDS.ALTUOM',
                                name: 'altUom',
                                value: '',
                                valueKey: 'altUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'MATERIAL.FIELDS.NUMCONV',
                                name: 'numConv',
                                value: '',
                                valueKey: 'numConv',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.DENCONV',
                                name: 'denConv',
                                value: '',
                                valueKey: 'denConv',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.LENGTH',
                                name: 'length',
                                value: '',
                                valueKey: 'length',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.WIDTH',
                                name: 'width',
                                value: '',
                                valueKey: 'width',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.HEIGH',
                                name: 'heigh',
                                value: '',
                                valueKey: 'heigh',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.DIMUOM',
                                name: 'dimUom',
                                value: '',
                                valueKey: 'dimUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'MATERIAL.FIELDS.VOLUME',
                                name: 'volume',
                                value: '',
                                valueKey: 'volume',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.VOLUOM',
                                name: 'volUom',
                                value: '',
                                valueKey: 'volUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            },
                            {
                                label: 'MATERIAL.FIELDS.GROSSWT',
                                name: 'grossWt',
                                value: '',
                                valueKey: 'grossWt',
                                type: 'input',
                                inputType: 'text',
                                option: '',
                                fieldType: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'MATERIAL.FIELDS.WTUOM',
                                name: 'wtUom',
                                value: '',
                                valueKey: 'wtUom',
                                type: 'select',
                                inputType: 'select',
                                option: 'units',
                                fieldType: '',
                                isEditable: false,
                                validations: [],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
