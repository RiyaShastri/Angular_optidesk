import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialRoutingModule } from './material-routing.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { MaterialComponent } from './material.component';


@NgModule({
    declarations: [MaterialComponent],
    imports: [
        CommonModule,
        MaterialRoutingModule,
        ComponentsModule
    ]
})
export class MaterialModule { }
