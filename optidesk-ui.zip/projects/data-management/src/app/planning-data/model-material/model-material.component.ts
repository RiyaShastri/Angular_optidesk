import { Component, OnInit, ViewChild } from '@angular/core';
import { MODEL_MATERIAL_CONFIG } from './model-material.config';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';

@Component({
    selector: 'app-model-material',
    templateUrl: './model-material.component.html',
    styleUrls: ['./model-material.component.css']
})
export class ModelMaterialComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = MODEL_MATERIAL_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    pageType = CONSTANTS.VIEW;
    resetForm = false;
    isTableEditable = true;
    baseUrl = '/planning-data/model-material';
    breadCrumb = {
        label: 'MODEL_MATERIAL.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'MODEL_MATERIAL.SIDE_BAR_MANUES.VIEW_MENU',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'MODEL_MATERIAL.SIDE_BAR_MANUES.MANAGE_MENU',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        }
    ];

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void { }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displayPageContent(searchedCriteria);
            });
        } else {
            this.displayPageContent(searchedCriteria);
        }
    }

    displayPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
