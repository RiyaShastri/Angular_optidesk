import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModelMaterialRoutingModule } from './model-material-routing.module';
import { ModelMaterialComponent } from './model-material.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
    declarations: [ModelMaterialComponent],
    imports: [
        CommonModule,
        ModelMaterialRoutingModule,
        ComponentsModule
    ]
})
export class ModelMaterialModule { }
