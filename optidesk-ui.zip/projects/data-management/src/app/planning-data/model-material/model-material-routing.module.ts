import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModelMaterialComponent } from './model-material.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: ModelMaterialComponent
            },
            {
                path: 'edit',
                component: ModelMaterialComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ModelMaterialRoutingModule { }
