import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModelRoutingModule } from './model-routing.module';
import { ModelComponent } from './model.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
    declarations: [ModelComponent],
    imports: [
        CommonModule,
        ModelRoutingModule,
        ComponentsModule
    ]
})
export class ModelModule { }
