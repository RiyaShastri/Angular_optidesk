import { Component, OnInit, ViewChild } from '@angular/core';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';
import { MODEL_CONFIG } from './model.config';

@Component({
    selector: 'app-model',
    templateUrl: './model.component.html',
    styleUrls: ['./model.component.css']
})
export class ModelComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = MODEL_CONFIG;
    masterData = {};
    moduleData = {};
    displayRecord = false;
    pageType = CONSTANTS.VIEW;
    resetForm = false;
    CONSTANTS = CONSTANTS;
    baseUrl = '/planning-data/model';
    breadCrumb = {
        label: 'MODEL.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'MODEL.SIDE_BAR_MANUES.VIEW_MENU',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'MODEL.SIDE_BAR_MANUES.MANAGE_MENU',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'MODEL.SIDE_BAR_MANUES.CREATE_MENU',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
        if (this.pageType === CONSTANTS.CREATE) {
            this.planningDataService.getNewModelNumber(this.moduleConfig.moduleName).toPromise().then(modelId => {
                const newModelId = modelId['message'];
                this.moduleConfig.search.editExternal = true;
                this.moduleData = this.planningDataService.createFreshModuleData(this.moduleConfig);
                this.moduleData['primaryData'] = { modelId: newModelId };
                this.setPrimaryField();
                this.displayRecord = true;
                this.resetForm = false;
            }).catch(err => {
                this.resetForm = true;
                this.displayRecord = false;
            });
        } else {
            this.setPrimaryField();
            this.moduleConfig.search.editExternal = false;
        }
    }

    setPrimaryField() {
        this.moduleConfig.tabs.forEach(tab => {
            tab.sections.forEach(section => {
                section.fields.forEach(field => {
                    field.forEach(data => {
                        if (data.name === 'modelId') {
                            data.fieldType = this.pageType !== CONSTANTS.CREATE ? 'primary' : '';
                        }
                    });
                });
            });
        });
    }

    searchCriteria(searchedCriteria) {
        if (this.pageType !== CONSTANTS.VIEW) {
            this.planningDataService.populateMasterData(this.moduleConfig.masterData).then(masterData => {
                this.masterData = masterData;
                this.displatPageContent(searchedCriteria);
            });
        } else {
            this.displatPageContent(searchedCriteria);
        }
    }

    displatPageContent(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
