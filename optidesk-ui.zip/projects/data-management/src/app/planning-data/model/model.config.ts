import { Validators } from '@angular/forms';

export const MODEL_CONFIG = {
    moduleName: 'MODEL',
    moduleLabel: 'MODEL.TITLE',
    moduleDescription: 'MODEL.DESCRIPTION',
    masterData: [],
    search: {
        tblName: 'model',
        editExternal: false,
        fields: [
            [
                {
                    label: 'MODEL.FIELDS.MODELID',
                    name: 'modelId',
                    value: '',
                    valueKey: 'modelId',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'MODEL_NOT_FOUND',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        {
                            name: 'maxlength', validator: Validators.maxLength(3), message: 'MAX_LENGTH',
                            messageParam: { max_char: 3 }
                        }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'MODEL.DETAIL_TAB.TITLE',
            tabDescription: 'MODEL.DETAIL_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'models',
            validations: [],
            sections: [
                {
                    sectionTitle: 'MODEL.DETAIL_TAB.SECTIONS.MODEL_DETAIL',
                    fields: [
                        [
                            {
                                label: 'MODEL.FIELDS.MODELID',
                                name: 'modelId',
                                value: '',
                                valueKey: 'modelId',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    {
                                        name: 'maxlength', validator: Validators.maxLength(3), message: 'MAX_LENGTH',
                                        messageParam: { max_char: 3 }
                                    }
                                ]
                            },
                            {
                                label: 'MODEL.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'createdOn',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'MODEL.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }
                        ],
                        [
                            {
                                label: 'MODEL.FIELDS.ACTIND',
                                name: 'actInd',
                                value: '',
                                valueKey: 'actInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
