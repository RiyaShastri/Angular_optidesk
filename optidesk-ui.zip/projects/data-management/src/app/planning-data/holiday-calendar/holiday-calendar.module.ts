import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HolidayCalendarRoutingModule } from './holiday-calendar-routing.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { HolidayCalendarComponent } from './holiday-calendar.component';


@NgModule({
    declarations: [HolidayCalendarComponent],
    imports: [
        CommonModule,
        HolidayCalendarRoutingModule,
        ComponentsModule
    ]
})
export class HolidayCalendarModule { }
