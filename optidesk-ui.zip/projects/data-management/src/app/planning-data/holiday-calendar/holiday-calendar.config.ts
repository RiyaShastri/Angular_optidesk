import { Validators } from '@angular/forms';
import {
    lessThanOrEqualValidation,
    greaterThanOrEqualValidation,
    noDuplicateRecord,
    invalidYearValidation
} from 'src/app/components/form-validator/form.validator';

export const HOLIDAY_CALENDAR_CONFIG = {
    moduleName: 'HOLIDAY_CALENDAR',
    moduleLabel: 'HOLIDAY_CALENDAR.TITLE',
    moduleDescription: 'HOLIDAY_CALENDAR.DESCRIPTION',
    search: {
        tblName: 'holcal',
        editExternal: false,
        recordExists: 'HOLIDAY_CALENDAR_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'HOLIDAY_CALENDAR.FIELDS.HOLCALKEY',
                    name: 'holCalKey',
                    value: '',
                    valueKey: 'holCalKey',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'HOLIDAY_CALENDAR_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'maxlength', validator: Validators.maxLength(5), message: 'ENTER_VALID_HOLCALKEY' }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'HOLIDAY_CALENDAR.HOLCAL_TAB.TITLE',
            tabDescription: 'HOLIDAY_CALENDAR.HOLCAL_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'holcal',
            validations: [],
            sections: [
                {
                    sectionTitle: 'HOLIDAY_CALENDAR.HOLCAL_TAB.SECTIONS.CALENDAR',
                    fields: [
                        [
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.HOLCALKEY',
                                name: 'holCalKey',
                                value: '',
                                valueKey: 'holCalKey',
                                type: '',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.YEARFROM',
                                name: 'yearFrom',
                                value: '',
                                valueKey: 'yearFrom',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                option: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'pattern', validator: Validators.pattern('^[0-9]*$'), message: 'INVALID_YEAR_FROM' },
                                    { name: 'minlength', validator: Validators.minLength(4), message: 'MINIMUM_4_DIGITS' },
                                    { name: 'maxlength', validator: Validators.maxLength(4), message: 'MAXIMUM_4_DIGITS' },
                                    {
                                        name: 'lessThanOrEqualValidation', validator: lessThanOrEqualValidation('holcal.yearTill'),
                                        message: 'INVALID_YEAR_RANGE'
                                    },
                                    {
                                        name: 'invalidYearValidation',
                                        validator: invalidYearValidation('lessOrEqual', 'hollist', 'holDate'),
                                        message: 'INVALID_YEAR_FROM'
                                    }
                                ]
                            },
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.YEARTILL',
                                name: 'yearTill',
                                value: '',
                                valueKey: 'yearTill',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                option: '',
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'pattern', validator: Validators.pattern('^[0-9]*$'), message: 'INVALID_YEAR_TILL' },
                                    { name: 'minlength', validator: Validators.minLength(4), message: 'MINIMUM_4_DIGITS' },
                                    { name: 'maxlength', validator: Validators.maxLength(4), message: 'MAXIMUM_4_DIGITS' },
                                    {
                                        name: 'greaterThanOrEqualValidation', validator: greaterThanOrEqualValidation('holcal.yearFrom'),
                                        message: 'INVALID_YEAR_RANGE'
                                    },
                                    {
                                        name: 'invalidYearValidation',
                                        validator: invalidYearValidation('greaterOrEqual', 'hollist', 'holDate'),
                                        message: 'INVALID_YEAR_TILL'
                                    },
                                ]
                            }
                        ],
                        [
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.DELIND',
                                name: 'delInd',
                                value: '',
                                valueKey: 'delInd',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.SRCFLG',
                                name: 'srcFlg',
                                value: '',
                                valueKey: 'srcFlg',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'secondary',
                                option: '',
                                isEditable: false,
                                validations: []
                            },
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.CRTDON',
                                name: 'crtDon',
                                value: '',
                                valueKey: 'crtDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'createdOn',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.CHGDON',
                                name: 'chgDon',
                                value: '',
                                valueKey: 'chgDon',
                                type: 'datepicker',
                                inputType: '',
                                fieldType: 'changedOn',
                                option: '',
                                isEditable: false,
                                validations: []
                            }

                        ]
                    ]
                }
            ]
        },
        {
            tabTitle: 'HOLIDAY_CALENDAR.HOLLIST_TAB.TITLE',
            tabDescription: 'HOLIDAY_CALENDAR.HOLLIST_TAB.DESCRIPTION',
            tabView: 'TABLE',
            tblName: 'hollist',
            validations: [
                { name: 'required', validator: Validators.required, message: 'REQUIRED' }
            ],
            sections: [
                {
                    sectionTitle: 'HOLIDAY_CALENDAR.HOLLIST_TAB.SECTIONS.GENERAL_DATA',
                    tblName: 'hollist',
                    sortBy: {
                        name: 'holDate',
                        type: 'date'
                    },
                    fields: [
                        [
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.HOLCALKEY',
                                name: 'holCalKey',
                                value: '',
                                valueKey: 'holCalKey',
                                childKey: 'holDate',
                                parentKeys: [],
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'HOLIDAY_CALENDAR.FIELDS.HOLDATE',
                                name: 'holDate',
                                value: '',
                                valueKey: 'holDate',
                                childKey: '',
                                parentKeys: [],
                                type: 'datepicker',
                                inputType: '',
                                fieldType: '',
                                option: 'holDates',
                                isRemoveField: true,
                                isEditable: true,
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'noDuplicateRecord', validator: noDuplicateRecord(), message: 'DUPLICATE_HOLIDAYS_NOT_ALLOWED' }
                                ],
                                searchValidations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ],
                                datePickerConfig: {
                                    yearFrom: 'holcal.yearFrom',
                                    yearTill: 'holcal.yearTill'
                                }
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
