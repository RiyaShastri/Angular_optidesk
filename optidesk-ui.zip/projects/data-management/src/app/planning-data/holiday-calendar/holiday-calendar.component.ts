import { Component, OnInit, ViewChild } from '@angular/core';
import { HOLIDAY_CALENDAR_CONFIG } from './holiday-calendar.config';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';

@Component({
    selector: 'app-holiday-calendar',
    templateUrl: './holiday-calendar.component.html',
    styleUrls: ['./holiday-calendar.component.css']
})
export class HolidayCalendarComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = HOLIDAY_CALENDAR_CONFIG;
    moduleData: any = {};
    displayRecord = false;
    pageType = CONSTANTS.VIEW;
    resetForm = false;
    baseUrl = '/planning-data/holiday-calendar';
    breadCrumb = {
        label: 'HOLIDAY_CALENDAR.TITLE',
        routerLink: this.baseUrl
    };
    sideBarMenus = [
        {
            label: 'HOLIDAY_CALENDAR.SIDE_BAR_MANUES.VIEW_HOLIDAY_CALENDAR',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'HOLIDAY_CALENDAR.SIDE_BAR_MANUES.EDIT_HOLIDAY_CALENDAR',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'HOLIDAY_CALENDAR.SIDE_BAR_MANUES.CREATE_HOLIDAY_CALENDAR',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void { }

    searchCriteria(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }
}
