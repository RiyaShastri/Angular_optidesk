import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HolidayCalendarComponent } from './holiday-calendar.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: HolidayCalendarComponent
            },
            {
                path: 'edit',
                component: HolidayCalendarComponent,
                canDeactivate: [CanDeactivatGuard]
            },
            {
                path: 'create',
                component: HolidayCalendarComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class HolidayCalendarRoutingModule { }
