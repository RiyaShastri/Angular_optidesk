import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard } from 'src/app/shared/services/auth-guard.service';
import { ContentComponent } from './content.component';
import { DashbaordMenuComponent } from './dashbaord-menu/dashbaord-menu.component';

const routes: Routes = [
    {
        path: '',
        component: ContentComponent,
        children: [
            {
                path: '',
                component: DashbaordMenuComponent,
                canActivate: [AuthGuard]
            },
            {
                path: 'planning-data',
                loadChildren: () => import('../planning-data/planning-data.module').then(m => m.PlanningDataModule),
                canActivate: [AuthGuard]
            },
            {
                path: 'authenticate-user',
                loadChildren: () => import('../authenticate-user/authenticate-user.module').then(m => m.AuthenticateUserModule)
            },
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ContentRoutingModule { }
