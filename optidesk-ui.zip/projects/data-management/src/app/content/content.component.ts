import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotifyService } from 'src/app/shared/services/notify.service';

@Component({
    selector: 'app-content',
    templateUrl: './content.component.html',
    styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
    homeBreadcrumb = {
        label: 'Home',
        routerLink: ['']
    };
    breadcrumbs = [];
    userInfo = [];
    hideBreadCrumb = false;
    constructor(
        public router: Router,
        private notifyService: NotifyService
    ) { 
        this.hideBreadCrumb = this.router.url.includes('authenticate-user');
    }

    ngOnInit(): void {
        if (this.breadcrumbs.length === 0) {
            this.breadcrumbs = [this.homeBreadcrumb];
        }

        this.notifyService.userDetailsObservable.subscribe(value => {
            if (value.hasOwnProperty('type') && value.type === 'user-details') {
                this.userInfo.push(value.data);
            }
        });
    }

    onActivate(componentReference) {
        this.hideBreadCrumb = this.router.url.includes('authenticate-user');
        this.breadcrumbs = componentReference.breadcrumbs || [];
        this.breadcrumbs.unshift(this.homeBreadcrumb);
    }
}
