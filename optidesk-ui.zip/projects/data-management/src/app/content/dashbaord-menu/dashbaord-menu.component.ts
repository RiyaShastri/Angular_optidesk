import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashbaord-menu',
    templateUrl: './dashbaord-menu.component.html',
    styleUrls: ['./dashbaord-menu.component.css']
})
export class DashbaordMenuComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {
    }

}
