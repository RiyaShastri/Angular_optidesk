import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashbaordMenuComponent } from './dashbaord-menu.component';

describe('DashbaordMenuComponent', () => {
  let component: DashbaordMenuComponent;
  let fixture: ComponentFixture<DashbaordMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashbaordMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashbaordMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
