import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentRoutingModule } from './content-routing.module';
import { ContentComponent } from './content.component';
import { LayoutModule } from 'src/app/shared/layout/layout.module';
import { DashbaordMenuComponent } from './dashbaord-menu/dashbaord-menu.component';

@NgModule({
    declarations: [
        ContentComponent,
        DashbaordMenuComponent
    ],
    imports: [
        CommonModule,
        LayoutModule,
        ContentRoutingModule
    ]
})
export class ContentModule { }
