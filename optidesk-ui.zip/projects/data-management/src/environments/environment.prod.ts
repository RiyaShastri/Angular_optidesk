// export const environment = {
//     production: true,
//     apiURL: 'http://oddev.westus.cloudapp.azure.com:8081',
//     AES_initVectorStr: 'FLvEHyF7qY6meHAU',
//     AES_key: '7Zk9ImH5C4W8A1MP'
// };
