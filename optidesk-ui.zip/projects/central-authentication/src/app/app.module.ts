import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from 'src/app/shared/layout/layout.module';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { UtilityModule } from 'src/app/core/utility/utility.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ComponentsModule } from 'src/app/components/components.module';
import { TokenInterceptor } from 'src/app/shared/services/token.interceptor';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { faBan, faCheck, faTimes, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { faClone, faCheckCircle } from '@fortawesome/free-regular-svg-icons';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';

export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
    declarations: [
        AppComponent,
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        LayoutModule,
        HttpClientModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        UtilityModule,
        ComponentsModule,
        NgxPermissionsModule.forRoot(),
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        })
    ],
    providers: [
        CanDeactivatGuard,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TokenInterceptor,
            multi: true
        }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
    constructor(library: FaIconLibrary) {
        library.addIcons(faBan);
        library.addIcons(faCheck);
        library.addIcons(faTimes);
        library.addIcons(faClone);
        library.addIcons(faInfoCircle);
        library.addIcons(faCheckCircle);
    }
}
