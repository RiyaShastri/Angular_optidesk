import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-onboard',
    templateUrl: './onboard.component.html',
    styleUrls: ['./onboard.component.css']
})
export class OnboardComponent implements OnInit {
    sideBarMenus = [];
    breadcrumbs = [
        {
            label: 'Onboard',
            routerLink: ['/onboard']
        }
    ];
    hideSideBar = false;
    constructor(
        private router: Router
    ) {
        this.hideSideBar = this.router.url === '/onboard';
    }

    ngOnInit(): void { }

    onActivate(componentReference) {
        this.hideSideBar = this.router.url === '/onboard';
        this.breadcrumbs.push(componentReference.breadCrumb);
        this.sideBarMenus = componentReference.sideBarMenus;
    }

    onDeactivate(componentReference) {
        this.breadcrumbs.pop();
    }

}
