import { Validators } from '@angular/forms';

export const CAAP_CUSTOMER_CONFIG = {
    moduleName: 'CAAP_CUSTOMER',
    moduleLabel: 'CAAP_CUSTOMER.TITLE',
    moduleDescription: 'CAAP_CUSTOMER.DESCRIPTION',
    search: {
        tblName: 'customers',
        editExternal: false,
        recordExists: 'CUSTOMER_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'CAAP_CUSTOMER.FIELDS.CLIENTCODE',
                    name: 'clntCode',
                    value: '',
                    valueKey: 'clntCode',
                    childKey: '',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    option: '',
                    notExistsLabel: 'CAAP_CUSTOMER_DOES_NOT_EXISTS',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'minlength', validator: Validators.minLength(8), message: 'ENTER_VALID_CLIENT_CODE' }
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'CAAP_CUSTOMER.CAAP_CUSTOMER_TAB.TITLE',
            tabDescription: 'CAAP_CUSTOMER.CAAP_CUSTOMER_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'customer',
            sections: [
                {
                    sectionTitle: 'CAAP_CUSTOMER.CAAP_CUSTOMER_TAB.SECTIONS.GENERAL_DATA',
                    tblName: 'customer',
                    fields: [
                        [
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.CLIENTCODE',
                                name: 'clntCode',
                                value: '',
                                valueKey: 'clntCode',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                option: '',
                                isEditable: false,
                            }
                        ],
                        [
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.COMPANYNAME',
                                name: 'companyName',
                                value: '',
                                valueKey: 'companyName',
                                type: 'input',
                                inputType: 'text',
                                isEditable: true,
                                editableFieldType: 2,
                                width: 'full',
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                        ],
                        [
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.CLIENTSTATUS',
                                name: 'clientStatus',
                                value: '',
                                valueKey: 'clientStatus',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_CLIENTSTATUS' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.TENANTID',
                                name: 'tenantId',
                                value: '',
                                valueKey: 'tenantId',
                                type: 'input',
                                inputType: 'text',
                                isEditable: true,
                                width: 'full',
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.CLIENTSECRET',
                                name: 'clientSecret',
                                value: '',
                                valueKey: 'clientSecret',
                                type: 'input',
                                inputType: 'text',
                                isEditable: true,
                                width: 'full',
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            },
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.CLIENTID',
                                name: 'clientId',
                                value: '',
                                valueKey: 'clientId',
                                type: 'input',
                                inputType: 'text',
                                isEditable: true,
                                width: 'full',
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'CAAP_CUSTOMER.FIELDS.HOSTURL',
                                name: 'hostUrl',
                                value: '',
                                valueKey: 'hostUrl',
                                type: 'input',
                                inputType: 'text',
                                isEditable: true,
                                width: 'full',
                                validations: [
                                    { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                                    { name: 'pattern', validator: Validators.pattern('(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?'), message: 'ENTER_VALID_HOST_URL' },
                                ]
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
