import { Component, OnInit, ViewChild } from '@angular/core';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { CAAP_CUSTOMER_CONFIG } from './customer.config';

@Component({
    selector: 'app-customer',
    templateUrl: './customer.component.html',
    styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = CAAP_CUSTOMER_CONFIG;
    masterData = {
        clientCodes: ['UNILEVER', 'PNG'],
        identityProviders: ['Google', 'Microsoft']
    };
    moduleData: any = {};
    pageType = CONSTANTS.VIEW;
    baseUrl = '/onboard/customer';
    breadCrumb = {
        label: 'CAAP_CUSTOMER.TITLE',
        routerLink: this.baseUrl
    };
    displayRecord = false;
    sideBarMenus = [
        {
            label: 'CAAP_CUSTOMER.SIDE_BAR_MANUES.VIEW_CAAP_CUSTOMER',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'CAAP_CUSTOMER.SIDE_BAR_MANUES.EDIT_CAAP_CUSTOMER',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'CAAP_CUSTOMER.SIDE_BAR_MANUES.CREATE_CAAP_CUSTOMER',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];
    resetForm = false;

    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
    }

    searchCriteria(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
