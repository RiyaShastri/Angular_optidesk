import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OnboardRoutingModule } from './onboard-routing.module';
import { MenusComponent } from './menus/menus.component';
import { LayoutModule } from 'src/app/shared/layout/layout.module';
import { TranslateModule } from '@ngx-translate/core';
import { NgbNavModule, NgbAlertModule, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { FaIconLibrary, FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faBan, faCheck, faTimes, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { faClone, faCheckCircle } from '@fortawesome/free-regular-svg-icons';
import { ModalService } from 'src/app/core/utility/modal/modal.service';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { ReactiveFormsModule } from '@angular/forms';
import { ComponentsModule } from 'src/app/components/components.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { OnboardComponent } from './onboard.component';

@NgModule({
    declarations: [OnboardComponent, MenusComponent],
    imports: [
        CommonModule,
        OnboardRoutingModule,
        CommonModule,
        LayoutModule,
        TranslateModule,
        FontAwesomeModule,
        NgbNavModule,
        NgbAlertModule,
        NgbModalModule,
        ReactiveFormsModule,
        ComponentsModule,
        NgxPermissionsModule.forChild()
    ],
    providers: [
        PlanningDataService,
        ModalService
    ]
})
export class OnboardModule {
    constructor(library: FaIconLibrary) {
        library.addIcons(faBan);
        library.addIcons(faCheck);
        library.addIcons(faTimes);
        library.addIcons(faClone);
        library.addIcons(faInfoCircle);
        library.addIcons(faCheckCircle);
    }
}
