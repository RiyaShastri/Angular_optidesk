import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-menus',
    templateUrl: './menus.component.html',
    styleUrls: ['./menus.component.css']
})
export class MenusComponent implements OnInit {
    breadCrumb = {};
    baseUrl = '/onboard';
    menus = [
        [
            {
                label: 'CAAP_CUSTOMER.TITLE',
                routerLink: this.baseUrl + '/customer',
                accessibleTo: ['SUPERADMIN']
            },
            {
                label: 'CAAP_USER.TITLE',
                routerLink: this.baseUrl + '/user',
                accessibleTo: ['SUPERADMIN', 'USERADMIN']
            }
        ]
    ];
    constructor() { }

    ngOnInit(): void {
    }

}
