import { Component, OnInit, ViewChild } from '@angular/core';
import { TabComponent } from 'src/app/components';
import { CONSTANTS } from 'src/app/shared/constants';
import { PlanningDataService } from 'src/app/shared/services/planning-data.service';
import { CAAP_USER_CONFIG } from './user.config';

@Component({
    selector: 'app-user',
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
    @ViewChild(TabComponent, { static: false }) childRef: TabComponent;
    moduleConfig = CAAP_USER_CONFIG;
    moduleData: any = {};
    pageType = CONSTANTS.VIEW;
    baseUrl = '/onboard/user';
    displayRecord = false;
    breadCrumb = {
        label: 'CAAP_USER.TITLE',
        routerLink: this.baseUrl
    };
    resetForm = false;
    sideBarMenus = [
        {
            label: 'CAAP_USER.SIDE_BAR_MANUES.VIEW_CAAP_USER',
            icon: 'eye',
            routerLink: this.baseUrl + '/view'
        },
        {
            label: 'CAAP_USER.SIDE_BAR_MANUES.EDIT_CAAP_USER',
            icon: 'edit',
            routerLink: this.baseUrl + '/edit'
        },
        {
            label: 'CAAP_USER.SIDE_BAR_MANUES.CREATE_CAAP_USER',
            icon: 'plus-square',
            routerLink: this.baseUrl + '/create'
        }
    ];
    constructor(
        private planningDataService: PlanningDataService
    ) {
        this.pageType = this.planningDataService.decidePageType();
    }

    ngOnInit(): void {
    }

    searchCriteria(searchedCriteria) {
        this.displayRecord = true;
        this.resetForm = false;
        this.moduleData = searchedCriteria;
    }

    reset() {
        this.resetForm = true;
        this.displayRecord = false;
    }

    canDeactivate() {
        return this.planningDataService.doCanDeactivate(this.childRef);
    }

}
