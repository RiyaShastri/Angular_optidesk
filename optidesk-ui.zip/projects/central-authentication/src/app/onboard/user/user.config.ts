import { Validators } from '@angular/forms';

export const CAAP_USER_CONFIG = {
    moduleName: 'CAAP_USER',
    moduleLabel: 'CAAP_USER.TITLE',
    moduleDescription: 'CAAP_USER.DESCRIPTION',
    search: {
        tblName: 'USERS',
        editExternal: false,
        recordExists: 'CUSTOMER_USER_ALREADY_EXISTS',
        fields: [
            [
                {
                    label: 'CAAP_USER.FIELDS.CLIENTCODE',
                    name: 'clntCode',
                    value: '',
                    valueKey: 'clntCode',
                    childKey: 'usrEmail',
                    parentKeys: [],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'CLIENTCODE_NOT_EXISTS',
                    width: 'full',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'minlength', validator: Validators.minLength(8), message: 'ENTER_VALID_CLIENT_CODE' }
                    ]
                },
                {
                    label: 'CAAP_USER.FIELDS.EMAIL',
                    name: 'usrEmail',
                    value: '',
                    valueKey: 'usrEmail',
                    childKey: '',
                    parentKeys: ['clntCode'],
                    type: 'input',
                    inputType: 'text',
                    fieldType: '',
                    option: '',
                    notExistsLabel: 'EMAIL_NOT_EXISTS',
                    width: 'full',
                    validations: [
                        { name: 'required', validator: Validators.required, message: 'REQUIRED' },
                        { name: 'email', validator: Validators.email, message: 'EMAIL_VALIDATION' },
                    ]
                }
            ]
        ]
    },
    tabs: [
        {
            tabTitle: 'CAAP_USER.CAAP_USER_TAB.TITLE',
            tabDescription: 'CAAP_USER.CAAP_USER_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'customerUser',
            sections: [
                {
                    sectionTitle: 'CAAP_USER.CAAP_USER_TAB.SECTIONS.GENERAL_DATA',
                    tblName: 'customerUser',
                    fields: [
                        [
                            {
                                label: 'CAAP_USER.FIELDS.CLIENTCODE',
                                name: 'clntCode',
                                value: '',
                                valueKey: 'clntCode',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                width: 'full',
                                isEditable: false,
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.FIRSTNAME',
                                name: 'firstName',
                                value: '',
                                valueKey: 'firstName',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                isEditable: true,
                                editableFieldType: 2,
                                width: 'full',
                            },
                            {
                                label: 'CAAP_USER.FIELDS.LASTNAME',
                                name: 'lastName',
                                value: '',
                                valueKey: 'lastName',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                isEditable: true,
                                editableFieldType: 2,
                                width: 'full',
                            },
                            {
                                label: 'CAAP_USER.FIELDS.EMAIL',
                                name: 'usrEmail',
                                value: '',
                                valueKey: 'usrEmail',
                                type: 'input',
                                inputType: 'text',
                                fieldType: 'primary',
                                isEditable: false,
                                width: 'full',
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.MOBNO',
                                name: 'mobile',
                                value: '',
                                valueKey: 'mobile',
                                type: 'input',
                                inputType: 'text',
                                fieldType: '',
                                isEditable: true,
                                editableFieldType: 2,
                                width: 'full',
                                validations: [
                                    { name: 'minlength', validator: Validators.minLength(10), message: 'ENTER_VALID_MOBILE_NO' }
                                ]
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.USERSTATE',
                                name: 'userStatus',
                                value: '',
                                valueKey: 'userStatus',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                validations: [
                                    { name: 'maxlength', validator: Validators.maxLength(1), message: 'INVALID_DELIND' },
                                ],
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        },
        {
            tabTitle: 'CAAP_USER.CUSTOMER_USER_ROLE_LIST_TAB.TITLE',
            tabDescription: 'CAAP_USER.CUSTOMER_USER_ROLE_LIST_TAB.DESCRIPTION',
            tabView: 'SECTION',
            tblName: 'userRoles',
            sections: [
                {
                    sectionTitle: 'CAAP_USER.CAAP_USER_TAB.SECTIONS.ROLES',
                    tblName: 'userRoles',
                    fields: [
                        [
                            {
                                label: 'CAAP_USER.FIELDS.USER_MANAGER',
                                name: 'userManager',
                                value: '',
                                valueKey: 'userManager',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.MASTER_DATA_ADMINISTRATOR',
                                name: 'masterDataAdmin',
                                value: '',
                                valueKey: 'masterDataAdmin',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.NETWORK_PLANNER',
                                name: 'networkPlanner',
                                value: '',
                                valueKey: 'networkPlanner',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.DEMAND_PLANNER',
                                name: 'demandPlanner',
                                value: '',
                                valueKey: 'demandPlanner',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.SUPLIER_PLANNER',
                                name: 'supplierPlanner',
                                value: '',
                                valueKey: 'supplierPlanner',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.PRODUCTION_PLANNER',
                                name: 'productionPlanner',
                                value: '',
                                valueKey: 'productionPlanner',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ],
                        [
                            {
                                label: 'CAAP_USER.FIELDS.DISTRIBUTION_PLANNER',
                                name: 'distributionPlanner',
                                value: '',
                                valueKey: 'distributionPlanner',
                                type: 'select',
                                inputType: 'select',
                                option: 'commonDropList',
                                fieldType: '',
                                isEditable: true,
                                width: 'full',
                                recordExists: 'INVALID_VALUE'
                            }
                        ]
                    ]
                }
            ]
        }
    ]
};
