import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';
import { CanDeactivatGuard } from 'src/app/shared/services/can-deactivat.guard';

const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'view',
                pathMatch: 'full'
            },
            {
                path: 'view',
                component: UserComponent
            },
            {
                path: 'edit',
                component: UserComponent,
                canDeactivate: [CanDeactivatGuard]
            },
            {
                path: 'create',
                component: UserComponent,
                canDeactivate: [CanDeactivatGuard]
            }
        ]
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class UserRoutingModule { }
