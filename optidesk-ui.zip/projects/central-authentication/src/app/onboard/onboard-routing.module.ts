import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenusComponent } from './menus/menus.component';
import { OnboardComponent } from './onboard.component';
import { NgxPermissionsGuard } from 'ngx-permissions';

const routes: Routes = [
    {
        path: '',
        component: OnboardComponent,
        children: [
            {
                path: '',
                component: MenusComponent
            },
            {
                path: 'customer',
                loadChildren: () => import('../onboard/customer/customer.module').then(m => m.CustomerModule),
                canActivate: [NgxPermissionsGuard],
                data: {
                    permissions: {
                        only: ['SUPERADMIN'],
                        redirectTo: '/auth/login'
                    }
                }
            },
            {
                path: 'user',
                loadChildren: () => import('../onboard/user/user.module').then(m => m.UserModule),
                canActivateChild: [NgxPermissionsGuard],
                data: {
                    permissions: {
                        only: ['SUPERADMIN', 'USERADMIN'],
                        redirectTo: '/auth/login'
                    }
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class OnboardRoutingModule { }
