import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContentComponent } from './content.component';
import { DashboardMenuComponent } from './dashboard-menu/dashboard-menu.component';
import { AuthGuardService as AuthGuard } from 'src/app/shared/services/auth-guard.service';

const routes: Routes = [
    {
        path: '',
        component: ContentComponent,
        children: [
            {
                path: '',
                component: DashboardMenuComponent,
                canActivate: [AuthGuard]
            },
            {
                path: 'auth',
                loadChildren: () => import('../auth/auth.module').then(m => m.AuthModule),
            },
            {
                path: 'onboard',
                loadChildren: () => import('../onboard/onboard.module').then(m => m.OnboardModule),
                canActivate: [AuthGuard]
            }
        ]
    },
    { path: '', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ContentRoutingModule { }
