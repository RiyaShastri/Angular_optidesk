import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentRoutingModule } from './content-routing.module';
import { ContentComponent } from './content.component';
import { LayoutModule } from 'src/app/shared/layout/layout.module';
import { DashboardMenuComponent } from './dashboard-menu/dashboard-menu.component';

@NgModule({
    declarations: [
        ContentComponent,
        DashboardMenuComponent
    ],
    imports: [
        CommonModule,
        ContentRoutingModule,
        LayoutModule
    ]
})
export class ContentModule { }
