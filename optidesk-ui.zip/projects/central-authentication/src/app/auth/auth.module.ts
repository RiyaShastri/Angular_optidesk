import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthComponent } from './auth.component';
import { AuthRoutingModule } from './auth-routing.module';
import { LayoutModule } from 'src/app/shared/layout/layout.module';
import { ComponentsModule } from 'src/app/components/components.module';

@NgModule({
    declarations: [AuthComponent],
    imports: [
        CommonModule,
        AuthRoutingModule,
        LayoutModule,
        ComponentsModule
    ]
})
export class AuthModule { }
