import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmOptions, ModalService } from 'src/app/core/utility/modal/modal.service';
import { SUB_ERROR_MESSAGE } from 'src/app/shared/constants';
import { AuthService } from 'src/app/shared/services/auth.service';
import { NotifyService } from 'src/app/shared/services/notify.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    submitted = false;
    strWindowFeatures = 'location=yes,scrollbars=yes,status=yes';

    constructor(
        private formBuilder: FormBuilder,
        private authService: AuthService,
        private modalService: ModalService,
        private notifyService: NotifyService
    ) {
    }

    ngOnInit() {
        document.body.classList.add('login-page');
        this.loginForm = this.formBuilder.group(
            {
                orgCode: ['', Validators.required],
            }
        );

        this.notifyService.currentMessage.subscribe(value => {
            if (value.hasOwnProperty('type') && value.type === 'verify-code') {
                this.errorRes(value.error);
            }

            if (value.hasOwnProperty('type') && value.type === 'email-verification') {
                this.successRes('Your account has been activated successfully. You can now login.');
            }
        });
    }

    get f() { return this.loginForm.controls; }

    getClientLoginURL() {
        this.submitted = true;

        if (this.loginForm.invalid) {
            return;
        }

        const params = {
            clientCode: this.loginForm.value.orgCode
        };
        this.authService.login(params).then(response => {
            location.href = response[`redirectUrl`];
        }).catch(error => {
            this.errorRes(error);
        });
    }

    successRes(mainMessage) {
        this.displayPopup(
            'success',
            'MESSAGE.TITLE_SUCCESS',
            mainMessage
        );
    }

    errorRes(err) {
        let subMessage = '';
        if (SUB_ERROR_MESSAGE.includes(err.error.errorSsid)) {
            subMessage = 'MESSAGE.' + err.error.errorSsid;
        }
        this.displayPopup(
            'info',
            'Error',
            subMessage
        );
    }

    displayPopup(type, title, message, subMessage = '', messageParam = {}, isActionModal = false) {
        const modalOption: ConfirmOptions = {
            type,
            title,
            message,
            subMessage,
            messageParam,
            isActionModal
        };
        return this.modalService.confirm(modalOption);
    }

    adminLogin() {
        this.authService.adminLogin().then(response => {
            window.open(response[`redirectUrl`], '_blank', this.strWindowFeatures);
        }).catch(error => {
        });
    }
}
