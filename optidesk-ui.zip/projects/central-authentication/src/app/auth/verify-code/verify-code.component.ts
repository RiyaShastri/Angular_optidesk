import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxPermissionsService } from 'ngx-permissions';
import { AuthService } from 'src/app/shared/services/auth.service';
import { ComponentService } from 'src/app/components/component.service';
import { NotifyService } from 'src/app/shared/services/notify.service';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-verify-code',
    templateUrl: './verify-code.component.html',
    styleUrls: ['./verify-code.component.css']
})
export class VerifyCodeComponent implements OnInit {
    userVerification: any;
    userVerificationData: any;
    displayLoader = false;

    @ViewChild('content') myModal: any;

    constructor(
        private Activatedroute: ActivatedRoute,
        private router: Router,
        private authService: AuthService,
        private permissionsService: NgxPermissionsService,
        private componentService: ComponentService,
        private notifyService: NotifyService,
        private modalService: NgbModal
    ) { }

    ngOnInit(): void {
        this.displayLoader = true;
        this.Activatedroute.queryParamMap.subscribe((params: any) => {
            this.userVerification = params.params;
            const requestJson = {
                ...this.userVerification,
                sessionState: this.userVerification.session_state
            };
            this.verifyCode(requestJson);
        });
    }

    verifyCode(requestJson) {
        this.authService.userCodeVerification(requestJson).then(response => {
            this.displayLoader = false;
            this.userVerificationData = response;
            if (!response.isSessionActive) {
                this.loadRoleAndRedirect();
            } else {
                this.displayModal();
            }
        }).catch(error => {
            const errMsgObj = {
                type: 'verify-code',
                error
            };
            this.notifyService.changeMessage(errMsgObj);
            this.router.navigate(['/auth/login']);
        });
    }

    loadRoleAndRedirect() {
        const currentTime = new Date().getTime();
        if (
            this.userVerificationData.role.indexOf('SUPERADMIN') > -1 ||
            this.userVerificationData.role.indexOf('USERADMIN') > -1
        ) {
            localStorage.setItem('token', this.userVerificationData.token);
            this.notifyService.setToken(this.userVerificationData.token);
            this.authService.getUserDetails().then(userInfo => {
                const perm = this.userVerificationData.role;
                const encryptedRoles = this.componentService.encryptText(perm);
                const userDetailsObj = {
                    type: 'user-details',
                    data: userInfo
                };
                this.notifyService.setUserDetailsJson(userDetailsObj);
                this.notifyService.setRole(JSON.stringify(encryptedRoles));
                this.permissionsService.loadPermissions(perm);
                localStorage.setItem('userLoggedIn', currentTime.toString());
                this.router.navigate(['/']);
            }).catch(error => {
            });
        } else {
            const authenticateUserURL = '/authenticate-user?token=' + this.userVerificationData.token + '&t=' + currentTime;
            if (!environment.production) {
                location.href = environment.managementUIURL + authenticateUserURL;
            } else {
                location.href = this.userVerificationData.host + '/optidesk' + authenticateUserURL;
            }
        }
    }

    displayModal() {
        const ngbModalOptions: NgbModalOptions = {
            backdrop: 'static',
            keyboard: false
        };
        this.modalService.open(this.myModal, ngbModalOptions).result.then((result) => {
            this.logoutFromPrevSessions();
        }, (reason) => {
            this.modalService.dismissAll();
        });
    }

    logoutFromPrevSessions() {
        this.notifyService.setToken(this.userVerificationData.token);
        this.authService.logoutFromAllDevice().then(response => {
            this.modalService.dismissAll();
            this.loadRoleAndRedirect();
        }).catch(error => {
        });
    }

    dismiss() {
        this.modalService.dismissAll();
        this.router.navigate(['/auth/login']);
        window.close();
    }
}
