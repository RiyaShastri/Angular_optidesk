import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerifyCodeRoutingModule } from './verify-code-routing.module';
import { VerifyCodeComponent } from './verify-code.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
    declarations: [
        VerifyCodeComponent
    ],
    imports: [
        CommonModule,
        VerifyCodeRoutingModule,
        TranslateModule
    ]
})
export class VerifyCodeModule { }
