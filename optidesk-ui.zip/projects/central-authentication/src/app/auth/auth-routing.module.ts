import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthComponent } from './auth.component';

const routes: Routes = [
    {
        path: '',
        component: AuthComponent,
        children: [
            {
                path: 'code-verification',
                loadChildren: () => import('../auth/verify-code/verify-code.module').then(m => m.VerifyCodeModule)
            },
            {
                path: 'verify-email',
                loadChildren: () => import('../auth/accept-invitation/accept-invitation.module').then(m => m.AcceptInvitationModule)
            },
            {
                path: 'login',
                loadChildren: () => import('../auth/login/login.module').then(m => m.LoginModule)
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AuthRoutingModule { }
