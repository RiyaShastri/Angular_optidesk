import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcceptInvitationRoutingModule } from './accept-invitation-routing.module';
import { AcceptInvitationComponent } from './accept-invitation.component';


@NgModule({
    declarations: [AcceptInvitationComponent],
    imports: [
        CommonModule,
        AcceptInvitationRoutingModule
    ]
})
export class AcceptInvitationModule { }
