import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AcceptInvitationComponent } from './accept-invitation.component';

const routes: Routes = [
    {
        path: '',
        component: AcceptInvitationComponent,
    },
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AcceptInvitationRoutingModule { }
