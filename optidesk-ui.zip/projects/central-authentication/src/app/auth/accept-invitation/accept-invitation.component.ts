import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { NotifyService } from 'src/app/shared/services/notify.service';

@Component({
    selector: 'app-accept-invitation',
    templateUrl: './accept-invitation.component.html',
    styleUrls: ['./accept-invitation.component.css']
})
export class AcceptInvitationComponent implements OnInit {
    emailActivation: any;

    constructor(
        private Activatedroute: ActivatedRoute,
        private authService: AuthService,
        private router: Router,
        private notifyService: NotifyService,
    ) { }

    ngOnInit(): void {
        document.body.classList.add('login-page');
        this.Activatedroute.queryParamMap
            .subscribe((verificationCode: any) => {
                this.emailActivation = verificationCode.params;
            });

        if (this.emailActivation) {
            this.authService.userEmailActivation(this.emailActivation).then(response => {
                const userVerificationObj = {
                    type: 'email-verification',
                    data: response
                }
                this.notifyService.changeMessage(userVerificationObj);
                this.router.navigate(['/auth/login']);
            }).catch(error => {
            });
        }
    }

}
