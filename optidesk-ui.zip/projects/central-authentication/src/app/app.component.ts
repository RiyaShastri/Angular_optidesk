import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from 'src/app/shared/services/auth.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    display = 'block';
    displaySessionEnd = true;
    @ViewChild('content') myModal: any;

    // Prevent refresh using keyboard
    @HostListener('window:keydown', ['$event'])
    unloadHandler(event) {
        this.authService.preventKeyboardRefresh(event);
    }

    constructor(
        private translate: TranslateService,
        public router: Router,
        private authService: AuthService,
        private modalService: NgbModal
    ) {
        this.translate.setDefaultLang('en');
        this.translate.use('en');
    }

    ngOnInit(): void {
        this.authService.manageSingleSession();
    }

    displayModal() {
        this.modalService.open(this.myModal, {}).result.then((result) => {
            this.endUserSession();
        }, (reason) => {
            this.modalService.dismissAll();
        });
    }

    endUserSession() {
        this.authService.logout().then(response => {
            this.modalService.dismissAll();
            localStorage.clear();
            this.router.navigate(['/auth/login']);
            this.displaySessionEnd = true;
        }).catch(error => {
        });
    }

    dismiss() {
        this.modalService.dismissAll();
        this.router.navigate(['/auth/login']);
    }
}
